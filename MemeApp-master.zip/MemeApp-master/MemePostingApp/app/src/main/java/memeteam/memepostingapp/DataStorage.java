package memeteam.memepostingapp;
/**
 * Created by bal_cjoleary on 12/8/2016.
 */
public class DataStorage {

    private String Message;
    private String Date;
    private String Time;

    public DataStorage(String data)
    {
        String[] list = data.split(":");
        Message = list[0];
        Date = list[1];
        Time = list[2];
    }

    public DataStorage(){}

    /**
     * Date = 0 , Time = 1 , message = 2
     * @return Get all the values in a array
     */
    public String[] getData()
    {
        String[] items = new String[3];
        items[0] = Date;
        items[1] = Time;
        items[2] = Message;
        return items;
    }

    public void setTime(String time) {
        Time = time;
    }

    public void setMessage(String message) {
        Message = message;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String print(){
        return Time+Message+Date;
    }

    /**
     * fills in the view with date, time and message
     *
     * @return view with filled text
     */



    public String fillView()
    {
        return Date+" "+Message+" "+Time;
    }

    /**
     * Gets a certain value in Data Storage
     * @param item Date , Time or message
     * @return Date , Time or message
     */
    public String getData(String item)
    {
        switch (item){
            case "Date":
                return Date;
            case "Message":
                return Message;
            case "Time":
                return Time;
            default:
                return "error";
        }
    }
}
