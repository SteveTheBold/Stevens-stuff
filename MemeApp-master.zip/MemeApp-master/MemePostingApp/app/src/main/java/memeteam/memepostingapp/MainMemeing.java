package memeteam.memepostingapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.util.Log;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import java.sql.Ref;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainMemeing extends AppCompatActivity {
    // URL of object to be parsed
    String JsonURL = "https://chats.mrow.org/chats";
    // This string will hold the results
    String data = "";
    // Defining the Volley request queue that handles the URL request concurrently
    RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_memeing);
        requestQueue = Volley.newRequestQueue(this);
        mainChat = (ListView) findViewById(R.id.mainChat);
        arrayOfDataEntries = new ArrayList<DataStorage>();
    }

    private ListView mainChat;

    private ListViewAd adapter;
    private ArrayList<DataStorage> arrayOfDataEntries;

//    private class ChatAsyncTask extends AsyncTask<String, Void, List<DataStorage>>{
//
//        @Override
//        protected List<DataStorage> doInBackground(String... urls) {
//
//        }
//
//        @Override
//        protected void onPostExecute(List<DataStorage> data) {
//
//        }
//    }


    /**
     * Refreshes the main chat
     * Chat view.
     */

    public void Refresh(View view) {
        adapter = new ListViewAd(this, R.id.mainChat, arrayOfDataEntries);
        mainChat.setAdapter(adapter);
        JsonObjectRequest arrayreq = new JsonObjectRequest(JsonURL, null,
                new Response.Listener<JSONObject>() {

                    // Takes the response from the JSON request
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray rows = response.getJSONArray("rows");
                            for (int j = 0; j < rows.length(); j++) {
                                JSONObject value = rows.getJSONObject(j);
                                DataStorage fill = new DataStorage();
                                fill.setTime(value.getString("time"));
                                fill.setMessage(value.getString("msg"));
                                fill.setDate(value.getString("date"));
                                arrayOfDataEntries.add(fill);
                            }

                            adapter.notifyDataSetChanged();
                        } catch (Exception e) {
                            System.out.println(e.toString());
                        }


                    }
                },
                new Response.ErrorListener() {
                    @Override
                    // Handles errors that occur due to Volley
                    public void onErrorResponse(VolleyError error) {
                        Log.e("Volley", error.getMessage());
                    }
                }
        );
        System.out.println("debug");
        requestQueue.add(arrayreq);
    }

    /**
     * Takes whats in the editable text value and posts
     */
    public void Send(View View) {
        final EditText message = (EditText) findViewById(R.id.messageEditText);
        //String text is the message the user typed in the editable text view
        String text = message.getText().toString();
        //the send button will not function with no text in the editable view
        text = text.trim();
        if (text.length() > 0) {

            String url = "https://chats.mrow.org/chats";
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            final String jsonString = "{'msg':  '" + text + "'} ";
            try {
                JSONObject jsonArray = new JSONObject(jsonString);
                JsonObjectRequest jsonArrayRequest = new JsonObjectRequest(Request.Method.POST, url, jsonArray, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        message.setText("");
                    }
                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                });
                requestQueue.add(jsonArrayRequest);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

}
