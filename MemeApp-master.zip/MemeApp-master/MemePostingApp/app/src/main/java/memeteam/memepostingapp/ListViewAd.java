package memeteam.memepostingapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

/**
 * Created by bal_sjtestone001 on 12/16/2016.
 */
public class ListViewAd extends ArrayAdapter<DataStorage> {

    private int layoutResource;

    public ListViewAd(Context context, int layoutResource, List<DataStorage> threeStringsList) {
        super(context, layoutResource, threeStringsList);
        this.layoutResource = layoutResource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View view = convertView;

        if (view == null) {
            LayoutInflater layoutInflater = LayoutInflater.from(getContext());
            view = layoutInflater.inflate(R.layout.threelistview, null);
        }

        DataStorage data = getItem(position);

        if (data != null) {
            TextView leftTextView = (TextView) view.findViewById(R.id.leftTextView);
            TextView rightTextView = (TextView) view.findViewById(R.id.rightTextView);
            TextView centreTextView = (TextView) view.findViewById(R.id.centreTextView);

            if (leftTextView != null) {
                leftTextView.setText(data.getData()[0]);
            }

            if (rightTextView != null) {
                rightTextView.setText(data.getData()[1]);
            }

            if (centreTextView != null) {
                centreTextView.setText(data.getData()[2]);
            }
        }

        return view;
    }
}
