package clubs.bhs_clubsapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {


    public static String sharedPreferencesName = "ClubsApp";
    public static String preferenceNameOfUserID = "userID";

    public enum ClubViewOption{
        ALL_CLUBS, CLUBS_USER_IS_IN, CLUBS_USER_IS_LEADER_OF
    }
    private ClubViewOption clubViewOption = ClubViewOption.ALL_CLUBS;

    ArrayList<ClubObject> clubs;
    private ListView clubList;
    private Context context;


    private static boolean GET_USER_ID_ON_FIRST_LAUNCH = true;
    //you can set the above to false for debug purposes

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        context = getBaseContext();

        GlobalDatabaseConnectionContainer.globalDatabaseInitializationCallback gdic = new GlobalDatabaseConnectionContainer.globalDatabaseInitializationCallback() {
            @Override
            public void onFinishedInitializing() {
                if (!GlobalDatabaseConnectionContainer.hasUser() && GET_USER_ID_ON_FIRST_LAUNCH)
                {
                    Intent goToFirstLaunchGetUserIDActivity = new Intent(context,FirstLaunchGetUserIDActivity.class);
                    startActivityForResult(goToFirstLaunchGetUserIDActivity,0);
                    //"abc".charAt(0);
                }
                else
                {
                    setUpSpinner();
                }
                //setUpSpinner();
                databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                //d.debug_addRandomUsersToRandomClubPositions(100,getBaseContext());
                //d.addClub("deletion club","","",null,context);
                refreshClubListDisplay(clubViewOption);
            }
        };
        GlobalDatabaseConnectionContainer.setGlobalDatabaseInitializationCallback(gdic);
        GlobalDatabaseConnectionContainer.initialize(this);
//        Intent intent = new Intent(getBaseContext(),ClubManagementPage.class);
//        intent.addFlags(intent.FLAG_ACTIVITY_NEW_TASK);
//        getBaseContext().startActivity(intent);
        // must get information and set it to the ArrayList clubs

    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        super.onActivityResult(requestCode,resultCode,data);
        setUpSpinner();
    }

    public void setUpSpinner()
    {
        Spinner spinner = (Spinner) findViewById(R.id.club_view_choices_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.club_view_choices_array,android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String s = (String) parent.getItemAtPosition(position);
                switch(s)
                {
                    case "All clubs":
                        clubViewOption = ClubViewOption.ALL_CLUBS;
                        break;
                    case "Clubs I'm in":
                        clubViewOption = ClubViewOption.CLUBS_USER_IS_IN;
                        break;
                    case "Clubs I'm a leader of":
                        clubViewOption = ClubViewOption.CLUBS_USER_IS_LEADER_OF;
                        break;
                }
                refreshClubListDisplay(clubViewOption);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                //do nothing
            }
        });
    }

    public void refreshClubListDisplay(ClubViewOption cvo)
    {
        if (GlobalDatabaseConnectionContainer.hasUser())
        {
            databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
            User thisUser = GlobalDatabaseConnectionContainer.getUserOfThisApp();
            switch(cvo)
            {
                case ALL_CLUBS:
                    //setClubListDisplay(GlobalDatabaseConnectionContainer.getDatabaseConnection().getAllClubs());
                    ArrayList<ClubObject> allClubs = d.getAllClubs();
                    setClubListDisplay(allClubs);
                    break;
                case CLUBS_USER_IS_IN:
                    //setClubListDisplay(GlobalDatabaseConnectionContainer.getUserOfThisApp().getClubsThisUserIsIn());
                    ArrayList<ClubObject> clubsUserIsIn = thisUser.getClubsThisUserIsALeaderOf_OrIsAMemberOf();
                    setClubListDisplay(clubsUserIsIn);
                    break;
                case CLUBS_USER_IS_LEADER_OF:
                    //setClubListDisplay(GlobalDatabaseConnectionContainer.getUserOfThisApp().getClubsThisUserIsALeaderOf());
                    ArrayList<ClubObject> clubsThisUserIsALeaderOf = thisUser.getClubsThisUserIsALeaderOf();
                    setClubListDisplay(clubsThisUserIsALeaderOf);
                    break;
            }
        }
    }

    public void setClubListDisplay(ArrayList<ClubObject> clubs)
    {
        clubList = (ListView) findViewById(R.id.publicList);
        ClubItemAdapter adapter = new ClubItemAdapter(context,clubs);
        clubList.setAdapter(adapter);
    }

    public ClubCalendar getTestClubCalendar()
    {
        ArrayList<CalendarEvent> events = new ArrayList<>();
        events.add(new CalendarEvent(2016,11,23,"event1","akdsf"));
        events.add(new CalendarEvent(2017,0,8,"event2","auyfda g"));
        events.add(new CalendarEvent(2017,2,17,"event3"," adf adh gdfat"));
        events.add(new CalendarEvent(2018,7,30,"event4","ja difay dgsyfu ag"));

        ClubCalendar cc = new ClubCalendar(events);
        return cc;
    }

    public void performRandomActionWithRandomClubAndUser(databaseConnection d)
    {
        int numUsers = d.getAllUsers().size();
        int numClubs = d.getAllClubs().size();
        Random r = new Random();
        int userIndex = r.nextInt(numUsers);
        int clubIndex = r.nextInt(numClubs);
        int userID = d.getAllUsers().get(userIndex).getID();
        int clubID = d.getAllClubs().get(clubIndex).getID();
        int action = r.nextInt(3);
        switch(action){
            case 0:
                d.addUserToClub(userID,clubID,null,this);
                break;
            case 1:
                d.addLeaderToClub(userID,clubID,null,this);
                break;
            case 2:
                d.addPendingJoinUserToClub(userID,clubID,null,this);
                break;
        }
    }

    public void addRandomClub(databaseConnection d)
    {
        String alphabet = "abcdefghijklmnopqrstuvwxyz ";
        String clubName = "";
        Random r = new Random();
        int numCharsInName = r.nextInt(2) + 4;
        for (int i = 0; i < numCharsInName; i++)
        {
            clubName = clubName + alphabet.charAt(r.nextInt(alphabet.length()));
        }
        clubName = clubName + " club";
        String desc = "";
        int numCharsInDesc = r.nextInt(6) + 20;
        for (int i = 0; i < numCharsInDesc; i++)
        {
            desc = desc + alphabet.charAt(r.nextInt(alphabet.length()));
        }
        d.addClub(clubName,desc,"",null,this);
    }

    public void addRandomUser(databaseConnection d)
    {
        String alphabet = "abcdefghijklmnopqrstuvwxyz ";
        String userName = "";
        Random r = new Random();
        int charsInUserName = r.nextInt(7) + 4;
        for (int i = 0; i < charsInUserName; i++)
        {
            userName = userName + alphabet.charAt(r.nextInt(alphabet.length()));
        }
        d.addUser(userName,null,this);
    }

    public void pressRefreshClubs(View view)
    {
        final ProgressDialog pd = new ProgressDialog(this);
        pd.setMessage("Refreshing...");
        pd.setCancelable(false);
        pd.show();
        databaseConnection.refreshCallback rc = new databaseConnection.refreshCallback() {
            @Override
            public void onRefresh() {
                refreshClubListDisplay(clubViewOption);
                pd.cancel();
            }
        };
        GlobalDatabaseConnectionContainer.getDatabaseConnection().refreshDatabase(rc,this);
    }

    public void pressUserProfile(View view)
    {
        Intent goToProfileActivity = new Intent(this,UserProfileActivity.class);
        startActivity(goToProfileActivity);
    }

}
