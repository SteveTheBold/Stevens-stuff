package clubs.bhs_clubsapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by super on 6/8/2017.
 */

public class UserJoinRequestItemAdapter extends BaseAdapter {

    private Context c;
    private ArrayList<User> pendingJoinUsers;
    private ClubObject thisClub;

    public UserJoinRequestItemAdapter(Context c, ClubObject thisClub)
    {
        this.c = c;
        this.thisClub = thisClub;
        this.pendingJoinUsers = thisClub.getPendingJoinUsers();
    }

    public View getView(int i, View view, ViewGroup vg)
    {
        LayoutInflater layoutInflater = LayoutInflater.from(c);
        view = layoutInflater.inflate(R.layout.user_join_request_item,null);
        final View copyOfView = view;

        final User thisUser = pendingJoinUsers.get(i);

        final TextView pendingJoinUsername = (TextView) view.findViewById(R.id.pendingJoinUsername);
        final Button accept = (Button) view.findViewById(R.id.acceptUserJoinRequestButton);
        final Button deny = (Button) view.findViewById(R.id.denyUserJoinRequestButton);
        final LinearLayout linearLayoutWhichContainsPendingJoinUser = (LinearLayout) view.findViewById(R.id.linearLayoutWhichContainsPendingJoinUser);

        pendingJoinUsername.setText(thisUser.getName());

        Button.OnClickListener onAccept = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int thisClubID = thisClub.getID();
                int thisUserID = thisUser.getID();
                final ProgressDialog pd = new ProgressDialog(c);
                pd.setMessage("Accepting Request...");
                pd.setCancelable(false);
                pd.show();

                databaseConnection.acceptPendingUserRequestCallback apurc = new databaseConnection.acceptPendingUserRequestCallback() {
                    @Override
                    public void onAccept() {
                        linearLayoutWhichContainsPendingJoinUser.setBackgroundColor(copyOfView.getResources().getColor(R.color.blue));
                        accept.setClickable(false);
                        deny.setClickable(false);
                        accept.setVisibility(View.GONE);
                        deny.setVisibility(View.GONE);
                        pendingJoinUsername.setText(thisUser.getName() + " (accepted)");
                        pd.cancel();
                    }
                };
                databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                d.acceptPendingUserRequest(thisUserID,thisClubID,apurc,c);
            }
        };

        Button.OnClickListener onDeny = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int thisClubId = thisClub.getID();
                int thisUserID = thisUser.getID();
                final ProgressDialog pd = new ProgressDialog(c);
                pd.setMessage("Denying Request...");
                pd.setCancelable(false);
                pd.show();

                databaseConnection.removePendingUserRequestCallback rpurc = new databaseConnection.removePendingUserRequestCallback() {
                    @Override
                    public void onRemoveRequest() {
                        linearLayoutWhichContainsPendingJoinUser.setBackgroundColor(copyOfView.getResources().getColor(R.color.blue));
                        accept.setClickable(false);
                        deny.setClickable(false);
                        accept.setVisibility(View.GONE);
                        deny.setVisibility(View.GONE);
                        pendingJoinUsername.setText(thisUser.getName() + " (denied)");
                        pd.cancel();
                    }
                };
                databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                d.removePendingUserRequest(thisUserID,thisClubId,rpurc,c);
            }
        };

        accept.setOnClickListener(onAccept);
        deny.setOnClickListener(onDeny);
        return view;
    }



    public long getItemId(int i)
    {
        return pendingJoinUsers.get(i).getID();
    }

    public int getCount()
    {
        return pendingJoinUsers.size();
    }

    public Object getItem(int position) {
        return null;
    }

}
