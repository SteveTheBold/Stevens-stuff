package clubs.bhs_clubsapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by super on 6/10/2017.
 */

public class ClubSelectionAdapter extends BaseAdapter {

    private ArrayList<ClubObject> clubs;
    private onClubSelectedListener onSelected;
    private Context c;
    private LinearLayout previousSelectedLinearLayout = null;

    public interface onClubSelectedListener{
        void onClubSelected(int clubID);
    }

    public ClubSelectionAdapter(ArrayList<ClubObject> clubs, Context c, onClubSelectedListener onSelected)
    {
        this.clubs = clubs;
        this.c = c;
        this.onSelected = onSelected;
    }

    public View getView(int i, View view, ViewGroup vg)
    {
        LayoutInflater layoutInflater = LayoutInflater.from(c);
        view = layoutInflater.inflate(R.layout.club_selection_list_item,null);

        final ClubObject thisClub = clubs.get(i);
        final TextView club_selection_list_item_club_name_textView = (TextView) view.findViewById(R.id.club_selection_list_item_club_name_textView);
        final LinearLayout ll = (LinearLayout) view.findViewById(R.id.ClubSelectionListItemLinearLayout);
        club_selection_list_item_club_name_textView.setText(thisClub.getClubName());
        View.OnClickListener onClick = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (previousSelectedLinearLayout != null)
                {
                    previousSelectedLinearLayout.setBackgroundColor(c.getResources().getColor(R.color.red));
                }
                ll.setBackgroundColor(c.getResources().getColor(R.color.blue));
                previousSelectedLinearLayout = ll;
                if (onSelected != null)
                {
                    onSelected.onClubSelected(thisClub.getID());
                }
            }
        };
        ll.setOnClickListener(onClick);

        return view;
    }


    public long getItemId(int i){return clubs.get(i).getID();}

    public int getCount(){return clubs.size();}

    public Object getItem(int position) {
        return null;
    }
}
