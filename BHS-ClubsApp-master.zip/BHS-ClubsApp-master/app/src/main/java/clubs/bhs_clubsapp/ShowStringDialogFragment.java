package clubs.bhs_clubsapp;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;

/**
 * Created by bal_tascofield on 6/1/2017.
 */

public class ShowStringDialogFragment extends DialogFragment {
    //to show this, create a new instance of this class and call show()
    private static String positiveButtonText = "default ok";
    private static String messageToDisplay = "default message";
    private static DialogInterface.OnClickListener onClickOkay = new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            //do nothing
        }
    };

    public static void setPositiveButtonText(String s){positiveButtonText = s;}
    public static void setMessageToDisplay(String s){messageToDisplay = s;}
    public static void setOnClickOkay(DialogInterface.OnClickListener l){onClickOkay = l;}
    public Dialog onCreateDialog(Bundle SavedInstanceState)
    {
        AlertDialog.Builder b = new AlertDialog.Builder(getActivity());
        b.setMessage(messageToDisplay);
        b.setCancelable(false);
        b.setPositiveButton(positiveButtonText,onClickOkay);
        return b.create();
    }
}
