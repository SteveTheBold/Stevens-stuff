package clubs.bhs_clubsapp;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

/**
 * Created by super on 6/10/2017.
 */

public class ModerationPanelActivity extends AppCompatActivity {

    private activityResultTask task = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_moderation_panel);
    }

    private interface activityResultTask{
        void onResult(int requestCode, int resultCode, Intent data);
    }



    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (task != null)
        {
            task.onResult(requestCode,resultCode,data);
        }
    }

    public void moderationPanelOnPressBack(View view)
    {
        finish();
    }

    public void moderationPanelOnPressChangeClubName(View view)
    {
        final Context copyOfThis = this;
        task = new activityResultTask() {
            @Override
            public void onResult(int requestCode, int resultCode, Intent data) {
                if (resultCode == Activity.RESULT_OK)
                {
                    final int clubID = data.getIntExtra(ClubSelectionActivity.SELECTED_CLUB_ID_EXTRA,-1);
                    ClubObject clubWhoseNameToChange = GlobalDatabaseConnectionContainer.getDatabaseConnection().getClubWithID(clubID);
                    final String oldName = clubWhoseNameToChange.getClubName();
                    AlertDialog.Builder b = new AlertDialog.Builder(copyOfThis);
                    final EditText editNewClubName = new EditText(copyOfThis);
                    editNewClubName.setHint("Enter new club name");
                    b.setView(editNewClubName);
                    b.setPositiveButton("Change name", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            String newName = editNewClubName.getText().toString();
                            if (newName.length() == 0)
                            {
                                ShowStringDialogFragment.setMessageToDisplay("The club's name can't be 0 characters long.");
                                ShowStringDialogFragment.setPositiveButtonText("OKAY");
                                ShowStringDialogFragment.setOnClickOkay(new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        //do nothing
                                    }
                                });
                                ShowStringDialogFragment ssdf = new ShowStringDialogFragment();
                                ssdf.show(getFragmentManager(),"");
                            }
                            else
                            {
                                final ProgressDialog pd = new ProgressDialog(copyOfThis);
                                pd.setMessage("Changing " + oldName + "'s name to " + newName);
                                pd.setCancelable(false);
                                pd.show();
                                databaseConnection.updateClubNameCallback ucnc = new databaseConnection.updateClubNameCallback() {
                                    @Override
                                    public void onUpdateName() {
                                        pd.cancel();
                                    }
                                };
                                databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                                d.updateNameOfClub(clubID,newName,ucnc,copyOfThis);
                            }
                        }
                    });
                    b.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //do nothing
                        }
                    });
                    b.show();
                }
            }
        };
        ClubSelectionActivity.setClubsToDisplay(GlobalDatabaseConnectionContainer.getDatabaseConnection().getAllClubs());
        Intent chooseClub = new Intent(this,ClubSelectionActivity.class);
        startActivityForResult(chooseClub,0);
    }

    public void moderationPanelOnPressDeleteClub(View view)
    {
        final Context copyOfThis = this;
        task = new activityResultTask() {
            @Override
            public void onResult(int requestCode, int resultCode, Intent data) {
                if (resultCode == Activity.RESULT_OK)
                {
                    final int clubID = data.getIntExtra(ClubSelectionActivity.SELECTED_CLUB_ID_EXTRA,-1);
                    final ClubObject clubToDelete = GlobalDatabaseConnectionContainer.getDatabaseConnection().getClubWithID(clubID);
                    cancelOrContinueDialogFragment.setMessageToDisplay("Delete " + clubToDelete.getClubName() + "? You cannot undo this.");
                    cancelOrContinueDialogFragment.setPositiveButtonText("Delete");
                    cancelOrContinueDialogFragment.setNegativeButtonText("Cancel");
                    cancelOrContinueDialogFragment.setOnClickNegative(new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //do nothing
                        }
                    });
                    cancelOrContinueDialogFragment.setOnClickPositive(new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            final ProgressDialog pd = new ProgressDialog(copyOfThis);
                            pd.setMessage("Deleting " + clubToDelete.getClubName() + "...");
                            pd.setCancelable(false);
                            pd.show();
                            databaseConnection.deleteClubCallback dcc = new databaseConnection.deleteClubCallback() {
                                @Override
                                public void onDelete() {
                                    pd.cancel();
                                }
                            };
                            databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                            d.deleteClub(clubID,dcc,copyOfThis);
                        }
                    });
                    cancelOrContinueDialogFragment cocdf = new cancelOrContinueDialogFragment();
                    cocdf.show(getFragmentManager(),"");
                }
            }
        };
        ClubSelectionActivity.setClubsToDisplay(GlobalDatabaseConnectionContainer.getDatabaseConnection().getAllClubs());
        Intent chooseClub = new Intent(this,ClubSelectionActivity.class);
        startActivityForResult(chooseClub,0);
    }

    public void moderationPanelOnPressCreateNewClub(View view)
    {
        final Context copyOfThis = this;
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        final EditText editNameOfNewClub = new EditText(this);
        editNameOfNewClub.setHint("Enter name of new club");
        b.setView(editNameOfNewClub);
        b.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //do nothing
            }
        });
        b.setPositiveButton("Create", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String newClubName = editNameOfNewClub.getText().toString();
                final ProgressDialog pd = new ProgressDialog(copyOfThis);
                pd.setMessage("Creating " + newClubName + "...");
                pd.setCancelable(false);
                pd.show();

                databaseConnection.addClubCallback acc = new databaseConnection.addClubCallback() {
                    @Override
                    public void onAdd(int idOfNewClub) {
                        pd.cancel();
                    }
                };
                databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                d.addClub(newClubName,"","",acc,copyOfThis);
            }
        });
        b.show();
    }

    public void moderationPanelOnPressDeleteUser(View view)
    {
        final Context copyOfThis = this;
        task = new activityResultTask() {
            @Override
            public void onResult(int requestCode, int resultCode, Intent data) {
                if (resultCode == Activity.RESULT_OK)
                {
                    final int userID = data.getIntExtra(UserSelectionActivity.SELECTED_USER_ID_EXTRA,-1);
                    final User userToDelete = GlobalDatabaseConnectionContainer.getDatabaseConnection().getUserWithID(userID);
                    cancelOrContinueDialogFragment.setMessageToDisplay("Delete " + userToDelete.getName() + "? You cannot undo this.");
                    cancelOrContinueDialogFragment.setPositiveButtonText("Delete");
                    cancelOrContinueDialogFragment.setNegativeButtonText("Cancel");
                    cancelOrContinueDialogFragment.setOnClickNegative(new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //do nothing
                        }
                    });
                    cancelOrContinueDialogFragment.setOnClickPositive(new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            final ProgressDialog pd = new ProgressDialog(copyOfThis);
                            pd.setMessage("Deleting " + userToDelete.getName() + "...");
                            pd.setCancelable(false);
                            pd.show();

                            databaseConnection.deleteUserCallback duc = new databaseConnection.deleteUserCallback() {
                                @Override
                                public void onDeleteUser() {
                                    pd.cancel();
                                }
                            };
                            databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                            d.deleteUser(userID,duc,copyOfThis);
                        }
                    });
                    cancelOrContinueDialogFragment cocdf = new cancelOrContinueDialogFragment();
                    cocdf.show(getFragmentManager(),"");
                }
            }
        };
        UserSelectionActivity.setUsersToDisplay(GlobalDatabaseConnectionContainer.getDatabaseConnection().getAllUsers());
        Intent chooseUser = new Intent(this,UserSelectionActivity.class);
        startActivityForResult(chooseUser,0);
    }

    public void moderationPanelOnPressCreateNewUser(View view)
    {
        final Context copyOfThis = this;
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        final EditText editNameOfNewUser = new EditText(this);
        editNameOfNewUser.setHint("Enter name of new user");
        b.setView(editNameOfNewUser);
        b.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //do nothing
            }
        });
        b.setPositiveButton("Create", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String newUserName = editNameOfNewUser.getText().toString();
                final ProgressDialog pd = new ProgressDialog(copyOfThis);
                pd.setMessage("Creating " + newUserName + "...");
                pd.setCancelable(false);
                pd.show();

                databaseConnection.addUserCallback auc = new databaseConnection.addUserCallback() {
                    @Override
                    public void onAdd(int idOfNewUser, String generatedSecretPassword) {
                        pd.cancel();
                        ShowStringDialogFragment.setMessageToDisplay("The secret password of the new user that you just created is " + generatedSecretPassword);
                        ShowStringDialogFragment.setPositiveButtonText("OK");
                        ShowStringDialogFragment.setOnClickOkay(new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                //do nothing
                            }
                        });
                        ShowStringDialogFragment ssdf = new ShowStringDialogFragment();
                        ssdf.show(getFragmentManager(),"");
                    }
                };
                databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                d.addUser(newUserName,auc,copyOfThis);
            }
        });
        b.show();
    }

    public void moderationPanelOnPressChangeUserName(View view)
    {
        final Context copyOfThis = this;
        task = new activityResultTask() {
            @Override
            public void onResult(int requestCode, int resultCode, Intent data) {
                if (resultCode == Activity.RESULT_OK)
                {
                    final int userID = data.getIntExtra(UserSelectionActivity.SELECTED_USER_ID_EXTRA,-1);
                    User userWhoseNameToChange = GlobalDatabaseConnectionContainer.getDatabaseConnection().getUserWithID(userID);
                    final String oldName = userWhoseNameToChange.getName();
                    AlertDialog.Builder b = new AlertDialog.Builder(copyOfThis);
                    final EditText editNewUserName = new EditText(copyOfThis);
                    editNewUserName.setHint("Enter new user name");
                    b.setView(editNewUserName);
                    b.setPositiveButton("Change name", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            String newName = editNewUserName.getText().toString();
                            if (newName.length() == 0)
                            {
                                ShowStringDialogFragment.setMessageToDisplay("The user's name can't be 0 characters long.");
                                ShowStringDialogFragment.setPositiveButtonText("OKAY");
                                ShowStringDialogFragment.setOnClickOkay(new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialog, int which) {
                                        //do nothing
                                    }
                                });
                                ShowStringDialogFragment ssdf = new ShowStringDialogFragment();
                                ssdf.show(getFragmentManager(),"");
                            }
                            else
                            {
                                final ProgressDialog pd = new ProgressDialog(copyOfThis);
                                pd.setMessage("Changing " + oldName + "'s name to " + newName);
                                pd.setCancelable(false);
                                pd.show();
                                databaseConnection.updateUserNameCallback uunc = new databaseConnection.updateUserNameCallback() {
                                    @Override
                                    public void onUpdateName() {
                                        pd.cancel();
                                    }
                                };
                                databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                                d.updateNameOfUser(userID,newName,uunc,copyOfThis);
                            }
                        }
                    });
                    b.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //do nothing
                        }
                    });
                    b.show();
                }
            }
        };
        UserSelectionActivity.setUsersToDisplay(GlobalDatabaseConnectionContainer.getDatabaseConnection().getAllUsers());
        Intent chooseUser = new Intent(this,UserSelectionActivity.class);
        startActivityForResult(chooseUser,0);
    }

    public void moderationPanelOnPressAddUserToClub(View view)
    {
        final Context copyOfThis = this;
        cancelOrContinueDialogFragment.setMessageToDisplay("First, choose a user to add to a club.");
        cancelOrContinueDialogFragment.setPositiveButtonText("Continue");
        cancelOrContinueDialogFragment.setNegativeButtonText("Cancel");
        cancelOrContinueDialogFragment.setOnClickNegative(new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //do nothing
            }
        });
        cancelOrContinueDialogFragment.setOnClickPositive(new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                task = new activityResultTask() {
                    @Override
                    public void onResult(int requestCode, int resultCode, Intent data) {
                        if (resultCode == Activity.RESULT_OK)
                        {
                            //the user has now picked a user
                            final int userID = data.getIntExtra(UserSelectionActivity.SELECTED_USER_ID_EXTRA,-1);
                            final User selectedUser = GlobalDatabaseConnectionContainer.getDatabaseConnection().getUserWithID(userID);
                            cancelOrContinueDialogFragment.setMessageToDisplay("Next, choose the club to add the user to.");
                            cancelOrContinueDialogFragment.setPositiveButtonText("Continue");
                            cancelOrContinueDialogFragment.setNegativeButtonText("Cancel");
                            cancelOrContinueDialogFragment.setOnClickNegative(new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //do nothing
                                }
                            });
                            cancelOrContinueDialogFragment.setOnClickPositive(new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //the user is now about to pick a club
                                    task = new activityResultTask() {
                                        @Override
                                        public void onResult(int requestCode, int resultCode, Intent data) {
                                            //the user has now picked a club
                                            if (resultCode == Activity.RESULT_OK)
                                            {
                                                final int clubID = data.getIntExtra(ClubSelectionActivity.SELECTED_CLUB_ID_EXTRA,-1);
                                                final ClubObject selectedClub = GlobalDatabaseConnectionContainer.getDatabaseConnection().getClubWithID(clubID);
                                                cancelOrContinueDialogFragment.setMessageToDisplay("Add " + selectedUser.getName() + " to " + selectedClub.getClubName() + "?");
                                                cancelOrContinueDialogFragment.setPositiveButtonText("Add");
                                                cancelOrContinueDialogFragment.setNegativeButtonText("Cancel");
                                                cancelOrContinueDialogFragment.setOnClickNegative(new DialogInterface.OnClickListener() {
                                                    @Override
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        //do nothing
                                                    }
                                                });
                                                cancelOrContinueDialogFragment.setOnClickPositive(new DialogInterface.OnClickListener() {
                                                    @Override
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        //it is now adding the user to the club
                                                        final ProgressDialog pd = new ProgressDialog(copyOfThis);
                                                        pd.setMessage("Adding " + selectedUser.getName() + " to " + selectedClub.getClubName() + "...");
                                                        pd.setCancelable(false);
                                                        pd.show();

                                                        databaseConnection.addUserToClubCallback autcc = new databaseConnection.addUserToClubCallback() {
                                                            @Override
                                                            public void onAddUser() {
                                                                //the user has now been added to the club
                                                                pd.cancel();
                                                            }
                                                        };
                                                        databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                                                        d.addUserToClub(userID,clubID,autcc,copyOfThis);
                                                    }
                                                });
                                                cancelOrContinueDialogFragment cocdf = new cancelOrContinueDialogFragment();
                                                cocdf.show(getFragmentManager(),"");
                                            }
                                        }
                                    };
                                    ClubSelectionActivity.setClubsToDisplay(selectedUser.getClubsThisUserIsNotInAndIsNotALeaderOf(GlobalDatabaseConnectionContainer.getDatabaseConnection().getAllClubs()));
                                    Intent nextChooseClub = new Intent(copyOfThis,ClubSelectionActivity.class);
                                    startActivityForResult(nextChooseClub,0);
                                }
                            });
                            cancelOrContinueDialogFragment cocdf = new cancelOrContinueDialogFragment();
                            cocdf.show(getFragmentManager(),"");
                        }
                    }
                };
                UserSelectionActivity.setUsersToDisplay(GlobalDatabaseConnectionContainer.getDatabaseConnection().getAllUsers());
                Intent firstChooseUser = new Intent(copyOfThis,UserSelectionActivity.class);
                startActivityForResult(firstChooseUser,0);
            }
        });
        cancelOrContinueDialogFragment cocdf = new cancelOrContinueDialogFragment();
        cocdf.show(getFragmentManager(),"");
    }

    public void moderationPanelOnPressRemoveUserFromClub(View view)
    {
        final Context copyOfThis = this;
        cancelOrContinueDialogFragment.setMessageToDisplay("First, choose a club to remove a user from.");
        cancelOrContinueDialogFragment.setPositiveButtonText("Continue");
        cancelOrContinueDialogFragment.setNegativeButtonText("Cancel");
        cancelOrContinueDialogFragment.setOnClickNegative(new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //do nothing
            }
        });
        cancelOrContinueDialogFragment.setOnClickPositive(new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //the user is now picking a club
                task = new activityResultTask() {
                    @Override
                    public void onResult(int requestCode, int resultCode, Intent data) {
                        if (resultCode == Activity.RESULT_OK)
                        {
                            //the user has now selected a club
                            final int clubID = data.getIntExtra(ClubSelectionActivity.SELECTED_CLUB_ID_EXTRA,-1);
                            final ClubObject selectedClub = GlobalDatabaseConnectionContainer.getDatabaseConnection().getClubWithID(clubID);
                            cancelOrContinueDialogFragment.setMessageToDisplay("Next, choose the user to remove from this club.");
                            cancelOrContinueDialogFragment.setPositiveButtonText("Continue");
                            cancelOrContinueDialogFragment.setNegativeButtonText("Cancel");
                            cancelOrContinueDialogFragment.setOnClickNegative(new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //do nothing
                                }
                            });
                            cancelOrContinueDialogFragment.setOnClickPositive(new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //the user is now picking a user
                                    task = new activityResultTask() {
                                        @Override
                                        public void onResult(int requestCode, int resultCode, Intent data) {
                                            //the user has now picked a user
                                            if (resultCode == Activity.RESULT_OK)
                                            {
                                                final int userID = data.getIntExtra(UserSelectionActivity.SELECTED_USER_ID_EXTRA,-1);
                                                final User selectedUser = GlobalDatabaseConnectionContainer.getDatabaseConnection().getUserWithID(userID);
                                                cancelOrContinueDialogFragment.setMessageToDisplay("Remove " + selectedUser.getName() + " from " + selectedClub.getClubName() + "?");
                                                cancelOrContinueDialogFragment.setPositiveButtonText("Remove");
                                                cancelOrContinueDialogFragment.setNegativeButtonText("Cancel");
                                                cancelOrContinueDialogFragment.setOnClickNegative(new DialogInterface.OnClickListener() {
                                                    @Override
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        //do nothing
                                                    }
                                                });
                                                cancelOrContinueDialogFragment.setOnClickPositive(new DialogInterface.OnClickListener() {
                                                    @Override
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        //it is now removing the user from the club
                                                        final ProgressDialog pd = new ProgressDialog(copyOfThis);
                                                        pd.setMessage("Removing " + selectedUser.getName() + " from " + selectedClub.getClubName() + "...");
                                                        pd.setCancelable(false);
                                                        pd.show();
                                                        databaseConnection.removeUserFromClubCallback rufcc = new databaseConnection.removeUserFromClubCallback() {
                                                            @Override
                                                            public void onRemoveUser() {
                                                                pd.cancel();
                                                            }
                                                        };
                                                        databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                                                        d.removeUserFromClub(userID,clubID,rufcc,copyOfThis);
                                                    }
                                                });
                                                cancelOrContinueDialogFragment cocdf = new cancelOrContinueDialogFragment();
                                                cocdf.show(getFragmentManager(),"");
                                            }
                                        }
                                    };
                                    UserSelectionActivity.setUsersToDisplay(selectedClub.getMembersOrLeaders());
                                    Intent nextChooseUser = new Intent(copyOfThis,UserSelectionActivity.class);
                                    startActivityForResult(nextChooseUser,0);
                                }
                            });

                            cancelOrContinueDialogFragment cocdf = new cancelOrContinueDialogFragment();
                            cocdf.show(getFragmentManager(),"");
                        }
                    }
                };
                ClubSelectionActivity.setClubsToDisplay(GlobalDatabaseConnectionContainer.getDatabaseConnection().getAllClubs());
                Intent firstChooseClub = new Intent(copyOfThis,ClubSelectionActivity.class);
                startActivityForResult(firstChooseClub,0);
            }
        });
        cancelOrContinueDialogFragment cocdf = new cancelOrContinueDialogFragment();
        cocdf.show(getFragmentManager(),"");
    }

    public void moderationPanelOnPressPromoteUserToClubLeader(View view)
    {
        final Context copyOfThis = this;
        cancelOrContinueDialogFragment.setMessageToDisplay("First, choose a user to be promoted to a club leader.");
        cancelOrContinueDialogFragment.setPositiveButtonText("Continue");
        cancelOrContinueDialogFragment.setNegativeButtonText("Cancel");
        cancelOrContinueDialogFragment.setOnClickNegative(new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //do nothing
            }
        });
        cancelOrContinueDialogFragment.setOnClickPositive(new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                task = new activityResultTask() {
                    @Override
                    public void onResult(int requestCode, int resultCode, Intent data) {
                        if (resultCode == Activity.RESULT_OK)
                        {
                            //the user has now picked a user
                            final int userID = data.getIntExtra(UserSelectionActivity.SELECTED_USER_ID_EXTRA,-1);
                            final User selectedUser = GlobalDatabaseConnectionContainer.getDatabaseConnection().getUserWithID(userID);
                            cancelOrContinueDialogFragment.setMessageToDisplay("Next, choose the club for the user to be a leader of.");
                            cancelOrContinueDialogFragment.setPositiveButtonText("Continue");
                            cancelOrContinueDialogFragment.setNegativeButtonText("Cancel");
                            cancelOrContinueDialogFragment.setOnClickNegative(new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //do nothing
                                }
                            });
                            cancelOrContinueDialogFragment.setOnClickPositive(new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //the user is now about to pick a club
                                    task = new activityResultTask() {
                                        @Override
                                        public void onResult(int requestCode, int resultCode, Intent data) {
                                            //the user has now picked a club
                                            if (resultCode == Activity.RESULT_OK)
                                            {
                                                final int clubID = data.getIntExtra(ClubSelectionActivity.SELECTED_CLUB_ID_EXTRA,-1);
                                                final ClubObject selectedClub = GlobalDatabaseConnectionContainer.getDatabaseConnection().getClubWithID(clubID);
                                                cancelOrContinueDialogFragment.setMessageToDisplay("Promote " + selectedUser.getName() + " to a leader of " + selectedClub.getClubName() + "?");
                                                cancelOrContinueDialogFragment.setPositiveButtonText("Promote");
                                                cancelOrContinueDialogFragment.setNegativeButtonText("Cancel");
                                                cancelOrContinueDialogFragment.setOnClickNegative(new DialogInterface.OnClickListener() {
                                                    @Override
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        //do nothing
                                                    }
                                                });
                                                cancelOrContinueDialogFragment.setOnClickPositive(new DialogInterface.OnClickListener() {
                                                    @Override
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        //it is now adding the user to the club
                                                        final ProgressDialog pd = new ProgressDialog(copyOfThis);
                                                        pd.setMessage("Promoting " + selectedUser.getName() + " to a leader of " + selectedClub.getClubName() + "...");
                                                        pd.setCancelable(false);
                                                        pd.show();

                                                        databaseConnection.addLeaderToClubCallback altcc = new databaseConnection.addLeaderToClubCallback() {
                                                            @Override
                                                            public void onAddLeader() {
                                                                pd.cancel();
                                                            }
                                                        };
                                                        databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                                                        d.addLeaderToClub(userID,clubID,altcc,copyOfThis);
                                                    }
                                                });
                                                cancelOrContinueDialogFragment cocdf = new cancelOrContinueDialogFragment();
                                                cocdf.show(getFragmentManager(),"");
                                            }
                                        }
                                    };
                                    ClubSelectionActivity.setClubsToDisplay(selectedUser.getClubsThisUserIsNotALeaderOf(GlobalDatabaseConnectionContainer.getDatabaseConnection().getAllClubs()));
                                    Intent nextChooseClub = new Intent(copyOfThis,ClubSelectionActivity.class);
                                    startActivityForResult(nextChooseClub,0);
                                }
                            });
                            cancelOrContinueDialogFragment cocdf = new cancelOrContinueDialogFragment();
                            cocdf.show(getFragmentManager(),"");
                        }
                    }
                };
                UserSelectionActivity.setUsersToDisplay(GlobalDatabaseConnectionContainer.getDatabaseConnection().getAllUsers());
                Intent firstChooseUser = new Intent(copyOfThis,UserSelectionActivity.class);
                startActivityForResult(firstChooseUser,0);
            }
        });
        cancelOrContinueDialogFragment cocdf = new cancelOrContinueDialogFragment();
        cocdf.show(getFragmentManager(),"");
    }

    public void moderationPanelOnPressRemoveClubLeader(View view)
    {
        final Context copyOfThis = this;
        cancelOrContinueDialogFragment.setMessageToDisplay("First, choose a club to remove a leader from.");
        cancelOrContinueDialogFragment.setPositiveButtonText("Continue");
        cancelOrContinueDialogFragment.setNegativeButtonText("Cancel");
        cancelOrContinueDialogFragment.setOnClickNegative(new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //do nothing
            }
        });
        cancelOrContinueDialogFragment.setOnClickPositive(new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //the user is now picking a club
                task = new activityResultTask() {
                    @Override
                    public void onResult(int requestCode, int resultCode, Intent data) {
                        if (resultCode == Activity.RESULT_OK)
                        {
                            //the user has now selected a club
                            final int clubID = data.getIntExtra(ClubSelectionActivity.SELECTED_CLUB_ID_EXTRA,-1);
                            final ClubObject selectedClub = GlobalDatabaseConnectionContainer.getDatabaseConnection().getClubWithID(clubID);
                            cancelOrContinueDialogFragment.setMessageToDisplay("Next, choose the leader to remove from this club.");
                            cancelOrContinueDialogFragment.setPositiveButtonText("Continue");
                            cancelOrContinueDialogFragment.setNegativeButtonText("Cancel");
                            cancelOrContinueDialogFragment.setOnClickNegative(new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //do nothing
                                }
                            });
                            cancelOrContinueDialogFragment.setOnClickPositive(new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    //the user is now picking a user
                                    task = new activityResultTask() {
                                        @Override
                                        public void onResult(int requestCode, int resultCode, Intent data) {
                                            //the user has now picked a user
                                            if (resultCode == Activity.RESULT_OK)
                                            {
                                                final int userID = data.getIntExtra(UserSelectionActivity.SELECTED_USER_ID_EXTRA,-1);
                                                final User selectedUser = GlobalDatabaseConnectionContainer.getDatabaseConnection().getUserWithID(userID);
                                                cancelOrContinueDialogFragment.setMessageToDisplay("Remove " + selectedUser.getName() + " from leadership of " + selectedClub.getClubName() + "?");
                                                cancelOrContinueDialogFragment.setPositiveButtonText("Remove");
                                                cancelOrContinueDialogFragment.setNegativeButtonText("Cancel");
                                                cancelOrContinueDialogFragment.setOnClickNegative(new DialogInterface.OnClickListener() {
                                                    @Override
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        //do nothing
                                                    }
                                                });
                                                cancelOrContinueDialogFragment.setOnClickPositive(new DialogInterface.OnClickListener() {
                                                    @Override
                                                    public void onClick(DialogInterface dialog, int which) {
                                                        //it is now removing the user from the club
                                                        final ProgressDialog pd = new ProgressDialog(copyOfThis);
                                                        pd.setMessage("Removing " + selectedUser.getName() + "'s leadership from " + selectedClub.getClubName() + "...");
                                                        pd.setCancelable(false);
                                                        pd.show();
                                                        databaseConnection.removeLeaderFromClubCallback rlfcc = new databaseConnection.removeLeaderFromClubCallback() {
                                                            @Override
                                                            public void onRemoveLeader() {
                                                                pd.cancel();
                                                            }
                                                        };
                                                        databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                                                        d.removeLeaderFromClub(userID,clubID,rlfcc,copyOfThis);
                                                    }
                                                });
                                                cancelOrContinueDialogFragment cocdf = new cancelOrContinueDialogFragment();
                                                cocdf.show(getFragmentManager(),"");
                                            }
                                        }
                                    };
                                    UserSelectionActivity.setUsersToDisplay(selectedClub.getLeaders());
                                    Intent nextChooseUser = new Intent(copyOfThis,UserSelectionActivity.class);
                                    startActivityForResult(nextChooseUser,0);
                                }
                            });

                            cancelOrContinueDialogFragment cocdf = new cancelOrContinueDialogFragment();
                            cocdf.show(getFragmentManager(),"");
                        }
                    }
                };
                ClubSelectionActivity.setClubsToDisplay(GlobalDatabaseConnectionContainer.getDatabaseConnection().getAllClubs());
                Intent firstChooseClub = new Intent(copyOfThis,ClubSelectionActivity.class);
                startActivityForResult(firstChooseClub,0);
            }
        });
        cancelOrContinueDialogFragment cocdf = new cancelOrContinueDialogFragment();
        cocdf.show(getFragmentManager(),"");
    }

    public void moderationPanelOnPressPromoteUserToModerator(View view)
    {
        final Context copyOfThis = this;
        task = new activityResultTask() {
            @Override
            public void onResult(int requestCode, int resultCode, Intent data) {
                if (resultCode == Activity.RESULT_OK)
                {
                    final int userID = data.getIntExtra(UserSelectionActivity.SELECTED_USER_ID_EXTRA,-1);
                    final User selectedUser = GlobalDatabaseConnectionContainer.getDatabaseConnection().getUserWithID(userID);
                    cancelOrContinueDialogFragment.setMessageToDisplay("Are you sure you want " + selectedUser.getName() + " to be a moderator? You would be giving them the ability to cause a lot of trouble.");
                    cancelOrContinueDialogFragment.setPositiveButtonText("Trust");
                    cancelOrContinueDialogFragment.setNegativeButtonText("Cancel");
                    cancelOrContinueDialogFragment.setOnClickNegative(new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //do nothing
                        }
                    });
                    cancelOrContinueDialogFragment.setOnClickPositive(new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            final ProgressDialog pd = new ProgressDialog(copyOfThis);
                            pd.setMessage("Promoting " + selectedUser.getName() + " to a moderator...");
                            pd.setCancelable(false);
                            pd.show();
                            databaseConnection.updateUserRankCallback uurc = new databaseConnection.updateUserRankCallback() {
                                @Override
                                public void onUpdateRank() {
                                    pd.cancel();
                                }
                            };
                            databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                            d.updateRankOfUser(userID, User.Rank.MODERATOR,uurc,copyOfThis);
                        }
                    });
                    cancelOrContinueDialogFragment cocdf = new cancelOrContinueDialogFragment();
                    cocdf.show(getFragmentManager(),"");
                }
            }
        };
        UserSelectionActivity.setUsersToDisplay(GlobalDatabaseConnectionContainer.getDatabaseConnection().getAllUsersWhoAreNotModerators());
        Intent selectNonModerator = new Intent(this,UserSelectionActivity.class);
        startActivityForResult(selectNonModerator,0);
    }

    public void moderationPanelOnPressDemoteUserFromModerator(View view)
    {
        final Context copyOfThis = this;
        task = new activityResultTask() {
            @Override
            public void onResult(int requestCode, int resultCode, Intent data) {
                if (resultCode == Activity.RESULT_OK)
                {
                    final int userID = data.getIntExtra(UserSelectionActivity.SELECTED_USER_ID_EXTRA,-1);
                    final User selectedUser = GlobalDatabaseConnectionContainer.getDatabaseConnection().getUserWithID(userID);
                    cancelOrContinueDialogFragment.setMessageToDisplay("Demote " + selectedUser.getName() + " from moderator?");
                    cancelOrContinueDialogFragment.setPositiveButtonText("Demote");
                    cancelOrContinueDialogFragment.setNegativeButtonText("Cancel");
                    cancelOrContinueDialogFragment.setOnClickNegative(new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //do nothing
                        }
                    });
                    cancelOrContinueDialogFragment.setOnClickPositive(new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            final ProgressDialog pd = new ProgressDialog(copyOfThis);
                            pd.setMessage("Demoting " + selectedUser.getName() + " from moderator...");
                            pd.setCancelable(false);
                            pd.show();
                            databaseConnection.updateUserRankCallback uurc = new databaseConnection.updateUserRankCallback() {
                                @Override
                                public void onUpdateRank() {
                                    pd.cancel();
                                }
                            };
                            databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                            d.updateRankOfUser(userID, User.Rank.USER,uurc,copyOfThis);
                        }
                    });
                    cancelOrContinueDialogFragment cocdf = new cancelOrContinueDialogFragment();
                    cocdf.show(getFragmentManager(),"");
                }
            }
        };
        UserSelectionActivity.setUsersToDisplay(GlobalDatabaseConnectionContainer.getDatabaseConnection().getAllUsersWhoAreModerators());
        Intent selectNonModerator = new Intent(this,UserSelectionActivity.class);
        startActivityForResult(selectNonModerator,0);
    }
}
