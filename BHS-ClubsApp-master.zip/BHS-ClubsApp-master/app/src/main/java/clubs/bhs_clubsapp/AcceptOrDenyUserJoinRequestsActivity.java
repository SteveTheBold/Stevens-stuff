package clubs.bhs_clubsapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by super on 6/8/2017.
 */

public class AcceptOrDenyUserJoinRequestsActivity extends AppCompatActivity {

    protected void onCreate(Bundle SavedInstanceState)
    {
        super.onCreate(SavedInstanceState);
        setContentView(R.layout.activity_accept_deny_requests);
        Intent intent = getIntent();
        int clubID = intent.getIntExtra(ClubManagementPage.CLUB_ID_NAME,-1);
        ClubObject thisClub = GlobalDatabaseConnectionContainer.getDatabaseConnection().getClubWithID(clubID);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        //ArrayList<User> pendingJoinUsers = thisClub.getPendingJoinUsers();

        ListView pendingJoinUserListView = (ListView) findViewById(R.id.pendingJoinUserListView);
        UserJoinRequestItemAdapter adapter = new UserJoinRequestItemAdapter(this,thisClub);
        pendingJoinUserListView.setAdapter(adapter);
    }
}
