package clubs.bhs_clubsapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.InputFilter;
import android.text.InputType;
import android.text.Spanned;
import android.text.method.PasswordTransformationMethod;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import java.util.ArrayList;

/**
 * Created by bal_tascofield on 6/1/2017.
 */

public class FirstLaunchGetUserIDActivity extends AppCompatActivity{

    public static boolean BLOCK_NON_LETTER_USERNAMES = true;
    private static boolean BLOCK_SPACES_AND_NEWLINES_IN_SECRET_PASSWORD = true;
    private static boolean HIDE_PASSWORD_WHILE_EDITING = true;

    private enum Mode{
        CREATE_NEW_ID, USE_OLD_ID
    }

    private Mode mode = Mode.CREATE_NEW_ID;

    public static InputFilter newUsernameFilter = new InputFilter() {
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            if (source != null)
            {
                String r = "";
                for (int i = 0; i < source.length(); i++)
                {
                    char c = source.charAt(i);
                    boolean isLetter = Character.isLetter(c);
                    boolean isSpace = Character.isSpaceChar(c);
                    if (isLetter || isSpace)
                    {
                        r = r + c;
                        //filter out characters that aren't spaces or letters
                    }
                }
                return r;
            }
            return null;
        }
    };
    //block the user from entering characters which aren't spaces or letter as part of their username

    private static InputFilter secretPasswordFilter = new InputFilter() {
        @Override
        public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
            if (source != null) {
                String r = "";
                for (int i = 0; i < source.length(); i++) {
                    char c = source.charAt(i);
                    boolean isSpace = Character.isSpaceChar(c);
                    boolean isNewline = (c == '\n');
                    if (!isSpace && !isNewline) {
                        r = r + c;
                        //filter out characters that aren't spaces or letters
                    }
                }
                return r;
            }
            return null;
        }
    };
    //block the user from entering newlines or spaces as part of the password

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.get_user_id_on_launch_activity);
        Spinner chooseLoginActionSpinner = (Spinner) findViewById(R.id.choose_login_action_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.identification_options_array,android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        chooseLoginActionSpinner.setAdapter(adapter);
        chooseLoginActionSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String s = (String) parent.getItemAtPosition(position);
                EditText editStuff = (EditText) findViewById(R.id.editStuff);
                editStuff.setText("");
                if (s.equals(getResources().getStringArray(R.array.identification_options_array)[0]))
                {
                    mode = Mode.CREATE_NEW_ID;
                }
                else //if (s.equals(getResources().getStringArray(R.array.identification_options_array)[1]))
                {
                    mode = Mode.USE_OLD_ID;
                }
                updateByMode();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                //do nothing
            }
        });
        Intent I = new Intent();
        setResult(RESULT_OK,I);
    }

    private void updateByMode()
    {
        Button submitButton = (Button) findViewById(R.id.submitIdentityButton);
        EditText editStuff = (EditText) findViewById(R.id.editStuff);

        switch(mode)
        {
            case CREATE_NEW_ID:
                submitButton.setText("Submit username");
                editStuff.setHint("Username of new identity goes here");
                if (BLOCK_NON_LETTER_USERNAMES)
                {
                    editStuff.setFilters(new InputFilter[]{newUsernameFilter});
                }
                editStuff.setTransformationMethod(null);
                break;
            case USE_OLD_ID:
                submitButton.setText("Submit secret password of old identity");
                editStuff.setHint("Secret password goes here");
                if (BLOCK_SPACES_AND_NEWLINES_IN_SECRET_PASSWORD)
                {
                    editStuff.setFilters(new InputFilter[]{secretPasswordFilter});
                }
                if (HIDE_PASSWORD_WHILE_EDITING)
                {
                    editStuff.setInputType(InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    editStuff.setTransformationMethod(PasswordTransformationMethod.getInstance());
                }
        }
    }

    public void onPressSubmitButton(View v)
    {
        String s = ((EditText) findViewById(R.id.editStuff)).getText().toString();
        switch(mode)
        {
            case CREATE_NEW_ID:
                createNewID(s);
                break;
            case USE_OLD_ID:
                submitSecretPassword(s);
                break;
        }
    }


    public void createNewID(final String enteredName)
    {
        if (GlobalDatabaseConnectionContainer.databaseHasInitialized())
        {
            createNewUserWhenTheDatabaseHasInitialized(enteredName);
        }
        else
        {
            GlobalDatabaseConnectionContainer.globalDatabaseInitializationCallback gdic = new GlobalDatabaseConnectionContainer.globalDatabaseInitializationCallback() {
                @Override
                public void onFinishedInitializing() {
                    createNewUserWhenTheDatabaseHasInitialized(enteredName);
                }
            };
            GlobalDatabaseConnectionContainer.setGlobalDatabaseInitializationCallback(gdic);
        }
    }

    private void createNewUserWhenTheDatabaseHasInitialized(final String newUsername)
    {
        if (newUsername.length() == 0)
        {
            ShowStringDialogFragment.setMessageToDisplay("Your username can't be 0 characters long.");
            ShowStringDialogFragment.setPositiveButtonText("OKAY.");
            ShowStringDialogFragment.setOnClickOkay(new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //do nothing
                }
            });
            ShowStringDialogFragment ssdf = new ShowStringDialogFragment();
            ssdf.show(getFragmentManager(),"");
        }
        else
        {
            cancelOrContinueDialogFragment.setMessageToDisplay("Create a new identity with the username \"" + newUsername + "\"?");
            cancelOrContinueDialogFragment.setPositiveButtonText("Create");
            cancelOrContinueDialogFragment.setNegativeButtonText("Cancel");
            cancelOrContinueDialogFragment.setOnClickNegative(new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //do nothing
                }
            });
            cancelOrContinueDialogFragment.setOnClickPositive(new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                    databaseConnection.addUserCallback auc = new databaseConnection.addUserCallback() {
                        @Override
                        public void onAdd(int idOfNewUser, String generatedSecretPassword) {
                            GlobalDatabaseConnectionContainer.setUserID(idOfNewUser,getBaseContext());
                            ShowStringDialogFragment.setMessageToDisplay("Your secret password is the following: " + generatedSecretPassword
                                    + " (you might want to write that down)");
                            ShowStringDialogFragment.setPositiveButtonText("OK");
                            ShowStringDialogFragment.setOnClickOkay(new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    finish();
                                }
                            });
                            ShowStringDialogFragment ssdf = new ShowStringDialogFragment();
                            ssdf.show(getFragmentManager(),"");
                        }
                    };
                    d.addUser(newUsername,auc,getBaseContext());
                }
            });
            cancelOrContinueDialogFragment cocdf = new cancelOrContinueDialogFragment();
            cocdf.show(getFragmentManager(),"");
        }
    }

    public void submitSecretPassword(final String password)
    {
        if (GlobalDatabaseConnectionContainer.databaseHasInitialized())
        {
            testValidityOfPasswordWhenDatabaseHasInitialized(password);
        }
        else
        {
            GlobalDatabaseConnectionContainer.globalDatabaseInitializationCallback gdic = new GlobalDatabaseConnectionContainer.globalDatabaseInitializationCallback() {
                @Override
                public void onFinishedInitializing() {
                    testValidityOfPasswordWhenDatabaseHasInitialized(password);
                }
            };
            GlobalDatabaseConnectionContainer.setGlobalDatabaseInitializationCallback(gdic);
        }
    }

    private void testValidityOfPasswordWhenDatabaseHasInitialized(String password)
    {
        databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
        ArrayList<User> allUsers = d.getAllUsers();
        boolean passwordIsValid = false;
        User userAssociatedWithPassword = null;
        for (User u: allUsers)
        {
            if (u.secretPasswordEquals(password))
            {
                passwordIsValid = true;
                userAssociatedWithPassword = u;
            }
        }
        if (passwordIsValid)
        {
            final int userID = userAssociatedWithPassword.getID();
            GlobalDatabaseConnectionContainer.setUserID(userID,getBaseContext());
            cancelOrContinueDialogFragment.setMessageToDisplay("Password is valid. Continue with your identity as \"" + userAssociatedWithPassword.getName() + "\"?");
            cancelOrContinueDialogFragment.setPositiveButtonText("Continue");
            cancelOrContinueDialogFragment.setNegativeButtonText("Cancel");
            cancelOrContinueDialogFragment.setOnClickNegative(new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //do nothing
                }
            });
            cancelOrContinueDialogFragment.setOnClickPositive(new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    GlobalDatabaseConnectionContainer.setUserID(userID,getBaseContext());
                    finish();
                }
            });
            cancelOrContinueDialogFragment cocdf = new cancelOrContinueDialogFragment();
            cocdf.show(getFragmentManager(),"");
        }
        else
        {
            ShowStringDialogFragment.setMessageToDisplay("Invalid password.");
            ShowStringDialogFragment.setOnClickOkay(new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    //do nothing
                }
            });
            ShowStringDialogFragment.setPositiveButtonText("OK");
            ShowStringDialogFragment ssdf = new ShowStringDialogFragment();
            ssdf.show(getFragmentManager(),"");
        }
    }

}
