package clubs.bhs_clubsapp;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by super on 6/11/2017.
 */

public class EditClubProfileActivity extends AppCompatActivity {

    public static String CLUB_PROFILE_CLUB_ID_EXTRA_NAME = "clubID";

    private static String EMPTY_DESCRIPTION = "[No Description]";
    private static String EMPTY_LOCATION = "[No Location]";
    private static String EMPTY_MEETING_TIME = "[No Meeting Times]";
    private static String EMPTY_IMAGE_PATH = "[No Image Path]";

    private int clubID;
    private ClubObject thisClub;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_club_profile);
        Intent i = getIntent();
        clubID = i.getIntExtra(CLUB_PROFILE_CLUB_ID_EXTRA_NAME,-1);
        resetEverything();
    }

    public void resetEverything()
    {
        resetClubObject();
        resetClubNameTextView();
        resetClubDescriptionTextView();
        resetClubLocationTextView();
        resetClubMeetingTimeTextView();
        resetClubImagePathTextView();
    }

    public void resetClubObject()
    {
        thisClub = GlobalDatabaseConnectionContainer.getDatabaseConnection().getClubWithID(clubID);
    }

    public void resetClubNameTextView()
    {
        String clubName = thisClub.getClubName();
        TextView clubProfileClubNameTextView = (TextView) findViewById(R.id.clubProfileClubNameTextView);
        clubProfileClubNameTextView.setText(clubName);
    }

    public void resetClubDescriptionTextView()
    {
        String clubDescription = thisClub.getDescription();
        TextView clubProfileClubDescriptionTextView = (TextView) findViewById(R.id.clubProfileClubDescriptionTextView);
        String clubDescriptionDisplay;
        if (clubDescription.length() == 0)
        {
            clubDescriptionDisplay = EMPTY_DESCRIPTION;
        }
        else
        {
            clubDescriptionDisplay = clubDescription;
        }
        clubProfileClubDescriptionTextView.setText(clubDescriptionDisplay);
    }

    public void resetClubLocationTextView()
    {
        String clubLocation = thisClub.getLocation();
        TextView clubProfileClubLocationTextView = (TextView) findViewById(R.id.clubProfileClubLocationTextView);
        String clubLocationDisplay;
        if (clubLocation.length() == 0)
        {
            clubLocationDisplay = EMPTY_LOCATION;
        }
        else
        {
            clubLocationDisplay = clubLocation;
        }
        clubProfileClubLocationTextView.setText(clubLocationDisplay);
    }

    public void resetClubMeetingTimeTextView()
    {
        String clubMeetingTime = thisClub.getMeetingTimes();
        TextView clubProfileClubMeetingTimeTextView = (TextView) findViewById(R.id.clubProfileClubMeetingTimesTextView);
        String clubMeetingTimeDisplay;
        if (clubMeetingTime.length() == 0)
        {
            clubMeetingTimeDisplay = EMPTY_MEETING_TIME;
        }
        else
        {
            clubMeetingTimeDisplay = clubMeetingTime;
        }
        clubProfileClubMeetingTimeTextView.setText(clubMeetingTimeDisplay);
    }

    public void resetClubImagePathTextView()
    {
        String clubImagePath = thisClub.getImagePath();
        TextView clubProfileClubImagePathTextView = (TextView) findViewById(R.id.clubProfileClubImagePathTextView);
        String clubImagePathDisplay;
        if (clubImagePath.length() == 0)
        {
            clubImagePathDisplay = EMPTY_IMAGE_PATH;
        }
        else
        {
            clubImagePathDisplay = clubImagePath;
        }
        clubProfileClubImagePathTextView.setText(clubImagePathDisplay);
    }

    public void editClubProfileOnPressBack(View view)
    {
        finish();
    }

    public void editClubProfileOnPressChangeClubName(View view)
    {
        final String oldName = thisClub.getClubName();
        final Context copyOfThis = this;
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        final EditText editNewClubName = new EditText(this);
        editNewClubName.setHint("Enter new club name");
        String initialEditValue = thisClub.getClubName();
        editNewClubName.setText(initialEditValue);
        editNewClubName.setSelection(initialEditValue.length());
        b.setView(editNewClubName);
        b.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //do nothing
            }
        });
        b.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //the user has entered the new name
                String newName = editNewClubName.getText().toString();
                if (newName.length() == 0)
                {
                    ShowStringDialogFragment.setMessageToDisplay("The club's name can't be 0 characters long.");
                    ShowStringDialogFragment.setPositiveButtonText("OK");
                    ShowStringDialogFragment.setOnClickOkay(new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //do nothing
                        }
                    });
                    ShowStringDialogFragment ssdf = new ShowStringDialogFragment();
                    ssdf.show(getFragmentManager(),"");
                }
                else
                {
                    final ProgressDialog pd = new ProgressDialog(copyOfThis);
                    pd.setMessage("Changing " + oldName + "'s name to " + newName + "...");
                    pd.setCancelable(false);
                    pd.show();

                    databaseConnection.updateClubNameCallback ucnc = new databaseConnection.updateClubNameCallback() {
                        @Override
                        public void onUpdateName() {
                            pd.cancel();
                            resetEverything();
                        }
                    };
                    databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                    d.updateNameOfClub(clubID,newName,ucnc,copyOfThis);
                }
            }
        });
        b.show();
    }

    public void editClubProfileOnPressChangeClubDescription(View view)
    {
        final Context copyOfThis = this;
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        final EditText editNewClubDescription = new EditText(this);
        String initialEditValue = thisClub.getDescription();
        editNewClubDescription.setText(initialEditValue);
        editNewClubDescription.setSelection(initialEditValue.length());
        editNewClubDescription.setHint("Enter new club description");
        b.setView(editNewClubDescription);
        b.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //do nothing
            }
        });
        b.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String newDescription = editNewClubDescription.getText().toString();
                final ProgressDialog pd = new ProgressDialog(copyOfThis);
                pd.setMessage("Updating club description...");
                pd.setCancelable(false);
                pd.show();

                databaseConnection.updateClubDescriptionCallback ucdc = new databaseConnection.updateClubDescriptionCallback() {
                    @Override
                    public void onUpdateDescription() {
                        pd.cancel();
                        resetEverything();
                    }
                };
                databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                d.updateDescriptionOfClub(clubID,newDescription,ucdc,copyOfThis);
            }
        });
        b.show();
    }

    public void editClubProfileOnPressChangeClubLocation(View view)
    {
        final Context copyOfThis = this;
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        final EditText editNewClubDescription = new EditText(this);
        String initialEditValue = thisClub.getLocation();
        editNewClubDescription.setText(initialEditValue);
        editNewClubDescription.setSelection(initialEditValue.length());
        editNewClubDescription.setHint("Enter new club location");
        b.setView(editNewClubDescription);
        b.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //do nothing
            }
        });
        b.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String newLocation = editNewClubDescription.getText().toString();
                final ProgressDialog pd = new ProgressDialog(copyOfThis);
                pd.setMessage("Updating club location...");
                pd.setCancelable(false);
                pd.show();

                databaseConnection.updateClubLocationCallback uclc = new databaseConnection.updateClubLocationCallback() {
                    @Override
                    public void onUpdateLocation() {
                        pd.cancel();
                        resetEverything();
                    }
                };
                databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                d.updateClubLocation(clubID,newLocation,uclc,copyOfThis);
            }
        });
        b.show();
    }

    public void editClubProfileOnPressChangeClubMeetingTimes(View view)
    {
        final Context copyOfThis = this;
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        final EditText editNewClubDescription = new EditText(this);
        String initialEditValue = thisClub.getMeetingTimes();
        editNewClubDescription.setText(initialEditValue);
        editNewClubDescription.setSelection(initialEditValue.length());
        editNewClubDescription.setHint("Enter new club meeting times");
        b.setView(editNewClubDescription);
        b.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //do nothing
            }
        });
        b.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String newMeetingTimes = editNewClubDescription.getText().toString();
                final ProgressDialog pd = new ProgressDialog(copyOfThis);
                pd.setMessage("Updating club meeting times...");
                pd.setCancelable(false);
                pd.show();

                databaseConnection.updateClubMeetingTimeCallback ucmtc = new databaseConnection.updateClubMeetingTimeCallback() {
                    @Override
                    public void onUpdateMeetingTime() {
                        pd.cancel();
                        resetEverything();
                    }
                };
                databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                d.updateClubMeetingTime(clubID,newMeetingTimes,ucmtc,copyOfThis);
            }
        });
        b.show();
    }

    public void editClubProfileOnPressChangeImagePath(View view)
    {
        final Context copyOfThis = this;
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        final EditText editNewClubDescription = new EditText(this);
        editNewClubDescription.setHint("Enter new image path");
        b.setView(editNewClubDescription);
        b.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //do nothing
            }
        });
        b.setPositiveButton("Submit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String newImagePath = editNewClubDescription.getText().toString();
                final ProgressDialog pd = new ProgressDialog(copyOfThis);
                pd.setMessage("Updating club image path...");
                pd.setCancelable(false);
                pd.show();
                databaseConnection.updateImagePathCallback uipc = new databaseConnection.updateImagePathCallback() {
                    @Override
                    public void onUpdateImagePath() {
                        pd.cancel();
                        resetEverything();
                    }
                };
                databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                d.updateImagePathOfClub(clubID,newImagePath,uipc,copyOfThis);
            }
        });
        b.show();
    }

    public void editClubProfileOnPressImagePathQuestionMark(View view)
    {
        ShowStringDialogFragment.setMessageToDisplay("You can set this to a link to any image, and it will display that image with the description of your club.");
        ShowStringDialogFragment.setPositiveButtonText("OK");
        ShowStringDialogFragment.setOnClickOkay(new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //do nothing
            }
        });
        ShowStringDialogFragment ssdf = new ShowStringDialogFragment();
        ssdf.show(getFragmentManager(),"");
    }
}
