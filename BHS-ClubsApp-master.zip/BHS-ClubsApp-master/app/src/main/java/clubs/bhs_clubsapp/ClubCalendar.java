package clubs.bhs_clubsapp;

import java.util.ArrayList;

/**
 * Created by bal_tascofield on 5/19/2017.
 */

public class ClubCalendar {

    private ArrayList<CalendarEvent> events;

    public ClubCalendar(ArrayList<CalendarEvent> events)
    {
        this.events = events;
    }

    public ArrayList<CalendarEvent> getEvents(){return events;}
}
