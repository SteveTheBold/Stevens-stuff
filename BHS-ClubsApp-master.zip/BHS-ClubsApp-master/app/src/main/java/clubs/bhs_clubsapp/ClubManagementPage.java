package clubs.bhs_clubsapp;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

import static clubs.bhs_clubsapp.GlobalDatabaseConnectionContainer.getDatabaseConnection;

/**
 * Created by bal_sjtestone001 on 5/17/2017.
 */

public class ClubManagementPage extends AppCompatActivity {

    public static String CLUB_ID_NAME = "ClubID";


    public int clubID;
    public ClubObject thisClub;

    private activityResultTask task = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.club_mangment);
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        Intent intent = getIntent();
        clubID = intent.getIntExtra("ClubId",-1);
        resetEverything();
    }

    public void resetEverything()
    {
        resetClubObject();
        resetMemberList();
    }

    public void resetClubObject()
    {
        thisClub = GlobalDatabaseConnectionContainer.getDatabaseConnection().getClubWithID(clubID);
    }

    public void resetMemberList()
    {
        ListView userList = (ListView) findViewById(R.id.memberList);
        MembersUserListItemAdapter mulia = new MembersUserListItemAdapter(this,thisClub);
        userList.setAdapter(mulia);
    }

    private interface activityResultTask{
        void onResult(int requestCode, int resultCode, Intent data);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (task != null)
        {
            task.onResult(requestCode,resultCode,data);
        }
    }

    public void clubManagementPressEditProfileButton(View view)
    {
        Intent goEditProfile = new Intent(this,EditClubProfileActivity.class);
        goEditProfile.putExtra(EditClubProfileActivity.CLUB_PROFILE_CLUB_ID_EXTRA_NAME,thisClub.getID());
        startActivity(goEditProfile);
    }

    public void pressManageJoinRequests(View view)
    {
        Intent intent = new Intent(this,AcceptOrDenyUserJoinRequestsActivity.class);
        intent.putExtra(CLUB_ID_NAME,thisClub.getID());
        startActivity(intent);
    }

    public void takeAttendance(View view){
        Intent intent = new Intent(this,ClubAttendanceActivity.class);
        intent.putExtra("ClubId",clubID);
        startActivity(intent);
    }

    public void clubManagementPressAddNewLeader(View view)
    {
        final Context copyOfThis = this;
        task = new activityResultTask() {
            @Override
            public void onResult(int requestCode, int resultCode, Intent data) {
                if (resultCode == Activity.RESULT_OK)
                {
                    final int userID = data.getIntExtra(UserSelectionActivity.SELECTED_USER_ID_EXTRA,-1);
                    final User selectedUser = GlobalDatabaseConnectionContainer.getDatabaseConnection().getUserWithID(userID);
                    cancelOrContinueDialogFragment.setMessageToDisplay("Promote " + selectedUser.getName() + " to a leader of " + thisClub.getClubName() + "?");
                    cancelOrContinueDialogFragment.setPositiveButtonText("Trust");
                    cancelOrContinueDialogFragment.setNegativeButtonText("Cancel");
                    cancelOrContinueDialogFragment.setOnClickNegative(new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //do nothing
                        }
                    });
                    cancelOrContinueDialogFragment.setOnClickPositive(new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            final ProgressDialog pd = new ProgressDialog(copyOfThis);
                            pd.setMessage("Promoting " + selectedUser.getName() + " to a leader of " + thisClub.getClubName() + "...");
                            pd.setCancelable(false);
                            pd.show();
                            databaseConnection.addLeaderToClubCallback altcc = new databaseConnection.addLeaderToClubCallback() {
                                @Override
                                public void onAddLeader() {
                                    pd.cancel();
                                    resetEverything();
                                }
                            };
                            databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                            d.addLeaderToClub(userID,clubID,altcc,copyOfThis);
                        }
                    });
                    cancelOrContinueDialogFragment cocdf = new cancelOrContinueDialogFragment();
                    cocdf.show(getFragmentManager(),"");
                }
            }
        };
        UserSelectionActivity.setUsersToDisplay(thisClub.getMembersWhoAreNotLeaders());
        Intent chooseUser = new Intent(this,UserSelectionActivity.class);
        startActivityForResult(chooseUser,0);
    }

    public void clubManagementPressRemoveClubLeader(View view)
    {
        final Context copyOfThis = this;
        task = new activityResultTask() {
            @Override
            public void onResult(int requestCode, int resultCode, Intent data) {
                if (resultCode == Activity.RESULT_OK)
                {
                    final int userID = data.getIntExtra(UserSelectionActivity.SELECTED_USER_ID_EXTRA,-1);
                    final User selectedUser = GlobalDatabaseConnectionContainer.getDatabaseConnection().getUserWithID(userID);
                    cancelOrContinueDialogFragment.setMessageToDisplay("Remove " + selectedUser.getName() + " from the leadership of " + thisClub.getClubName() + "?");
                    cancelOrContinueDialogFragment.setPositiveButtonText("Remove");
                    cancelOrContinueDialogFragment.setNegativeButtonText("Cancel");
                    cancelOrContinueDialogFragment.setOnClickNegative(new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //do nothing
                        }
                    });
                    cancelOrContinueDialogFragment.setOnClickPositive(new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            final ProgressDialog pd = new ProgressDialog(copyOfThis);
                            pd.setMessage("Removing " + selectedUser.getName() + " from the leadership of " + thisClub.getClubName() + "...");
                            pd.setCancelable(false);
                            pd.show();
                            databaseConnection.removeLeaderFromClubCallback rlfcc = new databaseConnection.removeLeaderFromClubCallback() {
                                @Override
                                public void onRemoveLeader() {
                                    pd.cancel();
                                    resetEverything();
                                }
                            };
                            databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                            d.removeLeaderFromClub(userID,clubID,rlfcc,copyOfThis);
                        }
                    });
                    cancelOrContinueDialogFragment cocdf = new cancelOrContinueDialogFragment();
                    cocdf.show(getFragmentManager(),"");
                }
            }
        };
        UserSelectionActivity.setUsersToDisplay(thisClub.getLeaders());
        Intent chooseUser = new Intent(this,UserSelectionActivity.class);
        startActivityForResult(chooseUser,0);
    }



}
