package clubs.bhs_clubsapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by super on 6/11/2017.
 */

public class UserSelectionAdapter extends BaseAdapter {

    private ArrayList<User> users;
    private UserSelectionAdapter.onUserSelectedListener onSelected;
    private Context c;
    private LinearLayout previousSelectedLinearLayout = null;

    public interface onUserSelectedListener{
        void onUserSelected(int clubID);
    }

    public UserSelectionAdapter(ArrayList<User> users, Context c, UserSelectionAdapter.onUserSelectedListener onSelected)
    {
        this.users = users;
        this.c = c;
        this.onSelected = onSelected;
    }

    public View getView(int i, View view, ViewGroup vg)
    {
        LayoutInflater layoutInflater = LayoutInflater.from(c);
        view = layoutInflater.inflate(R.layout.user_selection_list_item,null);

        final User thisUser = users.get(i);
        final TextView user_selection_list_item_user_name_textView = (TextView) view.findViewById(R.id.user_selection_list_item_user_name_textView);
        final LinearLayout ll = (LinearLayout) view.findViewById(R.id.UserSelectionListItemLinearLayout);
        user_selection_list_item_user_name_textView.setText(thisUser.getName());
        View.OnClickListener onClick = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (previousSelectedLinearLayout != null)
                {
                    previousSelectedLinearLayout.setBackgroundColor(c.getResources().getColor(R.color.red));
                }
                ll.setBackgroundColor(c.getResources().getColor(R.color.blue));
                previousSelectedLinearLayout = ll;
                if (onSelected != null)
                {
                    onSelected.onUserSelected(thisUser.getID());
                }
            }
        };
        ll.setOnClickListener(onClick);

        return view;
    }


    public long getItemId(int i){return users.get(i).getID();}

    public int getCount(){return users.size();}

    public Object getItem(int position) {
        return null;
    }
}
