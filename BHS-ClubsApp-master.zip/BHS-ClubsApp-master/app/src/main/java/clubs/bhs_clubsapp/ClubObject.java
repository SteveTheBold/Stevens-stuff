package clubs.bhs_clubsapp;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

/**
 * Created by bal_sjtestone001 on 5/5/2017.
 */

public class ClubObject implements Parcelable {


    private ArrayList<User> members;
    private ArrayList<User> leaders;
    private String description;
    private String clubName;
    private int ID;
    private ArrayList<User> pendingJoinUsers;
    private String imagePath;
    private ClubCalendar calendar;
    private String location;
    private String meetingTime;
    private ClubAttendanceObject attendace;

    public ClubObject(ArrayList<User> members, ArrayList<User> leaders, String description, String clubName, int ID, ArrayList<User> pendingJoinUsers, String imagePath, ClubCalendar calendar, String location, String meetingTime,ClubAttendanceObject attendace)
    {
        this.members = members;
        this.leaders = leaders;
        this.description = description;
        this.clubName = clubName;
        this.ID = ID;
        this.pendingJoinUsers = pendingJoinUsers;
        this.imagePath = imagePath;
        this.calendar = calendar;
        this.location = location;
        this.meetingTime = meetingTime;
        this.attendace = attendace;
    }

    protected ClubObject(Parcel in) {
        members = in.readArrayList(ClassLoader.getSystemClassLoader());
        leaders = in.readArrayList(ClassLoader.getSystemClassLoader());
        description = in.readString();
        clubName = in.readString();
        ID = in.readInt();
        pendingJoinUsers = in.readArrayList(ClassLoader.getSystemClassLoader());
    }

    public static final Creator<ClubObject> CREATOR = new Creator<ClubObject>() {
        @Override
        public ClubObject createFromParcel(Parcel in) {
            return new ClubObject(in);
        }

        @Override
        public ClubObject[] newArray(int size) {
            return new ClubObject[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

        dest.writeInt(ID);
        dest.writeString(clubName);
        dest.writeString(description);

    }


    public ArrayList<User> getMembers(){return members;}
    public ArrayList<User> getLeaders(){return leaders;}
    public String getDescription(){return description;}
    public String getClubName(){return clubName;}
    public int getID(){return ID;}
    public ArrayList<User> getPendingJoinUsers(){return pendingJoinUsers;}
    public String getImagePath(){return imagePath;}
    public ClubCalendar getCalendar(){return calendar;}
    public String getLocation(){return location;}
    public String getMeetingTimes(){return meetingTime;}
    public ClubAttendanceObject getAttendance(){return attendace;}

    public ArrayList<User> getMembersOrLeaders()
    {
        ArrayList<User> membersOrLeaders = new ArrayList<>();
        for (User u: leaders)
        {
            membersOrLeaders.add(u);
        }
        for (User member: members)
        {
            if (!userIsALeader(member))
            {
                membersOrLeaders.add(member);
            }
        }
        return membersOrLeaders;
    }

    public boolean userIsAMember(User u)
    {
        for (User m: members)
        {
            if (m.getID() == u.getID())
            {
                return true;
            }
        }
        return false;
    }

    public boolean userIsALeader(User u)
    {
        for (User l: leaders)
        {
            if (l.getID() == u.getID())
            {
                return true;
            }
        }
        return false;
    }

    public ArrayList<User> getMembersWhoAreNotLeaders()
    {
        ArrayList<User> nonLeaderMembers = new ArrayList<>();
        for (User m: members)
        {
            if (!userIsALeader(m))
            {
                nonLeaderMembers.add(m);
            }
        }
        return nonLeaderMembers;
    }

    public void addMember_warningOnlyAffectsLocalData(User member)
    {
        members.add(member);
    }

    public void addLeader_warningOnlyAffectsLocalData(User leader)
    {
        leaders.add(leader);
    }

    public void addPendingJoinUser_warningOnlyAffectsLocalData(User pendingJoinUser)
    {
        pendingJoinUsers.add(pendingJoinUser);
    }


}
