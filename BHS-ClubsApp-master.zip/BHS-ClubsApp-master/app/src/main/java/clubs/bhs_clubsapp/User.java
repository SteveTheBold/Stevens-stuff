package clubs.bhs_clubsapp;

import java.util.ArrayList;

/**
 * Created by bal_tascofield on 5/5/2017.
 */

public class User {
    private String name;
    private int id;
    private Rank rank;
    private String secretPassword;

    private ArrayList<ClubObject> clubsThisUserIsIn;
    private ArrayList<ClubObject> clubsThisUserIsALeaderOf;
    private ArrayList<ClubObject> pendingJoinClubs;

    public User(String name, int id, Rank rank, ArrayList<ClubObject> clubsThisUserIsIn,ArrayList<ClubObject> clubsThisUserIsALeaderOf, ArrayList<ClubObject> pendingJoinClubs, String secretPassword)
    {
        this.name = name;
        this.id = id;
        this.rank = rank;
        this.clubsThisUserIsIn = clubsThisUserIsIn;
        this.clubsThisUserIsALeaderOf = clubsThisUserIsALeaderOf;
        this.pendingJoinClubs = pendingJoinClubs;
        this.secretPassword = secretPassword;
    }

    public String getName(){return name;}
    public int getID(){return id;}
    public Rank getRank(){return rank;}
    public ArrayList<ClubObject> getClubsThisUserIsIn(){return clubsThisUserIsIn;}
    public ArrayList<ClubObject> getClubsThisUserIsALeaderOf() {return clubsThisUserIsALeaderOf;}
    public ArrayList<ClubObject> getPendingJoinClubs(){return pendingJoinClubs;}

    public ArrayList<ClubObject> getClubsThisUserIsALeaderOf_OrIsAMemberOf()
    {
        ArrayList<ClubObject> membershipsOrLeaderships = new ArrayList<>();
        for (ClubObject l: clubsThisUserIsALeaderOf)
        {
            membershipsOrLeaderships.add(l);
        }
        for (ClubObject membership: clubsThisUserIsIn)
        {
            boolean clubIsAlreadyInListOfLeaderships = false;
            for (ClubObject leaderhip: clubsThisUserIsALeaderOf)
            {
                if (leaderhip.getID() == membership.getID())
                {
                    clubIsAlreadyInListOfLeaderships = true;
                }
            }
            if (!clubIsAlreadyInListOfLeaderships)
            {
                membershipsOrLeaderships.add(membership);
            }
        }
        return membershipsOrLeaderships;
    }

    public boolean userAMemberOf(ClubObject c)
    {
        for (ClubObject membership: clubsThisUserIsIn)
        {
            if (membership.getID() == c.getID())
            {
                return true;
            }
        }
        return false;
    }

    public boolean userIsALeaderOf(ClubObject c)
    {
        for (ClubObject leadership: clubsThisUserIsALeaderOf)
        {
            if (leadership.getID() == c.getID())
            {
                return true;
            }
        }
        return false;
    }

    public ArrayList<ClubObject> getClubsThisUserIsNotInAndIsNotALeaderOf(ArrayList<ClubObject> allClubs)
    {
        ArrayList<ClubObject> copyOfAllClubs = new ArrayList<>();
        for (ClubObject c: allClubs)
        {
            copyOfAllClubs.add(c);
        }
        int index = 0;
        while (index < copyOfAllClubs.size())
        {
            ClubObject clubAtIndex = copyOfAllClubs.get(index);
            if (userAMemberOf(clubAtIndex) || userIsALeaderOf(clubAtIndex))
            {
                copyOfAllClubs.remove(index);
            }
            else
            {
                index++;
            }
        }
        return copyOfAllClubs;
    }

    public ArrayList<ClubObject> getClubsThisUserIsNotALeaderOf(ArrayList<ClubObject> allClubs)
    {
        ArrayList<ClubObject> copyOfAllClubs = new ArrayList<>();
        for (ClubObject c: allClubs)
        {
            copyOfAllClubs.add(c);
        }
        int index = 0;
        while (index < copyOfAllClubs.size())
        {
            ClubObject clubAtIndex = copyOfAllClubs.get(index);
            if (userIsALeaderOf(clubAtIndex))
            {
                copyOfAllClubs.remove(index);
            }
            else
            {
                index++;
            }
        }
        return copyOfAllClubs;
    }

    public boolean secretPasswordEquals(String s)
    {
        return secretPassword.equals(s);
    }

    public void addClubMembership_warningOnlyAffectsLocalData(ClubObject membership)
    {
        clubsThisUserIsIn.add(membership);
    }

    public void addClubLeadership_warningOnlyAffectsLocalData(ClubObject leadership)
    {
        clubsThisUserIsALeaderOf.add(leadership);
    }

    public void addClubJoinRequest_warningOnlyAffectsLocalData(ClubObject joinRequest)
    {
        pendingJoinClubs.add(joinRequest);
    }

    public enum Rank{
        USER, MODERATOR
    }
}
