package clubs.bhs_clubsapp;

import java.util.Date;
import java.util.GregorianCalendar;

/**
 * Created by bal_tascofield on 5/19/2017.
 */

public class CalendarEvent {

    private String name;
    private String description;
    private int year;
    private int month;
    private int day;

    public CalendarEvent(int year, int month, int day, String name, String description)
    {
        this.year = year;
        this.month = month;
        this.day = day;
        this.name = name;
        this.description = description;
    }

    public int getYear(){return year;}
    public int getMonth(){return month;}
    public int getDay(){return day;}
    public String getName(){return name;}
    public String getDescription(){return description;}
}
