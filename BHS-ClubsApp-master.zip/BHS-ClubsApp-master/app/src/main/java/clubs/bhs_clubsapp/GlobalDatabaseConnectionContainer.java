package clubs.bhs_clubsapp;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;

/**
 * Created by bal_tascofield on 6/2/2017.
 */

public class GlobalDatabaseConnectionContainer {
    private static String refreshToken = "1/v_Ae2pvIYUgR_KqR88ZJlLUjXda8DJipcqT1QYt77rc";
    private static String spreadsheetID = "1mDvFOM9ovlKQCM2BDhnVNdJR6Bhxl5HrhJnOnE-ZXO4";
    private static String clientID = "593549145110-lg67a17i7439mbj6s442e6o90ng6ju9o.apps.googleusercontent.com";
    private static String clientSecret = "cDhxfRaNRnRMwDEV6IXNqFcH";
    private static boolean databaseHasInitialized = false;
    private static databaseConnection d = null;
    static User userOfThisApp = null;
    private static globalDatabaseInitializationCallback gdic = null;
    private static boolean hasUserID = false;
    private static boolean hasUser = false;
    private static int userID = -1;

    public static void setGlobalDatabaseInitializationCallback(globalDatabaseInitializationCallback gdicToSet)
    {
        gdic = gdicToSet;
    }

    public interface globalDatabaseInitializationCallback{
        void onFinishedInitializing();
    }
    public static void initialize(final Context c)
    {
        d = new databaseConnection();
        databaseConnection.initializationCallback ic = new databaseConnection.initializationCallback() {
            @Override
            public void onSuccess() {
                //do the following when the database has finished initializing
                //ArrayList<ClubObject> allClubs = d.getAllClubs();
                ArrayList<User> allUsers = d.getAllUsers();
                tryToFindPrefUserID(c);
                if (hasUserID)
                {
                    findUserInUserList(allUsers);
                }
                databaseHasInitialized = true;
                if (gdic != null)
                {
                    gdic.onFinishedInitializing();
                }
            }
        };
        d.initialize(c,refreshToken,spreadsheetID,clientID,clientSecret,ic);
    }

    private static void tryToFindPrefUserID(Context c)
    {
        SharedPreferences prefs = c.getSharedPreferences(MainActivity.sharedPreferencesName,Context.MODE_PRIVATE);
        if (prefs.contains(MainActivity.preferenceNameOfUserID))
        {
            userID = prefs.getInt(MainActivity.preferenceNameOfUserID,-1);
            hasUserID = true;
        }
    }

    private static void findUserInUserList(ArrayList<User> allUsers)
    {
        for (User u: allUsers)
        {
            if (u.getID() == userID)
            {
                userOfThisApp = u;
                hasUser = true;
            }
        }
    }

    private static void setUserIdPreference(int userID, Context c)
    {
        SharedPreferences prefs = c.getSharedPreferences(MainActivity.sharedPreferencesName,Context.MODE_PRIVATE);
        SharedPreferences.Editor e = prefs.edit();
        e.putInt(MainActivity.preferenceNameOfUserID,userID);
        e.apply();
    }

    public static void setUserID(int id, Context c)
    {
        userID = id;
        setUserIdPreference(id,c);
        if (databaseHasInitialized)
        {
            ArrayList<User> allUsers = d.getAllUsers();
            findUserInUserList(allUsers);
        }
    }

    public static boolean hasUser()
    {
        return hasUser;
    }

    public static boolean databaseHasInitialized()
    {
        return databaseHasInitialized;
    }

    public static databaseConnection getDatabaseConnection()
    {
        return d;
    }

    public static User getUserOfThisApp()
    {
        return d.getUserWithID(userID);
    }
}

