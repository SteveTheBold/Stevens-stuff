package clubs.bhs_clubsapp;

/**
 * Created by bal_sjtestone001 on 5/5/2017.
 */

public class Member {
}
