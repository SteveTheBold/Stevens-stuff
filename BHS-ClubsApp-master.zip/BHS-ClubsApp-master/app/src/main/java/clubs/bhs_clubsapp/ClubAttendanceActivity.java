package clubs.bhs_clubsapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by bal_sjtestone001 on 6/14/2017.
 */

public class ClubAttendanceActivity extends AppCompatActivity {

    private int clubId;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance_days);
        clubId = getIntent().getIntExtra("ClubId",-1);

    }

}
