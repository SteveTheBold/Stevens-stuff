package clubs.bhs_clubsapp;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.TextView;

import java.util.ArrayList;


/**
 * Created by bal_sjtestone001 on 5/5/2017.
 */

public class ClubItemAdapter extends BaseAdapter {

    private ArrayList<ClubObject> clubs;
    private Context context;


    public ClubItemAdapter(Context context,ArrayList<ClubObject> clubs){
        this.context = context;
        this.clubs = clubs;
    }

    public View getView(int i, View view, ViewGroup vg){

        LayoutInflater layoutInflater = LayoutInflater.from(context);
        view = layoutInflater.inflate(R.layout.club_item, null);

        //ImageView imageView = (ImageView) view.findViewById(R.id.clubIcon);
        TextView clubName = (TextView) view.findViewById(R.id.Name);
        TextView clubDescription = (TextView) view.findViewById(R.id.disc);
        final ClubObject club = clubs.get(i);
        //imageView = clubs[i].getIcon();
        clubName.setText(club.getClubName());
        clubDescription.setText(club.getDescription());




        view.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                /** Build Intent for club details **/
                Intent intent = new Intent(context, ClubBioActivity.class);
                intent.putExtra("ClubId",club.getID());

                /** Start Intent FROM an activity (needs FLAG_ACTIVITY_NEW_TASK to start) **/
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);
            }
        });


        return view;}

    public long getItemId(int i){return clubs.get(i).getID();}

    public int getCount(){return clubs.size();}

    @Override
    public Object getItem(int position) {
        return null;
    }
}
