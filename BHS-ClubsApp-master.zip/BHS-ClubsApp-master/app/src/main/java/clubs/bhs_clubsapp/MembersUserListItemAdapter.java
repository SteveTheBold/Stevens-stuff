package clubs.bhs_clubsapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by super on 6/8/2017.
 */

public class MembersUserListItemAdapter extends BaseAdapter {

    private Context c;
    private ArrayList<User> users;
    private ClubObject thisClub;

    public MembersUserListItemAdapter(Context c, ClubObject thisClub)
    {
        this.c = c;
        this.thisClub = thisClub;
        this.users = thisClub.getMembersOrLeaders();
    }

    public int getCount(){return users.size();}

    public View getView(int i, View view, ViewGroup vg)
    {
        LayoutInflater layoutInflater = LayoutInflater.from(c);
        view = layoutInflater.inflate(R.layout.user_list_item,null);
        TextView username = (TextView) view.findViewById(R.id.usernameTextView);
        TextView position = (TextView) view.findViewById(R.id.positionTextView);
        final User u = users.get(i);
        boolean userIsLeader = false;
        for (User leader: thisClub.getLeaders())
        {
            if (leader.getID() == u.getID())
            {
                userIsLeader = true;
            }
        }
        String positionText;
        if (userIsLeader)
        {
            positionText = "Leader";
        }
        else
        {
            positionText = "Member";
        }
        position.setText(positionText);
        String name = u.getName();
        username.setText(name);
        return view;
    }

    public long getItemId(int i)
    {
        return users.get(i).getID();
    }

    public Object getItem(int position)
    {
        return null;
    }
}
