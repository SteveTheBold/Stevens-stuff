package clubs.bhs_clubsapp;

import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;

/**
 * Created by super on 6/3/2017.
 */

public class cancelOrContinueDialogFragment extends DialogFragment{

    private static String negativeButtonText = "default cancel";
    private static String positiveButtonText = "default ok";
    private static String messageToDisplay = "default message";
    private static DialogInterface.OnClickListener onClickNegative = new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            //do nothing
        }
    };
    private static DialogInterface.OnClickListener onClickPositive = new DialogInterface.OnClickListener() {
        @Override
        public void onClick(DialogInterface dialog, int which) {
            //do nothing
        }
    };

    public static void setNegativeButtonText(String s){negativeButtonText = s;}
    public static void setPositiveButtonText(String s){positiveButtonText = s;}
    public static void setMessageToDisplay(String s){messageToDisplay = s;}
    public static void setOnClickNegative(DialogInterface.OnClickListener l){onClickNegative = l;}
    public static void setOnClickPositive(DialogInterface.OnClickListener l){onClickPositive = l;}

    public Dialog onCreateDialog(Bundle SavedInstanceState)
    {
        AlertDialog.Builder b = new AlertDialog.Builder(getActivity());
        b.setMessage(messageToDisplay);
        b.setCancelable(false);
        b.setPositiveButton(positiveButtonText,onClickPositive);
        b.setNegativeButton(negativeButtonText,onClickNegative);
        return b.create();
    }
}
