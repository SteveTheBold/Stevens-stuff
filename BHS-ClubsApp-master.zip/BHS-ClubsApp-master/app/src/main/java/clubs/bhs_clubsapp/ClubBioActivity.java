package clubs.bhs_clubsapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

/**
 * Created by bal_sjtestone001 on 5/15/2017.
 */

public class ClubBioActivity extends AppCompatActivity {

    private int clubId;
    private String clubDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.club_bio);
        Intent intent = getIntent();
        TextView ClubDescription = (TextView) findViewById(R.id.clubDisc);
        clubId = intent.getIntExtra("ClubId", 0);
        ClubObject thisClub = GlobalDatabaseConnectionContainer.getDatabaseConnection().getClubWithID(clubId);
        ClubDescription.setText(thisClub.getDescription());
        ArrayList<User> leaders_arraylist = thisClub.getLeaders();

        String leaders = "";
        if (leaders_arraylist.size() == 0)
        {
            leaders = "No leaders";
        }
        else if (leaders_arraylist.size() >= 1)
        {
            leaders = leaders_arraylist.get(0).getName();
            if (leaders_arraylist.size() > 1)
            {
                for (int i = 1; i < leaders_arraylist.size(); i++)
                {
                    leaders = leaders + ", " + leaders_arraylist.get(i).getName();
                }
            }
        }

        TextView clubLeaders = (TextView) findViewById(R.id.clubLeaders);
        clubDescription = thisClub.getDescription();
        resetJoinButtonText();
        ImageView imageView = (ImageView) findViewById(R.id.image);
        String imagePath = thisClub.getImagePath();
        if (imagePath != null && isValidUrl(imagePath)) {
            Picasso.with(getBaseContext()).load(imagePath).into(imageView);
        }
        TextView meetings = (TextView) findViewById(R.id.clubTimes);
        meetings.setText("Meeting times: " + thisClub.getMeetingTimes());
        TextView location = (TextView) findViewById(R.id.clubLocation);
        location.setText("Location: " + thisClub.getLocation());
        clubLeaders.setText("Leaders: " + leaders);
    }

    public boolean isValidUrl(String s)
    {
        try{
            URL u = new URL(s);
            return true;
        }
        catch (MalformedURLException e)
        {
            return false;
        }
    }

    public void join(View view){
        final Button button = (Button) view.findViewById(R.id.join);
        if (userAlreadyIsTryingTOJoin())
        {
            databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
            final ProgressDialog pd = new ProgressDialog(this);
            pd.setMessage("Retracting Request...");
            pd.setCancelable(false);
            pd.show();
            databaseConnection.removePendingUserRequestCallback rpurc = new databaseConnection.removePendingUserRequestCallback() {
                @Override
                public void onRemoveRequest() {
                    resetJoinButtonText();
                    pd.cancel();
                }
            };
            d.removePendingUserRequest(GlobalDatabaseConnectionContainer.getUserOfThisApp().getID(),clubId,rpurc,getBaseContext());
        }
        else
        {
            databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
            final ProgressDialog pd = new ProgressDialog(this);
            pd.setMessage("Sending Request...");
            pd.setCancelable(false);
            pd.show();
            databaseConnection.addPendingJoinUserToClubCallback apjutcc = new databaseConnection.addPendingJoinUserToClubCallback() {
                @Override
                public void onAddPendingJoinUser() {
                    //after the user's request is added, change the button
                    resetJoinButtonText();
                    pd.cancel();
                }
            };
            d.addPendingJoinUserToClub(GlobalDatabaseConnectionContainer.getUserOfThisApp().getID(),clubId,apjutcc,getBaseContext());
        }

    }

    private void resetJoinButtonText()
    {
        boolean userIsTryingTOJoin = userAlreadyIsTryingTOJoin();
        Button button = (Button) findViewById(R.id.join);
        button.setVisibility(View.VISIBLE);
        button.setClickable(true);
        if (userIsTryingTOJoin)
        {
            button.setText("Retract request");
        }
        else
        {
            if (userIsMember() || userIsLeader())
            {
                button.setClickable(false);
                button.setVisibility(View.GONE);
            }
            else
            {
                button.setText("Send request to join");
            }
        }
    }

    public boolean userIsMember()
    {
        databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
        ClubObject thisClub = d.getClubWithID(clubId);
        ArrayList<User> membersOfThisClub = thisClub.getMembers();
        boolean userIsMember = false;
        for (User u: membersOfThisClub)
        {
            if (GlobalDatabaseConnectionContainer.getUserOfThisApp().getID() == u.getID())
            {
                userIsMember = true;
            }
        }
        return userIsMember;
    }

    public boolean userIsLeader()
    {
        databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
        ClubObject thisClub = d.getClubWithID(clubId);
        ArrayList<User> leadersOfThisClub = thisClub.getLeaders();
        boolean userIsLeader = false;
        for (User u: leadersOfThisClub)
        {
            if (GlobalDatabaseConnectionContainer.getUserOfThisApp().getID() == u.getID())
            {
                userIsLeader = true;
            }
        }
        return userIsLeader;
    }

    public boolean userAlreadyIsTryingTOJoin()
    {
        databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
        ClubObject thisClub = d.getClubWithID(clubId);
        ArrayList<User> pendingJoinUsersOfThisClub = thisClub.getPendingJoinUsers();
        boolean userIsTryingTOJoin = false;
        for (User u: pendingJoinUsersOfThisClub)
        {
            if (GlobalDatabaseConnectionContainer.getUserOfThisApp().getID() == u.getID())
            {
                userIsTryingTOJoin = true;
            }
        }
        return userIsTryingTOJoin;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()){

            case(R.id.editDes):
                Intent intent = new Intent(getBaseContext(),ClubManagementPage.class);
                intent.putExtra("ClubId",clubId);
                //intent.putExtra("ClubDescription",clubDescription);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getBaseContext().startActivity(intent);
                return super.onOptionsItemSelected(item);


            default:
                return super.onOptionsItemSelected(item);
        }
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        int pos = -1;
        ArrayList<ClubObject> clubs = GlobalDatabaseConnectionContainer.getDatabaseConnection().getAllClubs();
        for (int j = 0;j < clubs.size();j++){
            if (clubs.get(j).getID() == clubId)
                pos = j;
        }
        if (pos == -1)
            return false;
        ArrayList<User> users = GlobalDatabaseConnectionContainer.getDatabaseConnection().getAllClubs().get(pos).getLeaders();

        for (int i = 0;i < users.size();i++){
            int id = users.get(i).getID();
            if (id == GlobalDatabaseConnectionContainer.userOfThisApp.getID()){
                MenuInflater menuInflater = getMenuInflater();
                menuInflater.inflate(R.menu.bio_menu, menu);
                return true;
            }
        }
        return false;
    }
}


