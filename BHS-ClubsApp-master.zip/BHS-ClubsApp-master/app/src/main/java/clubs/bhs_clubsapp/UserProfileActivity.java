package clubs.bhs_clubsapp;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.InputFilter;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by super on 6/10/2017.
 */

public class UserProfileActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userprofile);

        resetEverything();
    }

    public void resetEverything()
    {
        resetUsernameTextView();
        resetRankTextView();
        resetModerationPanelButton();
    }

    public void resetRankTextView()
    {
        User thisUser = GlobalDatabaseConnectionContainer.getUserOfThisApp();
        User.Rank userRank = thisUser.getRank();
        String userRank_S;
        switch(userRank)
        {
            case USER:
                userRank_S = "User";
                break;
            case MODERATOR:
                userRank_S = "Moderator";
                break;
            default:
                userRank_S = "????";
                break;
        }

        TextView rankTextView = (TextView) findViewById(R.id.profileRankTextView);
        rankTextView.setText(userRank_S);
    }

    public void resetUsernameTextView()
    {
        User thisUser = GlobalDatabaseConnectionContainer.getUserOfThisApp();
        String username = thisUser.getName();
        TextView usernameTextView = (TextView) findViewById(R.id.profileUsernameTextView);
        usernameTextView.setText(username);
    }

    public void resetModerationPanelButton()
    {
        Button moderationPanelButton = (Button) findViewById(R.id.moderationPanelButton);
        User.Rank r = GlobalDatabaseConnectionContainer.getUserOfThisApp().getRank();
        if (r == User.Rank.USER)
        {
            moderationPanelButton.setVisibility(View.GONE);
            moderationPanelButton.setClickable(false);
        }
        else // if (r == User.Rank.MODERATOR)
        {
            moderationPanelButton.setVisibility(View.VISIBLE);
            moderationPanelButton.setClickable(true);
        }
    }

    public void onClickChangeUsername(View view)
    {
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        final EditText inputNewUsername = new EditText(this);
        if (FirstLaunchGetUserIDActivity.BLOCK_NON_LETTER_USERNAMES)
        {
            inputNewUsername.setFilters(new InputFilter[]{FirstLaunchGetUserIDActivity.newUsernameFilter});
        }
        inputNewUsername.setHint("Enter your new username");
        b.setView(inputNewUsername);
        final Context copyOfThis = this;

        b.setPositiveButton("Update Username", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String enteredName = inputNewUsername.getText().toString();
                final databaseConnection d = GlobalDatabaseConnectionContainer.getDatabaseConnection();
                if (enteredName.length() == 0)
                {
                    ShowStringDialogFragment.setMessageToDisplay("Your username can't be 0 characters long.");
                    ShowStringDialogFragment.setPositiveButtonText("OKAY.");
                    ShowStringDialogFragment.setOnClickOkay(new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            //do nothing
                        }
                    });
                    ShowStringDialogFragment ssdf = new ShowStringDialogFragment();
                    ssdf.show(getFragmentManager(),"");
                }
                else
                {
                    final ProgressDialog pd = new ProgressDialog(copyOfThis);
                    pd.setMessage("Updating Username...");
                    pd.setCancelable(false);
                    pd.show();

                    databaseConnection.updateUserNameCallback uunc = new databaseConnection.updateUserNameCallback() {
                        @Override
                        public void onUpdateName() {
                            databaseConnection.refreshCallback rc = new databaseConnection.refreshCallback() {
                                @Override
                                public void onRefresh() {
                                    resetEverything();
                                    pd.cancel();
                                }
                            };
                            d.refreshDatabase(rc,copyOfThis);

                        }
                    };

                    d.updateNameOfUser(GlobalDatabaseConnectionContainer.getUserOfThisApp().getID(),enteredName,uunc,copyOfThis);
                }
            }
        });

        b.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        b.show();
    }

    public void pressModerationPanelButton(View view)
    {
        Intent goToModerationPanel = new Intent(this,ModerationPanelActivity.class);
        startActivity(goToModerationPanel);
    }

}
