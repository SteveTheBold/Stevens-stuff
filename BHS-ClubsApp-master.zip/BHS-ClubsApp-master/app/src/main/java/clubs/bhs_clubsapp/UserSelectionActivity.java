package clubs.bhs_clubsapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by super on 6/11/2017.
 */

public class UserSelectionActivity extends AppCompatActivity {

    private User selectedUser = null;

    public static String SELECTED_USER_ID_EXTRA = "selectedUser";

    private static ArrayList<User> usersToDisplay = new ArrayList<>();

    public static void setUsersToDisplay(ArrayList<User> users)
    {
        usersToDisplay = users;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_selection);
        //ArrayList<User> allUsers = GlobalDatabaseConnectionContainer.getDatabaseConnection().getAllUsers();


        //ListView UserSelection_userListView = (ListView) findViewById(R.id.UserSelection_userListView);
        ListView UserSelection_userListView = (ListView) findViewById(R.id.UserSelection_userListView);
        UserSelectionAdapter adapter = new UserSelectionAdapter(usersToDisplay, this, new UserSelectionAdapter.onUserSelectedListener() {
            @Override
            public void onUserSelected(int userID) {
                selectedUser = GlobalDatabaseConnectionContainer.getDatabaseConnection().getUserWithID(userID);
                resetEverything();
            }
        });

        UserSelection_userListView.setAdapter(adapter);

        resetEverything();
    }


    public void resetEverything() {
        resetChooseButton();
        resetSelectedUserTextView();
    }

    public void resetChooseButton() {
        Button chooseButton = (Button) findViewById(R.id.user_selection_choose_button);
        if (selectedUser == null) {
            chooseButton.setClickable(false);
            chooseButton.setAlpha(0.5f);
        } else {
            chooseButton.setClickable(true);
            chooseButton.setAlpha(1f);
        }
    }

    public void resetSelectedUserTextView() {
        TextView user_selection_selected_user_textView = (TextView) findViewById(R.id.user_selection_selected_user_textView);
        String textToDisplay;
        if (selectedUser == null) {
            textToDisplay = "(no user selected)";
        } else {
            textToDisplay = selectedUser.getName();
        }
        user_selection_selected_user_textView.setText(textToDisplay);
    }

    public void onPressChoose(View view) {
        Intent i = new Intent();
        i.putExtra(SELECTED_USER_ID_EXTRA, selectedUser.getID());
        setResult(Activity.RESULT_OK, i);
        finish();
    }

    public void onPressCancel(View view) {
        setResult(Activity.RESULT_CANCELED);
        finish();
    }
}
