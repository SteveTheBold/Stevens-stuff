package clubs.bhs_clubsapp;

import android.provider.CalendarContract;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.Random;

/**
 * Created by bal_tascofield on 6/13/2017.
 */

public class ClubAttendanceObject {
    public static class ClubAttendanceDayObject{


        private ArrayList<ClubMemberAttendanceDayObject> userAttendances;
        private GregorianCalendar d;

        public ClubAttendanceDayObject(ArrayList<ClubMemberAttendanceDayObject> userAttendances, GregorianCalendar d)
        {
            this.userAttendances = userAttendances;
            this.d = d;
        }

        public GregorianCalendar getDate(){return d;}
        public ArrayList<ClubMemberAttendanceDayObject> getMemberAttendances(){return userAttendances;}
    }

    public static class ClubMemberAttendanceDayObject{
        private int userID;
        private boolean wasPresent;

        public ClubMemberAttendanceDayObject(int userID, boolean wasPresent)
        {
            this.userID = userID;
            this.wasPresent = wasPresent;
        }

        public int getUserID(){return userID;}
        public boolean wasPresent(){return wasPresent;}
    }

    private int clubID;
    private ArrayList<ClubAttendanceDayObject> days;

    public ClubAttendanceObject(int clubID, ArrayList<ClubAttendanceDayObject> days)
    {
        this.clubID = clubID;
        this.days = days;
    }

    public ArrayList<ClubAttendanceDayObject> getDays(){return days;}
    public int getClubID(){return clubID;}

    public static JSONObject clubMemberAttendanceDayObjectToJSONObject(ClubMemberAttendanceDayObject member)
    {
        try{
            JSONObject o = new JSONObject();
            o.put("UID",member.getUserID());
            o.put("p",member.wasPresent());
            return o;
        }
        catch (org.json.JSONException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    private static ClubMemberAttendanceDayObject JSONStringToClubMemberAttendanceDayObject(JSONObject o)
    {
        try{
            int userID = o.getInt("UID");
            boolean wasPresent = o.getBoolean("p");
            ClubMemberAttendanceDayObject m = new ClubMemberAttendanceDayObject(userID,wasPresent);
            return m;
        }
        catch (JSONException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    private static JSONObject clubAttendanceDayObjectToJSONObject(ClubAttendanceDayObject day)
    {
        try{
            JSONObject o = new JSONObject();
            Calendar d = day.getDate();
            int yearInt = d.get(Calendar.YEAR);
            int monthInt = d.get(Calendar.MONTH);
            int dayInt = d.get(Calendar.DAY_OF_MONTH);
            JSONObject dateObject = new JSONObject();
            dateObject.put("year",yearInt);
            dateObject.put("month",monthInt);
            dateObject.put("day",dayInt);
            o.put("date",dateObject);
            JSONArray membersJSON = new JSONArray();
            ArrayList<ClubMemberAttendanceDayObject> members = day.getMemberAttendances();
            for (ClubMemberAttendanceDayObject m: members)
            {
                membersJSON.put(clubMemberAttendanceDayObjectToJSONObject(m));
            }
            o.put("members",membersJSON);
            return o;
        }
        catch (org.json.JSONException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    private static ClubAttendanceDayObject JSONStringToClubAttendanceDayObject(JSONObject o)
    {
        try{
            JSONObject dateObject = o.getJSONObject("date");
            int year = dateObject.getInt("year");
            int month = dateObject.getInt("month");
            int day = dateObject.getInt("day");
            JSONArray members = o.getJSONArray("members");
            GregorianCalendar d = new GregorianCalendar(year,month,day);
            ArrayList<ClubMemberAttendanceDayObject> membersAL = new ArrayList<>();
            for (int i = 0; i < members.length(); i++)
            {
                membersAL.add(JSONStringToClubMemberAttendanceDayObject((JSONObject) members.get(i)));
            }
            ClubAttendanceDayObject dayObject = new ClubAttendanceDayObject(membersAL,d);
            return dayObject;
        }
        catch(JSONException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public static String clubAttendanceObjectToJSONString(ClubAttendanceObject attendance)
    {
        try{
            ArrayList<ClubAttendanceDayObject> days = attendance.getDays();
            int clubID = attendance.getClubID();
            JSONObject o = new JSONObject();
            o.put("CID",clubID);
            JSONArray daysJSA = new JSONArray();
            for (ClubAttendanceDayObject day: days)
            {
                JSONObject dayObject = clubAttendanceDayObjectToJSONObject(day);
                daysJSA.put(dayObject);
            }
            o.put("days",daysJSA);
            return o.toString();
        }
        catch (org.json.JSONException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public static ClubAttendanceObject StringToClubAttendanceObject(String s)
    {
        try{
            JSONObject o = new JSONObject(s);
            int clubID = o.getInt("CID");
            JSONArray days = o.getJSONArray("days");
            ArrayList<ClubAttendanceDayObject> daysAL = new ArrayList<>();
            for (int i = 0; i < days.length(); i++)
            {
                daysAL.add(JSONStringToClubAttendanceDayObject(days.getJSONObject(i)));
            }
            ClubAttendanceObject attendanceObject = new ClubAttendanceObject(clubID,daysAL);
            return attendanceObject;
        }
        catch(JSONException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public static ClubAttendanceObject getTestClubAttendanceObject()
    {
        Random r = new Random();
        ArrayList<Integer> members = new ArrayList<>();
        int numMembers = r.nextInt(4) + 5;
        int lastMember = r.nextInt(3);
        for (int i = 0; i < numMembers; i++)
        {
            members.add(lastMember);
            int memberIDIncrement = r.nextInt(4) + 1;
            lastMember+=memberIDIncrement;
        }
        int numDays = r.nextInt(7) + 8;
        int year = r.nextInt(18) + 1999;
        int month = r.nextInt(12);
        int day = r.nextInt(31);
        ArrayList<ClubAttendanceDayObject> dayAttendances = new ArrayList<>();
        for (int i = 0; i < numDays; i++)
        {
            ArrayList<ClubMemberAttendanceDayObject> memberAttendances = new ArrayList<>();
            GregorianCalendar d = new GregorianCalendar(year,month,day);
            for (int memberID: members)
            {
                boolean wasPresent = r.nextBoolean();
                ClubMemberAttendanceDayObject m = new ClubMemberAttendanceDayObject(memberID,wasPresent);
                memberAttendances.add(m);
            }
            ClubAttendanceDayObject dayAttendance = new ClubAttendanceDayObject(memberAttendances,d);
            dayAttendances.add(dayAttendance);
            int yearIncrement = r.nextInt(2);
            int monthIncrement = r.nextInt(4);
            int dayIncrement = r.nextInt(13);
            year+=yearIncrement;
            month = (month + monthIncrement) % 12;
            day = (day + dayIncrement) % 31;
        }
        int clubID = r.nextInt(50000);
        ClubAttendanceObject attendance = new ClubAttendanceObject(clubID,dayAttendances);
        return attendance;
    }

}
