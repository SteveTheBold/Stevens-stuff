package clubs.bhs_clubsapp;



import android.content.Context;
import com.android.volley.AuthFailureError;
import com.android.volley.NetworkResponse;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;


/**
 * Created by bal_tascofield on 4/28/2017.
 */

public class databaseConnection {

    //private Context c;

    private String refresh_token;
    private String access_token;

    private String clientId;
    private String clientSecret;
    private String spreadsheetID;

    private String[][] databaseState;
    private int lastUsedRow;
    private int totalClubs;
    private int totalUsers;
    private int lastUsedClubId;
    private int lastUsedUserId;

    private ArrayList<ClubObject> allClubs;
    private ArrayList<User> allUsers;

    private static final String ACCESS_TOKEN_NAME = "access_token";

    private static  final String base = "https://sheets.googleapis.com/v4/spreadsheets/";

    private static final String LAST_USED_COLUMN = "S";

    private static final String deletedString = "[deleted]";

    private static final int firstUsedRowForData = 9;
    private static final int numColumnsInClubList = 11;
    private static final int numColumnsInUserList = 7;
    private static final String topLeftOfSheet = "A1";

    public databaseConnection(){}

    /**
     * initialize this class. This is separate from the actual initializer because the initialization of this class will probably contain references to itself
     * @param c the context of the activity that is calling this
     * @param refresh_token technical thing
     * @param spreadsheetID the ID of the spreadsheet to get information from
     * @param clientId technical thing
     * @param clientSecret technical thing
     * @param ic the action to perform after the initialization is complete
     */
    public void initialize(final Context c, String refresh_token, String spreadsheetID, String clientId, String clientSecret, final initializationCallback ic)
    {
        //this.c = c;
        this.refresh_token = refresh_token;
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.spreadsheetID = spreadsheetID;

        final refreshCallback rc = new refreshCallback() {
            @Override
            public void onRefresh() {
                //after the database is done being refreshed, execute the callback
                if (ic != null)
                {
                    ic.onSuccess();
                }
            }
        };


        VolleyCallback assignAccessToken = new VolleyCallback() {
            @Override
            public void onSuccess(String result) {
                //after it gets the access token, assign the access token to its value, and then refresh the database
                try{
                    JSONObject j = new JSONObject(result);
                    access_token = j.getString("access_token");
                    refreshDatabase(rc,c);
                }
                catch (org.json.JSONException e)
                {
                    access_token = "error";
                }
            }
        };

        String grantType = "refresh_token";

        String authorizationBase = "https://www.googleapis.com/oauth2/v4/token";

        String contentType = "application/x-www-form-urlencoded";

        String[] keys = {
                "refresh_token",
                "client_id",
                "client_secret",
                "grant_type"
        };
        String[] values = {
                refresh_token,
                clientId,
                clientSecret,
                grantType
        };
        postWithVolley(authorizationBase,keys,values,contentType,assignAccessToken,c);
    }

    private interface databaseStatisticsSyncCallback{
        void onFinishSync();
    }

    private void syncDatabaseStatistics(final databaseStatisticsSyncCallback dssc, Context c)
    {
        String statisticsRange = "A1:B5";
        batchGetCallback bgc = new batchGetCallback() {
            @Override
            public void onSuccess(String[][] response) {
                //after it gets the section of the spreadsheet that contains the statistics, update the local variables to the correct values
                lastUsedRow = Integer.parseInt(response[0][1]);
                totalClubs = Integer.parseInt(response[1][1]);
                totalUsers = Integer.parseInt(response[2][1]);
                lastUsedClubId = Integer.parseInt(response[3][1]);
                lastUsedUserId = Integer.parseInt(response[4][1]);
                if (dssc != null)
                {
                    dssc.onFinishSync();
                }
            }
        };
        batchGet(statisticsRange,bgc,c);
    }

    public interface initializationCallback{
        void onSuccess();
    }

    private void getWithVolley(String url, final VolleyCallback callback, Context c)
    {
        RequestQueue q = Volley.newRequestQueue(c);
        StringRequest sr = new StringRequest(Request.Method.GET,url,
                new Response.Listener<String>() {
                    public void onResponse(String response) {
                        String r = response;
                        if (callback != null)
                        {
                            callback.onSuccess(r);
                        }
                    }
                },
                new Response.ErrorListener() {
                    public void onErrorResponse(VolleyError error) {
                        NetworkResponse resp = error.networkResponse;
                        byte[] data = resp.data;
                        String bytes = "";
                        for (byte by: data)
                        {
                            bytes = bytes + ((char) by);
                        }
                        String r = "error";
                    }
                }
        );
        q.add(sr);
    }

    private void postWithVolley(String url, final String[] paramKeys, final String[] paramValues, final String contentType, final VolleyCallback callback, Context c)
    {
        RequestQueue q = Volley.newRequestQueue(c);
        StringRequest sr = new StringRequest(Request.Method.POST,url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        String r = response;
                        if (callback != null)
                        {
                            callback.onSuccess(r);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String message = error.getMessage();
                        Throwable cause = error.getCause();
                        String localizedMessage = error.getLocalizedMessage();
                        NetworkResponse resp = error.networkResponse;
                        byte[] data = resp.data;
                        String bytes = "";
                        for (byte by: data)
                        {
                            bytes = bytes + ((char) by);
                        }
                        String r = "error";
                    }
                }){
            @Override
            protected Map<String,String> getParams(){
                Map<String,String> params = new HashMap<String,String>();
                for (int i = 0; i < paramKeys.length; i++)
                {
                    params.put(paramKeys[i],paramValues[i]);
                }
                return params;
            }

            @Override
            public Map<String,String> getHeaders() throws AuthFailureError {
                Map<String,String> params = new HashMap<String,String>();
                params.put("Content-Type",contentType);
                return params;
            }
        };
        q.add(sr);
    }

    private void postJSONWithVolley(String url, JSONObject o, final VolleyCallback v, Context c)
    {
        RequestQueue q = Volley.newRequestQueue(c);
        JsonObjectRequest jor = new JsonObjectRequest(Request.Method.POST, url, o, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                String response_s = response.toString();
                if (v != null)
                {
                    v.onSuccess(response_s);
                }
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String message = error.getMessage();
                        Throwable cause = error.getCause();
                        String localizedMessage = error.getLocalizedMessage();
                        NetworkResponse resp = error.networkResponse;
                        byte[] data = resp.data;
                        String bytes = "";
                        for (byte by: data)
                        {
                            bytes = bytes + ((char) by);
                        }
                        String r = "error";
                    }
                });
        q.add(jor);
    }

    public void postWithVolley(String url, final String[] paramKeys, final String[] paramValues, final VolleyCallback callback, Context c)
    {
        postWithVolley(url,paramKeys,paramValues,"application/x-www-form-urlencoded",callback,c);
    }

    private interface VolleyCallback{
        void onSuccess(String result);
    }

    private enum majorDimension{
        ROWS, COLUMNS
    }

    private enum ValueInputOption{
        INPUT_VALUE_OPTION_UNSPECIFIED, RAW, USER_ENTERED
    }

    private enum ValueRenderOption{
        FORMATTED_VALUE, UNFORMATTED_VALUE, FORMULA
    }

    private static String majorDimensionToString(majorDimension md)
    {
        switch(md)
        {
            case ROWS:
                return "ROWS";
            case COLUMNS:
                return "COLUMNS";
            default:
                return null;
        }
    }

    private static String ValueInputOptionToString(ValueInputOption vio)
    {
        switch(vio)
        {
            case INPUT_VALUE_OPTION_UNSPECIFIED:
                return "INPUT_VALUE_OPTION_UNSPECIFIED";
            case RAW:
                return "RAW";
            case USER_ENTERED:
                return "USER_ENTERED";
            default:
                return null;
        }
    }

    private static String ValueRenderOptionToString(ValueRenderOption vro)
    {
        switch(vro)
        {
            case FORMATTED_VALUE:
                return "FORMATTED_VALUE";
            case UNFORMATTED_VALUE:
                return "UNFORMATTED_VALUE";
            case FORMULA:
                return "FORMULA";
            default:
                return null;
        }
    }

    private interface batchGetCallback{
        void onSuccess(String[][] response);
    }

    private void batchGet(String range, majorDimension md, final batchGetCallback bgc, Context c)
    {
        //range uses format "A1:G10"
        String baseCommand = base
                + spreadsheetID + "/values:batchGet";
        String mdS = majorDimensionToString(md);
        VolleyCallback v = new VolleyCallback() {
            @Override
            public void onSuccess(String result) {
                try{
                    JSONObject j = new JSONObject(result);
                    JSONArray valueRanges = j.getJSONArray("valueRanges");
                    JSONObject valueRange = valueRanges.getJSONObject(0);
                    String[][] values = parseValueRange(valueRange);
                    if (bgc != null)
                    {
                        bgc.onSuccess(values);
                    }
                }
                catch (org.json.JSONException e)
                {
                    e.printStackTrace();
                }
            }
        };
        String[] keys = {
                ACCESS_TOKEN_NAME,
                "ranges",
                "majorDimension"
        };
        String[] values = {
                access_token,
                range,
                mdS
        };
        String url = addKeyValuePairsToUrl(keys,values,baseCommand);
        getWithVolley(url,v,c);
    }

    private void batchGet(String range, final batchGetCallback bgc, Context c)
    {
        majorDimension md = majorDimension.ROWS;
        batchGet(range,md,bgc,c);
    }

    private static String[][] parseValueRange(JSONObject o)
    {
        try{
            JSONArray values = o.getJSONArray("values");
            int maxRowLength = 0;
            for (int rowIndex = 0; rowIndex < values.length(); rowIndex++)
            {
                maxRowLength = Math.max(maxRowLength,values.getJSONArray(rowIndex).length());
            }
            String[][] r = new String[values.length()][0];
            for (int i = 0; i < values.length(); i++)
            {
                JSONArray valuesRow = values.getJSONArray(i);
                String[] thisRow = new String[maxRowLength];
                for (int j = 0; j < valuesRow.length(); j++)
                {
                    thisRow[j] = valuesRow.getString(j);
                }
                for (int k = 0; k < thisRow.length; k++)
                {
                    if (thisRow[k] == null)
                    {
                        thisRow[k] = "";
                    }
                }
                r[i] = thisRow;
            }
            return r;
        }
        catch (org.json.JSONException e)
        {
            return null;
        }
    }

    private static String addKeyValuePairsToUrl(String[] keys, String[] values, String url)
    {
        if (keys.length > 0)
        {
            String toAdd = "?" + keys[0] + "=" + values[0];
            for (int i = 1; i < keys.length; i++)
            {
                toAdd = toAdd + "&" + keys[i] + "=" + values[i];
            }
            return url + toAdd;
        }
        return url;
    }

    private static JSONObject makeValueRange(String[][] values, String range, String majorDimension)
    {
        try{
            JSONObject o = new JSONObject();
            o.put("range",range);
            o.put("majorDimension",majorDimension);
            JSONArray values_json = new JSONArray();
            for (String[] row: values)
            {
                JSONArray row_json = new JSONArray();
                for (String s: row)
                {
                    row_json.put(s);
                }
                values_json.put(row_json);
            }
            o.put("values",values_json);
            return o;
        }
        catch(org.json.JSONException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    private interface batchUpdateCallback{
        void onUpdate();
    }

    private void batchUpdate(String[][] values, String range, majorDimension md, ValueInputOption vio, final batchUpdateCallback buc, Context c)
    {
        try{
            String baseCommand = base + spreadsheetID + "/values:batchUpdate";
            String mdS = majorDimensionToString(md);
            String vioS = ValueInputOptionToString(vio);
            String[] paramKeys = {ACCESS_TOKEN_NAME};
            String[] paramValues = {access_token};
            JSONObject mainObject = new JSONObject();
            //mainObject.put(ACCESS_TOKEN_NAME,access_token);
            baseCommand = addKeyValuePairsToUrl(paramKeys,paramValues,baseCommand);
            mainObject.put("valueInputOption", vioS);
            JSONArray data = new JSONArray();
            JSONObject valueRange = makeValueRange(values,range,mdS);
            data.put(valueRange);
            mainObject.put("data",data);
            VolleyCallback v = new VolleyCallback() {
                @Override
                public void onSuccess(String result) {
                    if (buc != null)
                    {
                        buc.onUpdate();
                    }
                }
            };
            postJSONWithVolley(baseCommand,mainObject,v,c);
        }
        catch (org.json.JSONException e)
        {
            e.printStackTrace();
        }
    }

    private void batchUpdate(String[][] values, String range, final batchUpdateCallback buc, Context c)
    {
        majorDimension md = majorDimension.ROWS;
        ValueInputOption vio = ValueInputOption.RAW;
        batchUpdate(values,range,md,vio,buc,c);
    }

    private static String getSecondPointWithFirstPointAndStringArray(String[][] array, String point1)
    {
        int maxLengthOfArray = 0;
        for (String[] row: array)
        {
            maxLengthOfArray = Math.max(maxLengthOfArray,row.length);
        }
        int heightOfArray = array.length;
        char point1x = point1.charAt(0);
        int point1y = Integer.parseInt(point1.substring(1));
        char point2x = (char)((int) point1x + maxLengthOfArray - 1);
        int point2y = point1y + heightOfArray - 1;
        return "" + point2x + point2y;
    }

    public interface databaseResetCallback{
        void onReset();
    }

    /**
     * this resets the entire database permanently and all the data is lost. DO NOT CALL THIS METHOD
     * @param drc the thing to do after the database is reset
     */
    public void resetEntireDatabase(final databaseResetCallback drc, Context c)
    {
        //this is for debugging, the app should never actually use this
        String[][] defaultValue = {
               {"last row:","8","","","","","","","","","","",""},
               {"total clubs:","0","","","","","","","","","","",""},
               {"total users:","0","","","","","","","","","","",""},
               {"last used club id:","0","","","","","","","","","","",""},
               {"last used user id:","0","","","","","","","","","","",""},
               {"","","","","","","","","","","","",""},
               {"CLUBS","","","","","","","","","USERS","","","","",""},
               {"ID","NAME","DESCRIPTION","MEMBERS","LEADERS","PENDINGJOINREQUESTS","IMAGE_PATH","CALENDAR","LOCATION","MEETING TIME","ATTENDACE","","ID","NAME","CLUBMEMBERSHIPS","CLUBLEADERSHIPS","PENDINGCLUBREQUESTS","RANK (u for user, m for moderator","SECRET PASSWORD"}
         };
        updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
            @Override
            public void onUpdateState() {
                if (drc != null)
                {
                    drc.onReset();
                }
            }
        };
        updateDatabaseState(defaultValue, udsc,c);
    }

    public interface refreshCallback{
        void onRefresh();
    }

    /**
     * refreshes the local information from the spreadsheet
     * @param rc the action to perform after it has done this
     */
    public void refreshDatabase(final refreshCallback rc, final Context c)
    {
        databaseStatisticsSyncCallback dssc = new databaseStatisticsSyncCallback() {
            @Override
            public void onFinishSync() {
                //after it syncs statistics: use that information to find the last used row, and then request the entire spreadsheet
                String range = "A1:" + LAST_USED_COLUMN + lastUsedRow;
                batchGetCallback bgc = new batchGetCallback() {
                    @Override
                    public void onSuccess(String[][] response) {
                        //after it gets the entire spreadsheet, parse it and store that info
                        databaseState = response;
                        parseDatabaseState();
                        if (rc != null)
                        {
                            rc.onRefresh();
                        }
                    }
                };
                batchGet(range, bgc,c);
            }
        };
        syncDatabaseStatistics(dssc,c);
    }

    private void parseDatabaseState()
    {
        ArrayList<ClubObject> clubs = new ArrayList<>();
        ArrayList<User> users = new ArrayList<>();

        ArrayList<ArrayList<Integer>> membersToAddToClubs = new ArrayList<>();
        ArrayList<ArrayList<Integer>> leadersToAddToClubs = new ArrayList<>();
        ArrayList<ArrayList<Integer>> pendingJoinUsersToAddToClubs = new ArrayList<>();

        ArrayList<ArrayList<Integer>> clubMembershipsToAddToUsers = new ArrayList<>();
        ArrayList<ArrayList<Integer>> clubLeadershipsToAddToUsers = new ArrayList<>();
        ArrayList<ArrayList<Integer>> clubPendingRequestsToAddToUsers = new ArrayList<>();

        for (int i = firstUsedRowForData - 1; i < databaseState.length; i++)
        {
            String[] row = databaseState[i];
            if (row[0] != null && row[0].length()> 0 && !row[0].equals(deletedString))
            {
                int clubID = Integer.parseInt(row[0]);
                String clubName = row[1];
                String clubDescription = row[2];
                ArrayList<Integer> memberIDs = commaSeparatedValuesToIntArray(row[3]);
                ArrayList<Integer> leaderIDs = commaSeparatedValuesToIntArray(row[4]);
                ArrayList<Integer> pendingJoinIDs = commaSeparatedValuesToIntArray(row[5]);
                String imagePath = row[6];
                String calendarString = row[7];
                ClubCalendar cal;
                if (calendarString != null && calendarString.length()!=0)
                {
                    cal = stringToClubCalendar(calendarString);
                }
                else
                {
                    cal = new ClubCalendar(new ArrayList<CalendarEvent>());
                }
                String location = row[8];
                String meetingTime = row[9];
                String attendance = row[10];
                ClubAttendanceObject attendanceObject = ClubAttendanceObject.StringToClubAttendanceObject(attendance);
                ClubObject c = new ClubObject(new ArrayList<User>(), new ArrayList<User>(), clubDescription, clubName, clubID, new ArrayList<User>(), imagePath, cal,location,meetingTime,attendanceObject);
                clubs.add(c);
                membersToAddToClubs.add(memberIDs);
                leadersToAddToClubs.add(leaderIDs);
                pendingJoinUsersToAddToClubs.add(pendingJoinIDs);
            }

            if (row[numColumnsInClubList + 1] != null && row[numColumnsInClubList + 1].length() > 0 && !row[numColumnsInClubList + 1].equals(deletedString))
            {
                int userID = Integer.parseInt(row[numColumnsInClubList + 1]);
                String userName = row[numColumnsInClubList + 2];
                ArrayList<Integer> membershipIDs = commaSeparatedValuesToIntArray(row[numColumnsInClubList + 3]);
                ArrayList<Integer> leadershipIDs = commaSeparatedValuesToIntArray(row[numColumnsInClubList + 4]);
                ArrayList<Integer> pendingRequestIDs = commaSeparatedValuesToIntArray(row[numColumnsInClubList + 5]);
                String rank_S = row[numColumnsInClubList + 6];
                User.Rank rank;
                if (rank_S.charAt(0) == 'u')
                {
                    rank = User.Rank.USER;
                }
                else
                {
                    rank = User.Rank.MODERATOR;
                }
                String secretPassword = row[numColumnsInClubList + 7];
                User u = new User(userName,userID,rank,new ArrayList<ClubObject>(),new ArrayList<ClubObject>(), new ArrayList<ClubObject>(),secretPassword);
                users.add(u);
                clubMembershipsToAddToUsers.add(membershipIDs);
                clubLeadershipsToAddToUsers.add(leadershipIDs);
                clubPendingRequestsToAddToUsers.add(pendingRequestIDs);
            }
        }
        for (int userIndex = 0; userIndex < users.size(); userIndex++)
        {
            User thisUser = users.get(userIndex);
            ArrayList<Integer> clubMembershipIDsToAddToThisUser = clubMembershipsToAddToUsers.get(userIndex);
            for (int clubIdToAdd: clubMembershipIDsToAddToThisUser)
            {
                for (int clubSearchIndex = 0; clubSearchIndex < clubs.size(); clubSearchIndex++)
                {
                    ClubObject c = clubs.get(clubSearchIndex);
                    if (c.getID() == clubIdToAdd)
                    {
                        thisUser.addClubMembership_warningOnlyAffectsLocalData(c);
                    }
                }
            }
            ArrayList<Integer> clubLeadershipIDsToAddToThisUser = clubLeadershipsToAddToUsers.get(userIndex);
            for (int clubIdToAdd: clubLeadershipIDsToAddToThisUser)
            {
                for (int clubSearchIndex = 0; clubSearchIndex < clubs.size(); clubSearchIndex++)
                {
                    ClubObject c = clubs.get(clubSearchIndex);
                    if (c.getID() == clubIdToAdd)
                    {
                        thisUser.addClubLeadership_warningOnlyAffectsLocalData(c);
                    }
                }
            }
            ArrayList<Integer> clubPendingRequestsIDsToAddToThisUser = clubPendingRequestsToAddToUsers.get(userIndex);
            for (int clubIdToAdd: clubPendingRequestsIDsToAddToThisUser)
            {
                for (int clubSearchIndex = 0; clubSearchIndex < clubs.size(); clubSearchIndex++)
                {
                    ClubObject c = clubs.get(clubSearchIndex);
                    if (c.getID() == clubIdToAdd)
                    {
                        thisUser.addClubJoinRequest_warningOnlyAffectsLocalData(c);
                    }
                }
            }
        }
        for (int clubIndex = 0; clubIndex < clubs.size(); clubIndex++)
        {
            ClubObject thisClub = clubs.get(clubIndex);
            ArrayList<Integer> memberIDsToAddToThisClub = membersToAddToClubs.get(clubIndex);
            for (int userIdToAdd: memberIDsToAddToThisClub)
            {
                for (int userSearchIndex = 0; userSearchIndex < users.size(); userSearchIndex++)
                {
                    User u = users.get(userSearchIndex);
                    if (u.getID() == userIdToAdd)
                    {
                        thisClub.addMember_warningOnlyAffectsLocalData(u);
                    }
                }
            }
            ArrayList<Integer> leaderIDsToAddToThisClub = leadersToAddToClubs.get(clubIndex);
            for (int userIdToAdd: leaderIDsToAddToThisClub)
            {
                for (int userSearchIndex = 0; userSearchIndex < users.size(); userSearchIndex++)
                {
                    User u = users.get(userSearchIndex);
                    if (u.getID() == userIdToAdd)
                    {
                        thisClub.addLeader_warningOnlyAffectsLocalData(u);
                    }
                }
            }
            ArrayList<Integer> pendingJoinIDsToAddToThisClub = pendingJoinUsersToAddToClubs.get(clubIndex);
            for (int userIdToAdd: pendingJoinIDsToAddToThisClub)
            {
                for (int userSearchIndex = 0; userSearchIndex < users.size(); userSearchIndex++)
                {
                    User u = users.get(userSearchIndex);
                    if (u.getID() == userIdToAdd)
                    {
                        thisClub.addPendingJoinUser_warningOnlyAffectsLocalData(u);
                    }
                }
            }
        }
        allClubs = clubs;
        allUsers = users;
    }

    /**
     * get an arraylist of all clubs, as of whenever this was last refreshed.
     * Each club has the correct information about what members, leaders, pending join users, etc. that it has
     * @return the arraylist
     */
    public ArrayList<ClubObject> getAllClubs(){return allClubs;}

    /**
     * get an arraylist of all users, as of whenever this was last refreshed.
     * Each user has the correct information about what relationships they have with which clubs, etc.
     * @return
     */
    public ArrayList<User> getAllUsers(){return allUsers;}

    private interface updateDatabaseStateCallback{
        void onUpdateState();
    }

    private void updateDatabaseState(String[][] newState, final updateDatabaseStateCallback udsc, Context c)
    {
        String point1 = topLeftOfSheet;
        String point2 = getSecondPointWithFirstPointAndStringArray(newState, point1);
        String range = point1 + ":" + point2;
        batchUpdateCallback buc = new batchUpdateCallback() {
            @Override
            public void onUpdate() {
                if (udsc != null)
                {
                    udsc.onUpdateState();
                }
            }
        };
        batchUpdate(newState,range,buc,c);
    }

    public interface addClubCallback{
        void onAdd(int idOfNewClub);
    }

    private String[][] copyDatabaseState()
    {
        String[][] copyOfDatabaseState = new String[databaseState.length][0];
        for (int i = 0; i < databaseState.length; i++)
        {
            copyOfDatabaseState[i] = new String[databaseState[i].length];
            for (int j = 0; j < databaseState[i].length; j++)
            {
                copyOfDatabaseState[i][j] = databaseState[i][j];
            }
        }
        return copyOfDatabaseState;
    }

    /**
     * Add a new club to the database
     * @param name The name of the new club
     * @param description The description of the new club
     * @param imagePath the path to the image of the new club
     * @param acc The thing to do after the club has been added to the database, given whatever the ID of the new club is.
     */
    public void addClub(String name, String description, String imagePath, final addClubCallback acc, final Context c)
    {
        String[][] copyOfDatabaseState = copyDatabaseState();
        String[][] newState = null;
        int lastUsedClubIndex = getIndexOfClubInDatabase(lastUsedClubId,copyOfDatabaseState);
        int insertionIndex = -100000;
        boolean databaseHasEnoughRows = false;
        if (lastUsedClubIndex >= 0)
        {
            //if it has found the last club (if it hasn't been deleted)
            if (lastUsedClubIndex + 1 < copyOfDatabaseState.length)
            {
                databaseHasEnoughRows = true;
            }
            insertionIndex = lastUsedClubIndex + 1;
            newState = copyOfDatabaseState;
        }
        else
        {
            //if the last club has been deleted
            for (int i = 8; i < copyOfDatabaseState.length; i++)
            {
                if ((copyOfDatabaseState[i][0] == null || copyOfDatabaseState[i][0].equals("")) && !databaseHasEnoughRows)
                {
                    insertionIndex = i;
                    databaseHasEnoughRows = true;
                    newState = copyOfDatabaseState;
                }
            }
        }
        if (!databaseHasEnoughRows)
        {
            //if the database doesn't have enough rows, add another one
            newState = new String[copyOfDatabaseState.length + 1][0];
            for (int i = 0; i < copyOfDatabaseState.length; i++)
            {
                newState[i] = copyOfDatabaseState[i];
            }
            insertionIndex = copyOfDatabaseState.length;
            newState[copyOfDatabaseState.length] = new String[numColumnsInClubList + numColumnsInUserList + 1];
        }
        newState[insertionIndex][0] = "" + (lastUsedClubId + 1);
        newState[insertionIndex][1] = name;
        newState[insertionIndex][2] = description;
        newState[insertionIndex][6] = imagePath;
        newState[0][1] = "" + newState.length;
        newState[1][1] = "" + (totalClubs + 1);
        newState[3][1] = "" + (lastUsedClubId + 1);
        final int totalClubsAfterUpdate = totalClubs + 1;
        updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
            @Override
            public void onUpdateState() {
                //after the database is updated, refresh the local copy
                refreshCallback rc = new refreshCallback() {
                    //after the local copy is refreshed, do whatever the callback for this function is
                    @Override
                    public void onRefresh() {
                        if (acc != null)
                        {
                            acc.onAdd(totalClubsAfterUpdate);
                        }
                    }
                };
                refreshDatabase(rc,c);
            }
        };
        updateDatabaseState(newState,udsc,c);
    }

    private static String generateSecretPassword()
    {
        String alphanum = "abcdefghijklmnopqrstuvwxyz1234567890";
        Random r = new Random();
        int length = 10;
        String pw = "";
        for (int i = 0; i < length; i++)
        {
            pw = pw + alphanum.charAt(r.nextInt(alphanum.length()));
        }
        return pw;
    }

    public interface addUserCallback{
        void onAdd(int idOfNewUser, String generatedSecretPassword);
    }


    /**
     * Add a new user to the database
     * @param name the name of the new user.
     * @param auc The thing to do after the user has been added to the database, given what the ID of the new user is.
     */
    public void addUser(String name, final addUserCallback auc, final Context c)
    {
        String[][] copyOfDatabaseState = copyDatabaseState();
        String[][] newState = null;
        //int lastUsedClubIndex = getIndexOfClubInDatabase(lastUsedClubId,copyOfDatabaseState);
        int lastUsedUserIndex = getIndexOfUserInDatabase(lastUsedUserId,copyOfDatabaseState);
        int insertionIndex = -100000;
        boolean databaseHasEnoughRows = false;
        final String secretPassword = generateSecretPassword();
        if (lastUsedUserIndex >= 0)
        {
            //if it has found the last user (if it hasn't been deleted)
            if (lastUsedUserIndex + 1 < copyOfDatabaseState.length)
            {
                databaseHasEnoughRows = true;
            }
            insertionIndex = lastUsedUserIndex + 1;
            newState = copyOfDatabaseState;
        }
        else
        {
            //if the last user has been deleted
            for (int i = 8; i < copyOfDatabaseState.length; i++)
            {
                if ((copyOfDatabaseState[i][numColumnsInClubList + 1] == null || copyOfDatabaseState[i][numColumnsInClubList + 1].equals("")) && !databaseHasEnoughRows)
                {
                    insertionIndex = i;
                    databaseHasEnoughRows = true;
                    newState = copyOfDatabaseState;
                }
            }
        }
        if (!databaseHasEnoughRows)
        {
            //if the database doesn't have enough rows, add another one
            newState = new String[copyOfDatabaseState.length + 1][0];
            for (int i = 0; i < copyOfDatabaseState.length; i++)
            {
                newState[i] = copyOfDatabaseState[i];
            }
            insertionIndex = copyOfDatabaseState.length;
            newState[copyOfDatabaseState.length] = new String[numColumnsInClubList + numColumnsInUserList + 1];
        }
        newState[insertionIndex][numColumnsInClubList + 1] = "" + (lastUsedUserId + 1);
        newState[insertionIndex][numColumnsInClubList + 2] = name;
        newState[insertionIndex][numColumnsInClubList + 6] = "u";
        newState[insertionIndex][numColumnsInClubList + 7] = secretPassword;
        newState[0][1] = "" + newState.length;
        newState[2][1] = "" + (totalUsers + 1);
        newState[4][1] = "" + (lastUsedUserId + 1);
        final int totalClubsAfterUpdate = totalClubs + 1;
        final int copyOfLastUsedUserID = lastUsedUserId;
        updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
            @Override
            public void onUpdateState() {
                //after the database is updated, refresh the local copy
                refreshCallback rc = new refreshCallback() {
                    //after the local copy is refreshed, do whatever the callback for this function is
                    @Override
                    public void onRefresh() {
                        if (auc != null)
                        {
                            auc.onAdd(copyOfLastUsedUserID + 1, secretPassword);
                        }
                    }
                };
                refreshDatabase(rc,c);
            }
        };
        updateDatabaseState(newState,udsc,c);
    }

    private static String getCommaSeparatedValues(ArrayList<Integer> values)
    {
        String r = "";
        if (values.size() != 0)
        {
            r = r + values.get(0);
            for (int i = 1; i < values.size(); i++)
            {
                r = r + "," + values.get(i);
            }
        }
        return r;
    }

    private static ArrayList<Integer> commaSeparatedValuesToIntArray(String csv)
    {
        Scanner sc = new Scanner(csv);
        sc.useDelimiter(",");
        ArrayList<Integer> values_AL = new ArrayList<>();
        while (sc.hasNextInt())
        {
            values_AL.add(sc.nextInt());
        }
        return values_AL;
    }

    private static int getIndexOfClubInDatabase(int id, String[][] state)
    {
        for (int i = 8; i < state.length; i++)
        {
            if (state[i][0] != null && state[i][0].equals(Integer.toString(id)))
            {
                return i;
            }
        }
        return -10000;
    }

    private static int getIndexOfUserInDatabase(int id, String[][] state)
    {
        for (int i = 8; i < state.length; i++)
        {
            if (state[i][numColumnsInClubList + 1] != null && state[i][numColumnsInClubList + 1].equals(Integer.toString(id)))
            {
                return i;
            }
        }
        return -10000;
    }

    public interface addUserToClubCallback{
        void onAddUser();
    }

    private static String addValueToCSV(String csv, int value)
    {
        ArrayList<Integer> csvl = commaSeparatedValuesToIntArray(csv);
        Collections.sort(csvl);
        int i = Collections.binarySearch(csvl,value);
        if (i < 0)
        {
            int insertionPoint = -1 * (i + 1);
            csvl.add(insertionPoint,value);
        }
        String csv2 = getCommaSeparatedValues(csvl);
        return csv2;
    }

    private static String removeValueFromCSV(String csv, int value)
    {
        ArrayList<Integer> csvl = commaSeparatedValuesToIntArray(csv);
        Collections.sort(csvl);
        int i = Collections.binarySearch(csvl,value);
        if (i >= 0)
        {
            csvl.remove(i);
        }
        String csv2 = getCommaSeparatedValues(csvl);
        return csv2;
    }

    private static int searchForUser(ArrayList<User> users, int userID)
    {
        int index = -1;
        for (int i = 0; i < users.size(); i++)
        {
            if (users.get(i).getID() == userID)
            {
                index = i;
            }
        }
        return index;
    }

    private static int searchForClub(ArrayList<ClubObject> clubs, int clubID)
    {
        int index = -1;
        for (int i = 0; i < clubs.size(); i++)
        {
            if (clubs.get(i).getID() == clubID)
            {
                index = i;
            }
        }
        return index;
    }

    /**
     * make it so that a user is a member of a club
     * @param userID The user that will be the member of the club
     * @param clubID The club that the user will be a member of
     * @param autcc What to do after the action has been performed
     */
    public void addUserToClub(int userID, int clubID, final addUserToClubCallback autcc, final Context c)
    {
        boolean clubExists = (searchForClub(allClubs,clubID) > -1);
        boolean userExists = (searchForUser(allUsers,userID) > -1);
        if (clubExists && userExists)
        {
            String[][] copyOfDatabaseState = copyDatabaseState();
            //copyOfDatabaseState = addMemberToClubInDatabaseState(userID,clubID,copyOfDatabaseState);
            //copyOfDatabaseState = addClubMembershipToUserInDatabaseState(userID,clubID,copyOfDatabaseState);
            copyOfDatabaseState = coupleMemberAndClubInDatabaseState(userID,clubID,copyOfDatabaseState);
            updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
                @Override
                public void onUpdateState() {
                    //after the database is updated, refresh the local copy
                    refreshCallback rc = new refreshCallback() {
                        @Override
                        public void onRefresh() {
                            //after the local copy is refreshed, do whatever the callback for this function is
                            if (autcc != null)
                            {
                                autcc.onAddUser();
                            }
                        }
                    };
                    refreshDatabase(rc,c);
                }
            };
            updateDatabaseState(copyOfDatabaseState,udsc,c);
        }
    }

    private static String[][] coupleMemberAndClubInDatabaseState(int userID, int clubID, String[][] state)
    {
        state = addMemberToClubInDatabaseState(userID, clubID, state);
        state = addClubMembershipToUserInDatabaseState(userID, clubID, state);
        return state;
    }

    private static String[][] addMemberToClubInDatabaseState(int userID, int clubID, String[][] state)
    {
        int indexOfClub = getIndexOfClubInDatabase(clubID,state);
        String csv = state[indexOfClub][3];
        String csv2 = addValueToCSV(csv,userID);
        state[indexOfClub][3] = csv2;
        return state;
    }

    private static String[][] addClubMembershipToUserInDatabaseState(int userID, int clubID, String[][] state)
    {
        int indexOfUser = getIndexOfUserInDatabase(userID,state);
        String csv = state[indexOfUser][numColumnsInClubList + 3];
        String csv2 = addValueToCSV(csv, clubID);
        state[indexOfUser][numColumnsInClubList + 3] = csv2;
        return state;
    }

    public interface addLeaderToClubCallback{
        void onAddLeader();
    }

    /**
     * make it so that a user is a leader of a club
     * @param userID the user that will be the leader of the club
     * @param clubID the club that the user will be a leader of
     * @param altcc what to do after this action has been performed
     */
    public void addLeaderToClub(int userID, int clubID, final addLeaderToClubCallback altcc, final Context c)
    {
        boolean clubExists = (searchForClub(allClubs,clubID) > -1);
        boolean userExists = (searchForUser(allUsers,userID) > -1);
        if (clubExists && userExists)
        {
            String[][] copyOfDatabaseState = copyDatabaseState();
            //copyOfDatabaseState = addLeaderToClubInDatabaseState(userID,clubID,copyOfDatabaseState);
            //copyOfDatabaseState = addCLubLeadershipToUserInDatabaseState(userID,clubID,copyOfDatabaseState);
            copyOfDatabaseState = coupleLeaderAndClubInDatabaseState(userID,clubID,copyOfDatabaseState);
            updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
                @Override
                public void onUpdateState() {
                    //after the database is updated, refresh the local copy
                    refreshCallback rc = new refreshCallback() {
                        @Override
                        public void onRefresh() {
                            //after the local copy is refreshed, do whatever the callback for this function is
                            if (altcc != null)
                            {
                                altcc.onAddLeader();
                            }
                        }
                    };
                    refreshDatabase(rc,c);
                }
            };
            updateDatabaseState(copyOfDatabaseState,udsc,c);
        }
    }

    public static String[][] coupleLeaderAndClubInDatabaseState(int userID, int clubID, String[][] state)
    {
        state = addLeaderToClubInDatabaseState(userID,clubID,state);
        state = addCLubLeadershipToUserInDatabaseState(userID,clubID,state);
        return state;
    }

    private static String[][] addLeaderToClubInDatabaseState(int userID, int clubID, String[][] state)
    {
        int indexOfClub = getIndexOfClubInDatabase(clubID,state);
        String csv = state[indexOfClub][4];
        String csv2 = addValueToCSV(csv,userID);
        state[indexOfClub][4] = csv2;
        return state;
    }

    private static String[][] addCLubLeadershipToUserInDatabaseState(int userID, int clubID, String[][] state)
    {
        int indexOfUser = getIndexOfUserInDatabase(userID,state);
        String csv = state[indexOfUser][numColumnsInClubList + 4];
        String csv2 = addValueToCSV(csv, clubID);
        state[indexOfUser][numColumnsInClubList + 4] = csv2;
        return state;
    }

    public interface addPendingJoinUserToClubCallback{
        void onAddPendingJoinUser();
    }

    /**
     * add a user's request to join a club to the database, which a leader of that club can accept, or deny later
     * @param userID the user whose request will be added
     * @param clubID the club that the user is requesting to join
     * @param apjutcc what to do after this action has been performed
     */
    public void addPendingJoinUserToClub(int userID, int clubID, final addPendingJoinUserToClubCallback apjutcc, final Context c)
    {
        boolean clubExists = (searchForClub(allClubs,clubID) > -1);
        boolean userExists = (searchForUser(allUsers,userID) > -1);
        if (clubExists && userExists)
        {
            String[][] copyOfDatabaseState = copyDatabaseState();
            //copyOfDatabaseState = addPendingJoinUserToClubInDatabaseState(userID,clubID,copyOfDatabaseState);
            //copyOfDatabaseState = addPendingJoinRequestToUserInDatabaseState(userID,clubID,copyOfDatabaseState);
            copyOfDatabaseState = couplePendingJoinUserAndClubInDatabaseState(userID,clubID,copyOfDatabaseState);
            updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
                @Override
                public void onUpdateState() {
                    //after the database is updated, refresh the local copy
                    refreshCallback rc = new refreshCallback() {
                        @Override
                        public void onRefresh() {
                            //after the local copy is refreshed, do whatever the callback for this function is
                            if (apjutcc != null)
                            {
                                apjutcc.onAddPendingJoinUser();
                            }
                        }
                    };
                    refreshDatabase(rc,c);
                }
            };
            updateDatabaseState(copyOfDatabaseState,udsc,c);
        }
    }

    public static String[][] couplePendingJoinUserAndClubInDatabaseState(int userID, int clubID, String[][] state)
    {
        state = addPendingJoinRequestToUserInDatabaseState(userID,clubID,state);
        state = addPendingJoinUserToClubInDatabaseState(userID,clubID,state);
        return state;
    }

    private static String[][] addPendingJoinUserToClubInDatabaseState(int userID, int clubID, String[][] state)
    {
        int indexOfClub = getIndexOfClubInDatabase(clubID,state);
        String csv = state[indexOfClub][5];
        String csv2 = addValueToCSV(csv,userID);
        state[indexOfClub][5] = csv2;
        return state;
    }

    private static String[][] addPendingJoinRequestToUserInDatabaseState(int userID, int clubID, String[][] state)
    {
        int indexOfUser = getIndexOfUserInDatabase(userID,state);
        String csv = state[indexOfUser][numColumnsInClubList + 5];
        String csv2 = addValueToCSV(csv, clubID);
        state[indexOfUser][numColumnsInClubList + 5] = csv2;
        return state;
    }

    public interface updateClubDescriptionCallback{
        void onUpdateDescription();
    }

    /**
     * Change the description of a club to something else in the database (refreshes automatically)
     * @param clubID the id of the club whose description will be changed
     * @param newDescription the new description that it will be changed to
     * @param ucdc what to do after this action has been performed
     */
    public void updateDescriptionOfClub(int clubID, String newDescription, final updateClubDescriptionCallback ucdc, final Context c)
    {
        boolean clubExists = (searchForClub(allClubs,clubID) > -1);
        if (clubExists)
        {
            String[][] copyOfDatabaseState = copyDatabaseState();
            int indexOfClub = getIndexOfClubInDatabase(clubID, copyOfDatabaseState);
            copyOfDatabaseState[indexOfClub][2] = newDescription;
            updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
                @Override
                public void onUpdateState() {
                    //after the database is updated, refresh the local copy
                    refreshCallback rc = new refreshCallback() {
                        @Override
                        public void onRefresh() {
                            //after the local copy is refreshed, do whatever the callback for this function is
                            if (ucdc != null)
                            {
                                ucdc.onUpdateDescription();
                            }
                        }
                    };
                    refreshDatabase(rc,c);
                }
            };
            updateDatabaseState(copyOfDatabaseState,udsc,c);
        }
    }

    public interface updateClubNameCallback{
        void onUpdateName();
    }

    /**
     * change the name of a club to somehting else in the database (refreshes automatically)
     * @param clubID the club whose name will be changed
     * @param newName the new name of the club
     * @param ucnc what to do after this action has been performed
     */
    public void updateNameOfClub(int clubID, String newName, final updateClubNameCallback ucnc, final Context c)
    {
        boolean clubExists = (searchForClub(allClubs,clubID) > -1);
        if (clubExists)
        {
            String[][] copyOfDatabaseState = copyDatabaseState();
            int indexOfClub = getIndexOfClubInDatabase(clubID, copyOfDatabaseState);
            copyOfDatabaseState[indexOfClub][1] = newName;
            updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
                @Override
                public void onUpdateState() {
                    //after the database is updated, refresh the local copy
                    refreshCallback rc = new refreshCallback() {
                        @Override
                        public void onRefresh() {
                            //after the local copy is refreshed, do whatever the callback for this function is
                            if (ucnc != null)
                            {
                                ucnc.onUpdateName();
                            }
                        }
                    };
                    refreshDatabase(rc,c);
                }
            };
            updateDatabaseState(copyOfDatabaseState,udsc,c);
        }
    }

    public interface updateImagePathCallback{
        void onUpdateImagePath();
    }

    /**
     * change the image path associated with a club to something else
     * @param clubID the club whose image path will be changed
     * @param newPath the new image path
     * @param uipc what to do after this action has been performed
     */
    public void updateImagePathOfClub(int clubID, String newPath, final updateImagePathCallback uipc, final Context c)
    {
        boolean clubExists = (searchForClub(allClubs,clubID) > -1);
        if(clubExists)
        {
            String[][] copyOfDatabaseState = copyDatabaseState();
            int indexOfClub = getIndexOfClubInDatabase(clubID, copyOfDatabaseState);
            copyOfDatabaseState[indexOfClub][6] = newPath;
            updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
                @Override
                public void onUpdateState() {
                    //after the database is updated, refresh the local copy
                    refreshCallback rc = new refreshCallback() {
                        @Override
                        public void onRefresh() {
                            //after the local copy is refreshed, do whatever the callback for this function is
                            if (uipc != null)
                            {
                                uipc.onUpdateImagePath();
                            }
                        }
                    };
                    refreshDatabase(rc,c);
                }
            };
            updateDatabaseState(copyOfDatabaseState,udsc,c);
        }
    }

    public interface updateUserRankCallback{
        void onUpdateRank();
    }

    /**
     * change the rank of the user either from user to moderator, or vice versa (refreshes automatically)
     * @param userID the user whose rank to change
     * @param newRank the new rank of the user
     * @param uurc what to do after this action has been performed
     */
    public void updateRankOfUser(int userID, User.Rank newRank, final updateUserRankCallback uurc, final Context c)
    {
        boolean userExists = (searchForUser(allUsers,userID) > -1);
        if (userExists)
        {
            String[][] copyOfDatabaseState = copyDatabaseState();
            int userIndex = getIndexOfUserInDatabase(userID,copyOfDatabaseState);
            String rankString;
            switch(newRank){
                case MODERATOR:
                    rankString = "m";
                    break;
                default: //case USER:
                    rankString = "u";
                    break;
            }
            copyOfDatabaseState[userIndex][numColumnsInClubList + 6] = rankString;
            updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
                @Override
                public void onUpdateState() {
                    //after the database is updated, refresh the local copy
                    refreshCallback rc = new refreshCallback() {
                        @Override
                        public void onRefresh() {
                            //after the local copy is refreshed, do whatever the callback for this function is
                            if (uurc != null)
                            {
                                uurc.onUpdateRank();
                            }
                        }
                    };
                    refreshDatabase(rc,c);
                }
            };
            updateDatabaseState(copyOfDatabaseState,udsc,c);
        }
    }

    public interface updateUserNameCallback{
        void onUpdateName();
    }

    /**
     * Change the name of a user to something else (refreshes automatically)
     * @param userID the user whose name to change
     * @param newName the new name of the user
     * @param uunc what to do after this action has been performed
     */
    public void updateNameOfUser(int userID, String newName, final updateUserNameCallback uunc, final Context c)
    {
        boolean userExists = (searchForUser(allUsers,userID) > -1);
        if (userExists)
        {
            String[][] copyOfDatabaseState = copyDatabaseState();
            int userIndex = getIndexOfUserInDatabase(userID,copyOfDatabaseState);
            copyOfDatabaseState[userIndex][numColumnsInClubList + 2] = newName;
            updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
                @Override
                public void onUpdateState() {
                    //after the database is updated, refresh the local copy
                    refreshCallback rc = new refreshCallback() {
                        @Override
                        public void onRefresh() {
                            //after the local copy is refreshed, do whatever the callback for this function is
                            if (uunc != null)
                            {
                                uunc.onUpdateName();
                            }
                        }
                    };
                    refreshDatabase(rc,c);
                }
            };
            updateDatabaseState(copyOfDatabaseState,udsc,c);
        }
    }

    public interface removeUserFromClubCallback{
        void onRemoveUser();
    }

    /**
     * make it so that a user isn't a member or leader of a club anymore (refreshes automatically)
     * @param userID the member to remove from the club
     * @param clubID the club to remove the member from
     * @param rufcc what to do after this action has been performed
     */
    public void removeUserFromClub(int userID, int clubID, final removeUserFromClubCallback rufcc, final Context c)
    {
        boolean clubExists = (searchForClub(allClubs,clubID) > -1);
        boolean userExists = (searchForUser(allUsers,userID) > -1);
        if (userExists && clubExists)
        {
            String[][] copyOfDatabaseState = copyDatabaseState();
            //copyOfDatabaseState = removeMemberFromClubInDatabaseState(userID,clubID,copyOfDatabaseState);
            //copyOfDatabaseState = removeClubMembershipFromUserInDatabaseState(userID,clubID,copyOfDatabaseState);
            copyOfDatabaseState = decoupleMemberAndClubInDatabaseState(userID,clubID,copyOfDatabaseState);
            copyOfDatabaseState = decoupleLeaderAndClubInDatabaseState(userID,clubID,copyOfDatabaseState);
            updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
                @Override
                public void onUpdateState() {
                    //after the database is updated, refresh the local copy
                    refreshCallback rc = new refreshCallback() {
                        @Override
                        public void onRefresh() {
                            //after the local copy is refreshed, do whatever the callback for this function is
                            if (rufcc != null)
                            {
                                rufcc.onRemoveUser();
                            }
                        }
                    };
                    refreshDatabase(rc,c);
                }
            };
            updateDatabaseState(copyOfDatabaseState,udsc,c);
        }
    }

    public static String[][] decoupleMemberAndClubInDatabaseState(int userID, int clubID, String[][] state)
    {
        state = removeMemberFromClubInDatabaseState(userID,clubID,state);
        state = removeClubMembershipFromUserInDatabaseState(userID,clubID,state);
        return state;
    }

    private static String[][] removeMemberFromClubInDatabaseState(int userID, int clubID, String[][] state)
    {
        int indexOfClub = getIndexOfClubInDatabase(clubID,state);
        String csv = state[indexOfClub][3];
        String csv2 = removeValueFromCSV(csv,userID);
        state[indexOfClub][3] = csv2;
        return state;
    }

    private static String[][] removeClubMembershipFromUserInDatabaseState(int userID, int clubID, String[][] state)
    {
        int indexOfUser = getIndexOfUserInDatabase(userID,state);
        String csv = state[indexOfUser][numColumnsInClubList + 3];
        String csv2 = removeValueFromCSV(csv,clubID);
        state[indexOfUser][numColumnsInClubList + 3] = csv2;
        return state;
    }

    public interface removeLeaderFromClubCallback{
        void onRemoveLeader();
    }

    /**
     * make it so that a user isn't a leader of a club anymore (refreshes automatically)
     * @param userID the leader to remove from the club
     * @param clubID the club to remove from the leader
     * @param rlfcc what to do after this action has been performed
     */
    public void removeLeaderFromClub(int userID, int clubID, final removeLeaderFromClubCallback rlfcc, final Context c)
    {
        boolean clubExists = (searchForClub(allClubs,clubID) > -1);
        boolean userExists = (searchForUser(allUsers,userID) > -1);
        if (clubExists && userExists)
        {
            String[][] copyOfDatabaseState = copyDatabaseState();
            //copyOfDatabaseState = removeLeaderFromClubInDatabaseState(userID,clubID,copyOfDatabaseState);
            //copyOfDatabaseState = removeCLubLeadershipFromUserInDatabaseState(userID,clubID,copyOfDatabaseState);
            copyOfDatabaseState = decoupleLeaderAndClubInDatabaseState(userID,clubID,copyOfDatabaseState);
            updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
                @Override
                public void onUpdateState() {
                    //after the database is updated, refresh the local copy
                    refreshCallback rc = new refreshCallback() {
                        @Override
                        public void onRefresh() {
                            //after the local copy is refreshed, do whatever the callback for this function is
                            if (rlfcc != null)
                            {
                                rlfcc.onRemoveLeader();
                            }
                        }
                    };
                    refreshDatabase(rc,c);
                }
            };
            updateDatabaseState(copyOfDatabaseState,udsc,c);
        }
    }

    private static String[][] decoupleLeaderAndClubInDatabaseState(int userID, int clubID, String[][] state)
    {
        state = removeLeaderFromClubInDatabaseState(userID,clubID,state);
        state = removeCLubLeadershipFromUserInDatabaseState(userID,clubID,state);
        return state;
    }

    private static String[][] removeLeaderFromClubInDatabaseState(int userID, int clubID, String[][] state)
    {
        int indexOfClub = getIndexOfClubInDatabase(clubID,state);
        String csv = state[indexOfClub][4];
        String csv2 = removeValueFromCSV(csv,userID);
        state[indexOfClub][4] = csv2;
        return state;
    }

    private static String[][] removeCLubLeadershipFromUserInDatabaseState(int userID, int clubID, String[][] state)
    {
        int indexOfUser = getIndexOfUserInDatabase(userID,state);
        String csv = state[indexOfUser][numColumnsInClubList + 4];
        String csv2 = removeValueFromCSV(csv, clubID);
        state[indexOfUser][numColumnsInClubList + 4] = csv2;
        return state;
    }

    public interface removePendingUserRequestCallback{
        void onRemoveRequest();
    }

    /**
     * make is so that a user no longer has a pending request to join a club (refreshes automatically)
     * @param userID the user whose request to remove
     * @param clubID the club that the user was trying to join
     * @param dpurc what to do after this action has been performed
     */
    public void removePendingUserRequest(int userID, int clubID, final removePendingUserRequestCallback dpurc, final Context c)
    {
        boolean clubExists = (searchForClub(allClubs,clubID) > -1);
        boolean userExists = (searchForUser(allUsers,userID) > -1);
        if (clubExists && userExists)
        {
            String[][] copyOfDatabaseState = copyDatabaseState();
            //copyOfDatabaseState = removePendingJoinUserFromClubInDatabaseState(userID,clubID,copyOfDatabaseState);
            //copyOfDatabaseState = removePendingJoinRequestFromUserInDatabaseState(userID,clubID,copyOfDatabaseState);
            copyOfDatabaseState = decouplePendingUserAndClubInDatabaseState(userID,clubID,copyOfDatabaseState);
            updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
                @Override
                public void onUpdateState() {
                    //after the database is updated, refresh the local copy
                    refreshCallback rc = new refreshCallback() {
                        @Override
                        public void onRefresh() {
                            //after the local copy is refreshed, do whatever the callback for this function is
                            if (dpurc != null)
                            {
                                dpurc.onRemoveRequest();
                            }
                        }
                    };
                    refreshDatabase(rc,c);
                }
            };
            updateDatabaseState(copyOfDatabaseState,udsc,c);
        }
    }

    private static String[][] decouplePendingUserAndClubInDatabaseState(int userID, int clubID, String[][] state)
    {
        state = removePendingJoinRequestFromUserInDatabaseState(userID,clubID,state);
        state = removePendingJoinUserFromClubInDatabaseState(userID,clubID,state);
        return state;
    }

    private static String[][] removePendingJoinUserFromClubInDatabaseState(int userID, int clubID, String[][] state)
    {
        int indexOfClub = getIndexOfClubInDatabase(clubID,state);
        String csv = state[indexOfClub][5];
        String csv2 = removeValueFromCSV(csv,userID);
        state[indexOfClub][5] = csv2;
        return state;
    }

    private static String[][] removePendingJoinRequestFromUserInDatabaseState(int userID, int clubID, String[][] state)
    {
        int indexOfUser = getIndexOfUserInDatabase(userID,state);
        String csv = state[indexOfUser][numColumnsInClubList + 5];
        String csv2 = removeValueFromCSV(csv, clubID);
        state[indexOfUser][numColumnsInClubList + 5] = csv2;
        return state;
    }

    public interface acceptPendingUserRequestCallback{
        void onAccept();
    }

    /**
     * accept a pending user request. removes the pending request and then adds the user to the club (refreshes automatically)
     * @param userID the user whose request to accept
     * @param clubID the club that the user was trying to join
     * @param apurc what to do after this action has been performed
     */
    public void acceptPendingUserRequest(final int userID, final int clubID, final acceptPendingUserRequestCallback apurc, final Context c)
    {
        boolean clubExists = (searchForClub(allClubs,clubID) > -1);
        boolean userExists = (searchForUser(allUsers,userID) > -1);
        if (clubExists && userExists)
        {
            String[][] copyOfDatabaseState = copyDatabaseState();
            copyOfDatabaseState = decouplePendingUserAndClubInDatabaseState(userID,clubID,copyOfDatabaseState);
            copyOfDatabaseState = coupleMemberAndClubInDatabaseState(userID,clubID,copyOfDatabaseState);
            updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
                @Override
                public void onUpdateState() {
                    //after the database is updated, refresh the local copy
                    refreshCallback rc = new refreshCallback() {
                        @Override
                        public void onRefresh() {
                            //after the local copy is refreshed, do whatever the callback for this function is
                            if (apurc != null)
                            {
                                apurc.onAccept();
                            }
                        }
                    };
                    refreshDatabase(rc,c);
                }
            };
            updateDatabaseState(copyOfDatabaseState,udsc,c);
        }
    }

    private static String clubCalendarToString(ClubCalendar c)
    {
        try{
            JSONArray events = new JSONArray();
            ArrayList<CalendarEvent> eventsList = c.getEvents();
            for (CalendarEvent e: eventsList)
            {
                JSONObject o = new JSONObject();
                o.put("year",e.getYear());
                o.put("month",e.getMonth());
                o.put("day",e.getDay());
                o.put("name",e.getName());
                o.put("description",e.getDescription());
                events.put(o);
            }
            JSONObject mainObject = new JSONObject();
            mainObject.put("events",events);
            return mainObject.toString();
        }
        catch(org.json.JSONException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    private static ClubCalendar stringToClubCalendar(String c)
    {
        try{
            JSONObject mainObject = new JSONObject(c);
            JSONArray events = mainObject.getJSONArray("events");
            ArrayList<CalendarEvent> eventsList = new ArrayList<>();
            for (int i = 0; i < events.length(); i++)
            {
                JSONObject event = (JSONObject) events.get(i);
                int year = event.getInt("year");
                int month = event.getInt("month");
                int day = event.getInt("day");
                String name = event.getString("name");
                String description = event.getString("description");
                CalendarEvent e = new CalendarEvent(year,month,day,name,description);
                eventsList.add(e);
            }
            ClubCalendar clubCalendar = new ClubCalendar(eventsList);
            return clubCalendar;
        }
        catch(org.json.JSONException e)
        {
            e.printStackTrace();
            return null;
        }
    }

    public interface updateClubCalendarCallback{
        void onUpdateCalendar();
    }

    /**
     * change a club's calendar to a new one (refreshes automatically)
     * @param clubID the club whose calendar to update
     * @param c the new calendar
     * @param uccc what to do after this action has been performed
     */
    public void updateClubCalendar(int clubID, ClubCalendar cal, final updateClubCalendarCallback uccc, final Context c)
    {
        boolean clubExists = (searchForClub(allClubs,clubID) > -1);
        if (clubExists)
        {
            String[][] copyOfDatabaseState = copyDatabaseState();
            int indexOfClub = getIndexOfClubInDatabase(clubID, copyOfDatabaseState);
            String calendarString = clubCalendarToString(cal);
            copyOfDatabaseState[indexOfClub][7] = calendarString;
            updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
                @Override
                public void onUpdateState() {
                    //after the database is updated, refresh the local copy
                    refreshCallback rc = new refreshCallback() {
                        @Override
                        public void onRefresh() {
                            //after the local copy is refreshed, do whatever the callback for this function is
                            if (uccc != null)
                            {
                                uccc.onUpdateCalendar();
                            }
                        }
                    };
                    refreshDatabase(rc,c);
                }
            };
            updateDatabaseState(copyOfDatabaseState,udsc,c);
        }
    }

    public interface updateClubLocationCallback{
        void onUpdateLocation();
    }

    /**
     * change a club's location to a new one (refreshes automatically)
     * @param clubID the club whose location to update
     * @param newLocation the new location
     * @param uclc what to do after this action has been performed
     */
    public void updateClubLocation(int clubID, String newLocation, final updateClubLocationCallback uclc, final Context c)
    {
        boolean clubExists = (searchForClub(allClubs,clubID) > -1);
        if (clubExists)
        {
            String[][] copyOfDatabaseState = copyDatabaseState();
            int indexOfClub = getIndexOfClubInDatabase(clubID,copyOfDatabaseState);
            copyOfDatabaseState[indexOfClub][8] = newLocation;
            updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
                @Override
                public void onUpdateState() {
                    refreshCallback rc = new refreshCallback() {
                        @Override
                        public void onRefresh() {
                            if (uclc != null)
                            {
                                uclc.onUpdateLocation();
                            }
                        }
                    };
                    refreshDatabase(rc,c);
                }
            };
            updateDatabaseState(copyOfDatabaseState,udsc,c);
        }
    }

    public interface updateClubAttendaceCallback{
        void onUpdateAttendace();
    }

    /**
     * change a club's attendance record to a new one (refreshes automatically)
     * @param clubID the club whose attendance to change
     * @param newAttendance the new attendance record
     * @param ucac what to do after this action has been performed
     */
    public void updateClubAttendance(int clubID, ClubAttendanceObject newAttendance, final updateClubAttendaceCallback ucac, final Context c)
    {
        boolean clubExists = (searchForClub(allClubs,clubID) > -1);
        if (clubExists)
        {
            String[][] copyOfDatabaseState = copyDatabaseState();
            int indexOfClub = getIndexOfClubInDatabase(clubID,copyOfDatabaseState);
            copyOfDatabaseState[indexOfClub][10] = ClubAttendanceObject.clubAttendanceObjectToJSONString(newAttendance);
            updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
                @Override
                public void onUpdateState() {
                    refreshCallback rc = new refreshCallback() {
                        @Override
                        public void onRefresh() {
                            if (ucac != null)
                            {
                                ucac.onUpdateAttendace();
                            }
                        }
                    };
                    refreshDatabase(rc,c);
                }
            };
            updateDatabaseState(copyOfDatabaseState,udsc,c);
        }
    }

    public interface updateClubMeetingTimeCallback{
        void onUpdateMeetingTime();
    }

    /**
     * change a club's meeting time to a new one (refreshes automatically)
     * @param clubID the club whose meeting time to update
     * @param newMeetingTime the new meeting time
     * @param ucmtc what to do after this action has been completed
     */
    public void updateClubMeetingTime(int clubID, String newMeetingTime, final updateClubMeetingTimeCallback ucmtc, final Context c)
    {
        boolean clubExists = (searchForClub(allClubs,clubID) > -1);
        if (clubExists)
        {
            String[][] copyOfDatabaseState = copyDatabaseState();
            int indexOfClub = getIndexOfClubInDatabase(clubID,copyOfDatabaseState);
            copyOfDatabaseState[indexOfClub][9] = newMeetingTime;
            updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
                @Override
                public void onUpdateState() {
                    refreshCallback rc = new refreshCallback() {
                        @Override
                        public void onRefresh() {
                            if (ucmtc != null)
                            {
                                ucmtc.onUpdateMeetingTime();
                            }
                        }
                    };
                    refreshDatabase(rc,c);
                }
            };
            updateDatabaseState(copyOfDatabaseState,udsc,c);
        }
    }

    public interface deleteClubCallback{
        void onDelete();
    }

    /**
     * delete a club, removing all user from it, and itself from all users, and from the list
     * @param clubID the club to delete
     * @param dcc what to do after this action had been performed
     */
    public void deleteClub(int clubID, final deleteClubCallback dcc, final Context c)
    {
        String[][] copyOfDatabaseState = copyDatabaseState();
        ClubObject clubToDelete = null;
        for (int i = 0; i < allClubs.size(); i++)
        {
            if (allClubs.get(i).getID() == clubID)
            {
                clubToDelete = allClubs.get(i);
            }
        }
        if (clubToDelete != null)
        {
            copyOfDatabaseState[1][1] = "" + (totalClubs - 1);
            ArrayList<User> membersOfClub = clubToDelete.getMembers();
            ArrayList<User> leadersOfClub = clubToDelete.getLeaders();
            ArrayList<User> pendingJoinUsersOfClub = clubToDelete.getPendingJoinUsers();
            for (User u: membersOfClub)
            {
                copyOfDatabaseState = removeMemberFromClubInDatabaseState(u.getID(),clubID,copyOfDatabaseState);
                copyOfDatabaseState = removeClubMembershipFromUserInDatabaseState(u.getID(),clubID,copyOfDatabaseState);
            }
            for (User u: leadersOfClub)
            {
                copyOfDatabaseState = removeLeaderFromClubInDatabaseState(u.getID(),clubID,copyOfDatabaseState);
                copyOfDatabaseState = removeCLubLeadershipFromUserInDatabaseState(u.getID(),clubID,copyOfDatabaseState);
            }
            for (User u: pendingJoinUsersOfClub)
            {
                copyOfDatabaseState = removePendingJoinUserFromClubInDatabaseState(u.getID(),clubID,copyOfDatabaseState);
                copyOfDatabaseState = removePendingJoinRequestFromUserInDatabaseState(u.getID(),clubID,copyOfDatabaseState);
            }
            int indexOfClub = getIndexOfClubInDatabase(clubID, copyOfDatabaseState);
            copyOfDatabaseState[indexOfClub][0] = deletedString;
            copyOfDatabaseState[indexOfClub][1] = "";
            copyOfDatabaseState[indexOfClub][2] = "";
            copyOfDatabaseState[indexOfClub][3] = "";
            copyOfDatabaseState[indexOfClub][4] = "";
            copyOfDatabaseState[indexOfClub][5] = "";
            copyOfDatabaseState[indexOfClub][6] = "";
            copyOfDatabaseState[indexOfClub][7] = "";
            updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
                @Override
                public void onUpdateState() {
                    //after the database is updated, refresh the local copy
                    refreshCallback rc = new refreshCallback() {
                        @Override
                        public void onRefresh() {
                            //after the local copy is refreshed, do whatever the callback for this function is
                            if (dcc != null)
                            {
                                dcc.onDelete();
                            }
                        }
                    };
                    refreshDatabase(rc,c);
                }
            };
            updateDatabaseState(copyOfDatabaseState,udsc,c);
        }
    }

    public interface deleteUserCallback{
        void onDeleteUser();
    }

    /**
     * delete a user, removing them from all clubs, and all clubs from them, and from the list
     * @param userID the user to delete
     * @param duc what to do after this action has been performed
     */
    public void deleteUser(int userID, final deleteUserCallback duc, final Context c)
    {
        String[][] copyOfDatabaseState = copyDatabaseState();
        User userToDelete = null;
        for (int i = 0; i < allUsers.size(); i++)
        {
            if (allUsers.get(i).getID() == userID)
            {
                userToDelete = allUsers.get(i);
            }
        }
        if (userToDelete != null)
        {
            copyOfDatabaseState[2][1] = "" + (totalUsers - 1);
            ArrayList<ClubObject> clubMemberships = userToDelete.getClubsThisUserIsIn();
            ArrayList<ClubObject> clubLeaderships = userToDelete.getClubsThisUserIsALeaderOf();
            ArrayList<ClubObject> clubPendingJoinRequests = userToDelete.getPendingJoinClubs();
            for (ClubObject club: clubMemberships)
            {
                copyOfDatabaseState = removeClubMembershipFromUserInDatabaseState(userID,club.getID(),copyOfDatabaseState);
                copyOfDatabaseState = removeMemberFromClubInDatabaseState(userID,club.getID(),copyOfDatabaseState);
            }
            for (ClubObject club: clubLeaderships)
            {
                copyOfDatabaseState = removeCLubLeadershipFromUserInDatabaseState(userID,club.getID(),copyOfDatabaseState);
                copyOfDatabaseState = removeLeaderFromClubInDatabaseState(userID,club.getID(),copyOfDatabaseState);
            }
            for (ClubObject club: clubPendingJoinRequests)
            {
                copyOfDatabaseState = removePendingJoinRequestFromUserInDatabaseState(userID,club.getID(),copyOfDatabaseState);
                copyOfDatabaseState = removePendingJoinUserFromClubInDatabaseState(userID,club.getID(),copyOfDatabaseState);
            }
            int indexOfUser = getIndexOfUserInDatabase(userID,copyOfDatabaseState);
            copyOfDatabaseState[indexOfUser][numColumnsInClubList + 1] = deletedString;
            copyOfDatabaseState[indexOfUser][numColumnsInClubList + 2] = "";
            copyOfDatabaseState[indexOfUser][numColumnsInClubList + 3] = "";
            copyOfDatabaseState[indexOfUser][numColumnsInClubList + 4] = "";
            copyOfDatabaseState[indexOfUser][numColumnsInClubList + 5] = "";
            copyOfDatabaseState[indexOfUser][numColumnsInClubList + 6] = "";
            copyOfDatabaseState[indexOfUser][numColumnsInClubList + 7] = "";
            updateDatabaseStateCallback udsc = new updateDatabaseStateCallback() {
                @Override
                public void onUpdateState() {
                    //after the database is updated, refresh the local copy
                    refreshCallback rc = new refreshCallback() {
                        @Override
                        public void onRefresh() {
                            //after the local copy is refreshed, do whatever the callback for this function is
                            if (duc != null)
                            {
                                duc.onDeleteUser();
                            }
                        }
                    };
                    refreshDatabase(rc,c);
                }
            };
            updateDatabaseState(copyOfDatabaseState,udsc,c);
        }
    }

    public ClubObject getClubWithID(int id)
    {
        for (ClubObject c: allClubs)
        {
            if (c.getID() == id)
            {
                return c;
            }
        }
        return null;
    }

    public User getUserWithID(int id)
    {
        for (User u: allUsers)
        {
            if (u.getID() == id)
            {
                return u;
            }
        }
        return null;
    }

    public ArrayList<User> getAllUsersWhoAreNotModerators()
    {
        ArrayList<User> nonModerators = new ArrayList<>();
        for (User u: allUsers)
        {
            if (u.getRank() != User.Rank.MODERATOR)
            {
                nonModerators.add(u);
            }
        }
        return nonModerators;
    }

    public ArrayList<User> getAllUsersWhoAreModerators()
    {
        ArrayList<User> moderators = new ArrayList<>();
        for (User u: allUsers)
        {
            if (u.getRank() == User.Rank.MODERATOR)
            {
                moderators.add(u);
            }
        }
        return moderators;
    }

    public void debug_addRandomUsersToRandomClubPositions(int numCycles, final Context c)
    {
        Random r = new Random();
        String[][] newState = copyDatabaseState();
        for (int i = 0; i < numCycles; i++)
        {
            User randomUser = allUsers.get(r.nextInt(allUsers.size()));
            ClubObject randomClub = allClubs.get(r.nextInt(allClubs.size()));
            int userID = randomUser.getID();
            int clubID = randomClub.getID();
            int randomPosition = r.nextInt(3);
            switch(randomPosition)
            {
                case 0:
                    newState = coupleMemberAndClubInDatabaseState(userID,clubID,newState);
                    break;
                case 1:
                    newState = coupleLeaderAndClubInDatabaseState(userID,clubID,newState);
                    break;
                case 2:
                    newState = couplePendingJoinUserAndClubInDatabaseState(userID,clubID,newState);
                    break;

            }
        }
        updateDatabaseState(newState, new updateDatabaseStateCallback() {
            @Override
            public void onUpdateState() {
                refreshDatabase(null,c);
            }
        },c);
    }
}
