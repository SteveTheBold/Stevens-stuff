package clubs.bhs_clubsapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by super on 6/10/2017.
 */

public class ClubSelectionActivity extends AppCompatActivity {

    private ClubObject selectedClub = null;

    public static String SELECTED_CLUB_ID_EXTRA = "selectedClub";

    private static ArrayList<ClubObject> clubsToDisplay = new ArrayList<>();

    public static void setClubsToDisplay(ArrayList<ClubObject> clubs)
    {
        clubsToDisplay = clubs;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_club_selection);
        //ArrayList<ClubObject> allClubs = GlobalDatabaseConnectionContainer.getDatabaseConnection().getAllClubs();


        ListView ClubSelection_clubListView = (ListView) findViewById(R.id.ClubSelection_clubListView);
        ClubSelectionAdapter adapter = new ClubSelectionAdapter(clubsToDisplay, this, new ClubSelectionAdapter.onClubSelectedListener() {
            @Override
            public void onClubSelected(int clubID) {
                selectedClub = GlobalDatabaseConnectionContainer.getDatabaseConnection().getClubWithID(clubID);
                resetEverything();
            }
        });

        ClubSelection_clubListView.setAdapter(adapter);

        resetEverything();
    }


    public void resetEverything()
    {
        resetChooseButton();
        resetSelectedClubTextView();
    }

    public void resetChooseButton()
    {
        Button chooseButton = (Button) findViewById(R.id.club_selection_choose_button);
        if (selectedClub == null)
        {
            chooseButton.setClickable(false);
            chooseButton.setAlpha(0.5f);
        }
        else
        {
            chooseButton.setClickable(true);
            chooseButton.setAlpha(1f);
        }
    }

    public void resetSelectedClubTextView()
    {
        TextView club_selection_selected_club_textView = (TextView) findViewById(R.id.club_selection_selected_club_textView);
        String textToDisplay;
        if (selectedClub == null)
        {
            textToDisplay = "(no club selected)";
        }
        else
        {
            textToDisplay = selectedClub.getClubName();
        }
        club_selection_selected_club_textView.setText(textToDisplay);
    }

    public void onPressChoose(View view)
    {
        Intent i = new Intent();
        i.putExtra(SELECTED_CLUB_ID_EXTRA,selectedClub.getID());
        setResult(Activity.RESULT_OK,i);
        finish();
    }

    public void onPressCancel(View view)
    {
        setResult(Activity.RESULT_CANCELED);
        finish();
    }
}
