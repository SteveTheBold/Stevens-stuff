package dreamteam.b_movieapp.holders;

/**
 * Created by Jin on 6/25/2017.
 */

public class Trailer {

    String youtubeID, title;

    public Trailer(String youtubeID, String title) {

        this.youtubeID = youtubeID;
        this.title = title;

    }

    public String getYoutubeID() {
        return youtubeID;
    }

    public String getTitle() {
        return title;
    }
}
