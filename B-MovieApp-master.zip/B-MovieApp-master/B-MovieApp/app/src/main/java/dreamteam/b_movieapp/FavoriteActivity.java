package dreamteam.b_movieapp;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.GridView;

import java.util.ArrayList;
import java.util.List;

import dreamteam.b_movieapp.adapters.MovieAdapter;
import dreamteam.b_movieapp.data.*;
import dreamteam.b_movieapp.holders.Movie;

/**
 * Created by bal_sjtestone001 on 2/15/2017.
 */
public class FavoriteActivity extends AppCompatActivity {

    GridView favoriteGridView;

    ArrayList<Movie> favoritesList;
    SQLiteDatabase db;
    //TODO: get the favorites list from main
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorite);
        MoviesDataBase moviesDataBase = new MoviesDataBase(getApplicationContext());
        db = moviesDataBase.getReadableDatabase();

        favoriteGridView = (GridView) findViewById(R.id.favoriteGridView);

        accessDatabase();
    }

    public void accessDatabase() {

        Cursor result = db.rawQuery("SELECT * FROM Movie ORDER BY '" + MovieDataContract.MovieEntry.COLUMN_ID + "' DESC", null);

        favoritesList = new ArrayList<>();
        while(result.moveToNext()) {
            String title = result.getString(
                    result.getColumnIndexOrThrow(MovieDataContract.MovieEntry.COLUMN_TITLE));

            String date = result.getString(
                    result.getColumnIndexOrThrow(MovieDataContract.MovieEntry.COLUMN_DATE));

            String synopsis = result.getString(
                    result.getColumnIndexOrThrow(MovieDataContract.MovieEntry.COLUMN_SYNOPSIS));

            String imagePath = result.getString(
                    result.getColumnIndexOrThrow(MovieDataContract.MovieEntry.COLUMN_IMAGEPATH));

            double rating = Double.parseDouble(new Float(result.getFloat(
                    result.getColumnIndexOrThrow(MovieDataContract.MovieEntry.COLUMN_RATING))).toString());

            favoritesList.add(new Movie(0 /** placeholder **/, title, date, synopsis, imagePath, rating));

        }
        result.close();

        populateGridView();

    }

    public void populateGridView() {

//        for(Movie current : favoritesList) {
//            System.out.println(current);
//        }
        Movie[] favoritesArray = new Movie[favoritesList.size()];
        for(int i = 0; i < favoritesList.size(); i++) {
            favoritesArray[i] = favoritesList.get(i);
        }
        MovieAdapter viewAdapter = new MovieAdapter(favoritesArray, getApplicationContext());

        favoriteGridView.setAdapter(viewAdapter);
    }
}
