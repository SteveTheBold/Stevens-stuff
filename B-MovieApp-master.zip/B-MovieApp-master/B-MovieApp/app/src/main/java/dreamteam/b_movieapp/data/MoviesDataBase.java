package dreamteam.b_movieapp.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import dreamteam.b_movieapp.data.MovieDataContract;

/**
 * Created by bal_sjtestone001 on 3/2/2017.
 */
public class MoviesDataBase extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 4;
    static final String DATABASE_NAME = "BMovieData.db";

    @Override
    public void onCreate(SQLiteDatabase db) {
        final String SQL_CREATE_MOVIE_TABLE = "CREATE TABLE "
                + MovieDataContract.MovieEntry.TABLE_NAME + "("
                + MovieDataContract.MovieEntry.COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + MovieDataContract.MovieEntry.COLUMN_TITLE + " TEXT,"
                + MovieDataContract.MovieEntry.COLUMN_DATE + " INTEGER,"
                + MovieDataContract.MovieEntry.COLUMN_RATING + " INTEGER,"
                + MovieDataContract.MovieEntry.COLUMN_IMAGEPATH + " TEXT,"
                + MovieDataContract.MovieEntry.COLUMN_SYNOPSIS + " TEXT,"
                + MovieDataContract.MovieEntry.COLUMN_REVIEW + " TEXT);";
        db.execSQL(SQL_CREATE_MOVIE_TABLE);
    }

    public MoviesDataBase (Context context){
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        final String SQL_DELETE_MOVIE_TABLE =
                "DROP TABLE IF EXISTS " + MovieDataContract.MovieEntry.TABLE_NAME;
        db.execSQL(SQL_DELETE_MOVIE_TABLE);
        this.onCreate(db);
    }

}
