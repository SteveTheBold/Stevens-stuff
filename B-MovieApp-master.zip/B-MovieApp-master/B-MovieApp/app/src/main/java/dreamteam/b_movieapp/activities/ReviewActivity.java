package dreamteam.b_movieapp.activities;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.RatingBar;
import android.widget.TextView;

import dreamteam.b_movieapp.R;

public class ReviewActivity extends AppCompatActivity {

    private TextView authorView, contentView;
    private RatingBar ratingBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.review_view);

        // Initialize the ActionBar
        ActionBar ab = getSupportActionBar();
        // Add the "up" button (parent Activity referenced in manifest)
        ab.setDisplayHomeAsUpEnabled(false);

        authorView = (TextView) findViewById(R.id.authorView);
        contentView = (TextView) findViewById(R.id.contentView);
        ratingBar = (RatingBar) findViewById(R.id.ratingBar);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        String author = bundle.getString("author");
        String content = bundle.getString("content");
        int rating = bundle.getInt("rating");

        authorView.setText(author);
        contentView.setText(content);
        ratingBar.setNumStars(rating);

    }
}
