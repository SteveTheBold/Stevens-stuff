package dreamteam.b_movieapp.data;

import android.provider.BaseColumns;

/**
 * Created by bal_sjtestone001 on 3/6/2017.
 */
public class MovieDataContract {
    public static final class MovieEntry implements BaseColumns{
        public static final String TABLE_NAME = "Movie";
        public static final String COLUMN_ID = "_id";
        public static final String COLUMN_TITLE = "title";
        public static final String COLUMN_DATE = "date";
        public static final String COLUMN_SYNOPSIS = "synopsis";
        public static final String COLUMN_IMAGEPATH = "imagePath";
        public static final String COLUMN_RATING = "rating";
        public static final String COLUMN_REVIEW = "review";

    }
}
