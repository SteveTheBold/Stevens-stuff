package dreamteam.b_movieapp.holders;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by bal_jfbeaubien on 1/9/2017.
 */
public class Movie implements Parcelable{

    String title, date, imagePath, synopsis,videoUrl;
    Double rating;
    boolean video;
    int id;

    public Movie(int id, String movieTitle, String movieDate, String movieSynopsis,
            String movieImagePath, Double movieRating) {

        this.id = id;
        this.title = movieTitle;
        this.date = movieDate;
        this.synopsis = movieSynopsis;
        this.imagePath = movieImagePath;
        this.rating = movieRating;

    }

    public String toString() {
        return "Title: " + title;
    }

    protected Movie(Parcel in) {

        id = in.readInt();
        title = in.readString();
        date = in.readString();
        imagePath = in.readString();
        synopsis = in.readString();
        rating = in.readDouble();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {

        dest.writeInt(id);
        dest.writeString(title);
        dest.writeString(date);
        dest.writeString(imagePath);
        dest.writeString(synopsis);
        dest.writeDouble(rating);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Movie> CREATOR = new Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel in) {
            return new Movie(in);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDate() {
        return date;
    }

    public String getImagePath() {
        return imagePath;
    }

    public String getSynopsis() {
        return synopsis;
    }

    public Double getRating() {
        return rating;
    }

//    public boolean hasVideo(){
//        return video;
//    }

    public void addVideoUrl(String url){
        videoUrl = url;
    }

    public void setRating(Double rating) {
        this.rating = rating;
    }
}
