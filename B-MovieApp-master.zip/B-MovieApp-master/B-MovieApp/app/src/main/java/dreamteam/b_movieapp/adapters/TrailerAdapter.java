package dreamteam.b_movieapp.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RatingBar;
import android.widget.TextView;

import java.util.Random;

import dreamteam.b_movieapp.R;
import dreamteam.b_movieapp.activities.ReviewActivity;
import dreamteam.b_movieapp.holders.Review;
import dreamteam.b_movieapp.holders.Trailer;

/**
 * Created by bal_jfbeaubien on 2/14/2017.
 */
public class TrailerAdapter extends BaseAdapter {

    private Context cxt;
    private Trailer[] trailers;

    public TrailerAdapter(Trailer[] trailers, Context cxt) {

        this.trailers = trailers;
        this.cxt = cxt;
    }

    @Override
    public int getCount() {
        return trailers.length;
    }

    @Override
    public Object getItem(int i) {
        return trailers[i];
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        final Trailer currentTrailer = trailers[i];
        View layout;

        if(view == null) {
            /** Not a recycled view **/

            TextView textView = new TextView(cxt);
            textView.setText(currentTrailer.getTitle());
            textView.setTextSize(16);
            textView.setTextColor(Color.BLACK);

            textView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube://" + currentTrailer.getYoutubeID()));
                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    cxt.startActivity(intent);
                }
            });

            layout = textView;

        }else {

            layout = view;
        }

        return layout;

    }
}
