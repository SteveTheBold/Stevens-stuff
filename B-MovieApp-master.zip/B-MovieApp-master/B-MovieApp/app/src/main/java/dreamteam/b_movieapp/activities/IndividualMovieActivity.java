package dreamteam.b_movieapp.activities;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabaseLockedException;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.squareup.picasso.Picasso;
import com.squareup.picasso.Target;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;

import dreamteam.b_movieapp.BuildConfig;
import dreamteam.b_movieapp.adapters.TrailerAdapter;
import dreamteam.b_movieapp.holders.Movie;
import dreamteam.b_movieapp.R;
import dreamteam.b_movieapp.data.MovieDataContract;
import dreamteam.b_movieapp.data.MoviesDataBase;
import dreamteam.b_movieapp.holders.Review;
import dreamteam.b_movieapp.adapters.ReviewAdapter;
import dreamteam.b_movieapp.holders.Trailer;

public class IndividualMovieActivity extends AppCompatActivity {

    private Movie movie;
    private Review[] reviews;
    private Trailer trailer;

    private ImageView moviePosterView;
    private TextView titleView, dateView, synopsisView;
    private ListView reviewListView, trailerListView;

    private static final String API_KEY = BuildConfig.API_KEY;

    private boolean ADDED_TO_FAVORITES;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.movie_menu, menu);
        MenuItem menuItem = menu.findItem(R.id.action_favorite);
        // Favorite status isn't changing so do opposite of predicted by method
        setIconColor(menuItem, !ADDED_TO_FAVORITES);
        return true;

    }
    MoviesDataBase dataBase;
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            case R.id.action_favorite:

                SQLiteDatabase dbWrite = dataBase.getWritableDatabase();

                if(ADDED_TO_FAVORITES) {
                    //remove from favorites
                    Toast.makeText(IndividualMovieActivity.this, "Removed from favorites", Toast.LENGTH_SHORT).show();
                    setIconColor(item, ADDED_TO_FAVORITES);

                    String whereClause = MovieDataContract.MovieEntry.COLUMN_TITLE + "=?";
                    String[] whereArgs = { movie.getTitle() };
                    dbWrite.delete(MovieDataContract.MovieEntry.TABLE_NAME, whereClause, whereArgs);

                    ADDED_TO_FAVORITES = false;

                }else {
                    //add to favorites
                    Toast.makeText(IndividualMovieActivity.this, "Added to favorites", Toast.LENGTH_SHORT).show();
                    setIconColor(item, ADDED_TO_FAVORITES);

                    ContentValues movieInfo = new ContentValues();
                    /*
                        Fills movieInfo with information from the movie object in this class.
                        then inserts it into dbWrite to be used in favorites
                     */
                    movieInfo.put(MovieDataContract.MovieEntry._ID, movie.getId());
                    movieInfo.put(MovieDataContract.MovieEntry.COLUMN_TITLE, movie.getTitle());
                    movieInfo.put(MovieDataContract.MovieEntry.COLUMN_DATE, movie.getDate());
                    movieInfo.put(MovieDataContract.MovieEntry.COLUMN_SYNOPSIS, movie.getSynopsis());
                    movieInfo.put(MovieDataContract.MovieEntry.COLUMN_IMAGEPATH, movie.getImagePath());
                    movieInfo.put(MovieDataContract.MovieEntry.COLUMN_RATING, movie.getRating());
                    movieInfo.put(MovieDataContract.MovieEntry.COLUMN_REVIEW, "Review Placeholder !");

                    dbWrite.insert(MovieDataContract.MovieEntry.TABLE_NAME, null, movieInfo);

                    ADDED_TO_FAVORITES = true;
                }

                return true;

            case R.id.action_share:

                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, "https://www.youtube.com/watch?v=" + trailer.getYoutubeID());
                sendIntent.setType("text/plain");
                startActivity(Intent.createChooser(sendIntent,"Share using"));


            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void setIconColor(MenuItem item, boolean isSelected) {

        Drawable drawable = item.getIcon();
        drawable.mutate();

        if(isSelected) {
            drawable.setColorFilter(Color.parseColor("#FFFFFF"), PorterDuff.Mode.SRC_ATOP);
        }else {
            drawable.setColorFilter(Color.parseColor("#FFD700"), PorterDuff.Mode.SRC_ATOP);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_individual_movie);

        // Initialize components of the details page
        moviePosterView = (ImageView) findViewById(R.id.moviePoster);
        titleView = (TextView) findViewById(R.id.title);
        dateView = (TextView) findViewById(R.id.date);
        synopsisView = (TextView) findViewById(R.id.synopsis);
        reviewListView = (ListView) findViewById(R.id.reviewList);
        trailerListView = (ListView) findViewById(R.id.trailerList);

        // Initialize the ActionBar
        ActionBar ab = getSupportActionBar();
        // Add the "up" button (parent Activity referenced in manifest)
        ab.setDisplayHomeAsUpEnabled(true);

        if(getIntent() != null) {
            // Grab Intent sent to this Activity
            Intent intent = getIntent();
            // Initialize the Movie object to be displayed
            movie = (Movie) intent.getExtras().get("movie");
        }

        System.out.println(movie.getId());

        Picasso.with(this).load("http://image.tmdb.org/t/p/w185/" + movie.getImagePath()).into(moviePosterView);
        titleView.setText(movie.getTitle() + " - " + movie.getRating() + " / 10");
        dateView.setText(movie.getDate());
        synopsisView.setText(movie.getSynopsis());

        dataBase = new MoviesDataBase(this);
        ADDED_TO_FAVORITES = isMovieFavorited();

        getReviews();
        getTrailers();
    }

    public boolean isMovieFavorited() {

        SQLiteDatabase sqLiteDatabase = dataBase.getReadableDatabase();

//        String selection = MovieDataContract.MovieEntry.COLUMN_TITLE + " = ?";
//        String[] selectionArgs = { movie.getTitle() };

        Cursor result = sqLiteDatabase.rawQuery("SELECT * FROM " + MovieDataContract.MovieEntry.TABLE_NAME +
                                                " WHERE " + MovieDataContract.MovieEntry.COLUMN_TITLE + "='" +
                                                movie.getTitle() + "'", null);
        return result.getCount() != 0;
    }

    public void getReviews() {

        String url = "https://api.themoviedb.org/3/movie/" + movie.getId()
                + "/reviews?api_key=" + API_KEY + "&language=en-US&page=1";

        System.out.println(url);

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {

                    JSONArray results = response.getJSONArray("results");
                    Review[] reviewArray = new Review[results.length()];

                    for(int i = 0; i < results.length(); i++) {

                        JSONObject currentReview = results.getJSONObject(i);
                        reviewArray[i] = new Review(
                                currentReview.getString("author"),
                                currentReview.getString("content"),
                                currentReview.getString("url")
                        );

                    }

                    if(reviewArray.length > 0) {
                        reviews = reviewArray;
                        ReviewAdapter reviewAdapter = new ReviewAdapter(reviewArray, getApplicationContext());
                        reviewListView.setAdapter(reviewAdapter);
                    }


                }catch (JSONException error) {

                    // Display JSON Exception
                    Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();

                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                Log.e("Volley", error.getMessage());
            }
        });

        requestQueue.add(objectRequest);

    }

    public void getTrailers() {

        String url = "https://api.themoviedb.org/3/movie/" + movie.getId() +
                "/videos?api_key=" + API_KEY + "&language=en-US";

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {

                    JSONArray results = response.getJSONArray("results");
                    Trailer[] trailers = new Trailer[results.length()];

                    for(int i = 0; i < results.length(); i++) {

                        JSONObject currentTrailer = (JSONObject) results.get(i);
                        trailers[i] = new Trailer(currentTrailer.getString("key"), currentTrailer.getString("name"));

                        if(i == 0) {
                            trailer = trailers[i];
                        }
                    }

                    if(trailers.length > 0) {
                        System.out.println("THERE ARE TRAILERS");
                        TrailerAdapter trailerAdapter = new TrailerAdapter(trailers, getApplicationContext());
                        trailerListView.setAdapter(trailerAdapter);
                    }


                }catch (JSONException error) {

                    // Display JSON Exception
                    Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();

                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                Log.e("Volley", error.getMessage());
            }
        });

        requestQueue.add(objectRequest);

    }
}
