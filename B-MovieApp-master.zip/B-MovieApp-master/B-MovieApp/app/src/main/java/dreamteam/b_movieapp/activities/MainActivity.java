package dreamteam.b_movieapp.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.GridView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

import dreamteam.b_movieapp.BuildConfig;
import dreamteam.b_movieapp.FavoriteActivity;
import dreamteam.b_movieapp.holders.Movie;
import dreamteam.b_movieapp.adapters.MovieAdapter;
import dreamteam.b_movieapp.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        updateFavorites();
        // Display movies on startup
        movieDBCall(topRatedURL);
        setContentView(R.layout.activity_main);
    }
    // Initialize the sorting icons
    // Menu contains two icons, thumbs up for top rated and trend-line for popular
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu);
        return true;

    }

    // Default method run when any MenuItem in the ActionBar is clicked
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {

            // Handle the popular icon
            case R.id.action_popular:
                movieDBCall(popularURL);
                return true;

            // Handle the top rated icon
            case R.id.action_top_rated:
                movieDBCall(topRatedURL);
                return true;
            case R.id.action_favorite:
                Intent intent = new Intent(getBaseContext(),FavoriteActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                getBaseContext().startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }


    // Movie website url
    // needs to be set
    private static final String key = BuildConfig.API_KEY;
    private String topRatedURL = "https://api.themoviedb.org/3/movie/top_rated?api_key=" + key + "&language=en-US&page=1&&page=1&append_to_response=videos";
    private String popularURL = "https://api.themoviedb.org/3/movie/popular?api_key=" + key + "&language=en-US&page=1&append_to_response=videos";
    private int movieId;
    private String getVideos = "https://api.themoviedb.org/3/movie/"+ movieId +"/videos?api_key="+ key +"&language=en-US";
    public ArrayList<Movie> favorites;
    public Movie[] movieList;


    private void updateFavorites(){
        favorites = new ArrayList<>();

        if (getIntent().hasExtra("movie")){
            // title date movie syno image rating
            Movie temp = getIntent().getParcelableExtra("movie");
            favorites.add(temp);

        }
    }

    /**
     * JsonObject request to get each movie's info
     * @param url Movie api website
     */
    public void movieDBCall(String url) {
        updateFavorites();

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest objectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                try {

                    JSONArray results = response.getJSONArray("results");
                    movieList = new Movie[results.length()];

                    // Parses every movie's info and creates a new movie object for Movie[]
                    for(int i = 0; i < results.length(); i++) {


                            JSONObject currentMovie = results.getJSONObject(i);

                            // construction of a new Movie object
                            movieList[i] = new Movie(
                                    currentMovie.getInt("id"),
                                    currentMovie.getString("title").replaceAll("\\p{P}", ""),
                                    currentMovie.getString("release_date"),
                                    currentMovie.getString("overview"),
                                    currentMovie.getString("poster_path"),
                                    currentMovie.getDouble("vote_average"));
                        // if the movie has a video, then get those videos
                    }

                    populateGridView(movieList);

                }catch (JSONException error) {

                    // Display JSON Exception
                    Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();

                }

            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
                Log.e("Volley", error.getMessage());
            }
        });

        requestQueue.add(objectRequest);

        /**
         * gets the videos site if a movie has one
         */
        
//        JsonObjectRequest trailers = new JsonObjectRequest(Request.Method.GET, getVideos, null, new Response.Listener<JSONObject>() {
//            @Override
//            public void onResponse(JSONObject response) {
//
//                for (int j = 0;j < movieList.length;j++)
//                    if (movieList[j].hasVideo())
//                        try {
//                            movieId = movieList[j].getId();
//                            JSONObject videoDetails = response.getJSONObject("results");
//                            movieList[j].addVideoUrl(videoDetails.getString("site"));
//
//                        } catch (JSONException error) {
//
//                            // Display JSON Exception
//                            Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
//
//                        }
//
//            }
//        }, new Response.ErrorListener() {
//            @Override
//            public void onErrorResponse(VolleyError error) {
//                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
//                Log.e("Volley", error.getMessage());
//            }
//        });
//
//        requestQueue.add(trailers);
    }


    /**
     * creates a adapter for gridView and sets it with Movies[]
     * @param movies Movie array from movieDBCall
     */

    public void populateGridView(Movie[] movies) {
        MovieAdapter viewAdapter = new MovieAdapter(movies, getApplicationContext());

        GridView movieView = (GridView) findViewById(R.id.gridView);
        movieView.setAdapter(viewAdapter);
    }

}
