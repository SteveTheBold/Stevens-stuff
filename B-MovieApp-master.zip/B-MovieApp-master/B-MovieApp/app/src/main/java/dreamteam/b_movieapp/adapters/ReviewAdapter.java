package dreamteam.b_movieapp.adapters;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.RatingBar;
import android.widget.TextView;

import java.util.Random;

import dreamteam.b_movieapp.R;
import dreamteam.b_movieapp.holders.Review;
import dreamteam.b_movieapp.activities.ReviewActivity;

/**
 * Created by bal_jfbeaubien on 2/14/2017.
 */
public class ReviewAdapter extends BaseAdapter {

    private Context cxt;
    private Review[] reviews;

    public ReviewAdapter(Review[] reviews, Context cxt) {

        this.reviews = reviews;
        this.cxt = cxt;
    }

    @Override
    public int getCount() {
        return reviews.length;
    }

    @Override
    public Object getItem(int i) {
        return reviews[i];
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        final Review currentReview = reviews[i];
        View layout;

        if(view == null) {
            /** Not a recycled view **/
            LayoutInflater inflater = (LayoutInflater) cxt.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            layout = inflater.inflate(R.layout.review_view, null);

            TextView authorView = (TextView) layout.findViewById(R.id.authorView);
            TextView contentView = (TextView) layout.findViewById(R.id.contentView);
            RatingBar ratingBar = (RatingBar) layout.findViewById(R.id.ratingBar);

            authorView.setTextColor(Color.BLACK);
            contentView.setTextColor(Color.BLACK);

            authorView.setText(currentReview.getAuthor());
            if(currentReview.getContent().length() > 151) {
                contentView.setText(currentReview.getContent().substring(0, 150) + "...");
            }else {
                contentView.setText(currentReview.getContent());
            }
            ratingBar.setNumStars(new Random(4).nextInt());

            contentView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                    Intent intent = new Intent(cxt, ReviewActivity.class);
                    intent.putExtra("author", currentReview.getAuthor());
                    intent.putExtra("content", currentReview.getContent());
                    intent.putExtra("rating", new Random(4).nextInt());

                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    cxt.startActivity(intent);

                }
            });

        }else {

            layout = view;
        }

        return layout;

    }
}
