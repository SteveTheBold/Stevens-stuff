package dreamteam.b_movieapp.adapters;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import dreamteam.b_movieapp.holders.Movie;
import dreamteam.b_movieapp.activities.IndividualMovieActivity;

/**
 * Created by bal_jfbeaubien on 1/13/2017.
 */
public class MovieAdapter extends BaseAdapter {

    private Movie[] movieList;
    private Context cxt;

    private boolean CONNECTED_TO_INTERNET;

    public MovieAdapter(Movie[] movies, Context context) {
        this.movieList = movies;
        this.cxt = context;

        ConnectivityManager connectivityManager =
                (ConnectivityManager) cxt.getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkInfo activeNetwork = connectivityManager.getActiveNetworkInfo();

        CONNECTED_TO_INTERNET = activeNetwork != null &&
                activeNetwork.isConnectedOrConnecting();

        if(!CONNECTED_TO_INTERNET) {
            Toast.makeText(cxt, "You are not connected to the internet.", Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public int getCount() {
        return movieList.length;
    }

    @Override
    public Object getItem(int i) {
        return movieList[i];
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        if(CONNECTED_TO_INTERNET) {

            ImageView imgV;

            if(view == null) {
                /** Not recycled View **/
                imgV = new ImageView(cxt);
                imgV.setAdjustViewBounds(true);
                imgV.setScaleType(ImageView.ScaleType.FIT_CENTER);

            }else {
                /** Recycled View **/
                imgV = (ImageView) view;
            }

            final Movie currentMovie = movieList[i];
            Picasso.with(cxt).load("http://image.tmdb.org/t/p/w185/" + currentMovie.getImagePath()).into(imgV);

            System.out.println(currentMovie.getImagePath());
            // Sets a onClick listener for each image in
            imgV.setOnClickListener(new View.OnClickListener() {

                public void onClick(View v) {
                    /** Build Intent for movie details **/
                    Intent intent = new Intent(cxt, IndividualMovieActivity.class);
                    intent.putExtra("movie", currentMovie);

                    /** Start Intent FROM an activity (needs FLAG_ACTIVITY_NEW_TASK to start) **/
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    cxt.startActivity(intent);
                }

            });

            return imgV;

        }else {
            //TODO: Make the GridView a ListView and revamp it for lack of internet connection

            TextView textView;

            if(view == null) {
                /** Not recycled View **/
                textView = new TextView(cxt);
            }else {
                /** Recycled View **/
                textView = (TextView) view;
            }

            final Movie currentMovie = movieList[i];
            textView.setText(currentMovie.getTitle());

            return textView;
        }



    }
}
