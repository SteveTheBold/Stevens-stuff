package dreamteam.b_movieapp.holders;

/**
 * Created by bal_jfbeaubien on 2/14/2017.
 */
public class Review {

    private String author, content, url;

    public Review(String author, String content, String url) {

        this.author = author;
        this.content = content;
        this.url = url;
    }

    public String getAuthor() {
        return author;
    }

    public String getContent() {
        return content;
    }

    public String getUrl() {
        return url;
    }
}
